﻿<#
.Synopsis
   Collect Active Directory Group Membership
.DESCRIPTION
   Long description
.EXAMPLE
   Example of how to use this cmdlet
.EXAMPLE
   Another example of how to use this cmdlet
.NOTES
    Version 2.0 (9/28/2015)
    - Complete rewrite of script from previous versions
    - Includes intermediate changes up to 9/28/2015
#>

[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DomainList,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

if ($Standalone) 
{ 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }

    if ($DomainList)
    {
        $domains_detail = @()
        foreach ($domain in $domainlist)
        {
            # Convert FQDN to DN
            $domainnamearray = $domain.split(".")
            $domainDN = "dc=" + $domainnamearray[0]
            for ($i=1;$i -lt $domainnamearray.count; $i++) { $domaindn += ",dc=" + $domainnamearray[$i] }

            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $domain
            $domainobj | Add-Member NoteProperty DomainDN $domaindn
            $domains_detail += $domainobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose        
    } 
} 


# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

# Get the name and DN for the root domain
$root = new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
$rootDN = $($root.rootDomainNamingContext)
$current_forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()

# Import the list of custom groups for which membership should be collected
# This comes from a tab-delimited file that contains the Domain, Domain DistinguishedName, and Group Name for each group
function Import-CustomGroups($custom_file)
{
    Write-Verbose "Getting list of custom groups from file"
    $header = "Domain","DomainDN","GroupName"
    $delimiter = "`t"
    $CustomGroupList = import-csv -Path $custom_file -Header $header -Delimiter $delimiter
    
    #TODO: Filter the list of custom groups to remove any of the groups we collect by default
    
    # $customgrouplist.count doesn't actually work (at least not if there is only one member)
    Write-Verbose "Found $($CustomGroupList.count) custom groups" -verbose
    return $CustomGroupList
}

#Find the SID of the domain given the distinguished name
function Get-domainSID($domainDN)
{
    # Use ADSI interface to get the object
    $domain = new-object System.DirectoryServices.DirectoryEntry("LDAP://$($domainDN)")

    # Get the objectSID, which is stored in byte format.
    
    $byteObjectSID = $($domain.objectsid)
    $strObjectSID = (New-Object System.Security.Principal.SecurityIdentifier($byteObjectSID,0)).value

    return $strObjectSID
}

#Find an AD Object by searching for the objectSID
function Find-ADObjectBySID ($sid, $domaindn, $groupname)
{
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher
    $Searcher.Filter = "objectSID=$SID"
    $Searcher.SearchRoot = "LDAP://$($domaindn)"
    $foundObj = $Searcher.FindOne()
    $searcher.Dispose()
    
    if ($foundObj)
    {
        # $foundObj is a System.DirectoryServices.SearchResult, but we need a System.DirectoryServices.DirectoryEntry
        # So we need to go from one to another
        $adObj = $foundObj.GetDirectoryEntry()
        return $adobj
    }
    else 
    { 
        $memberObj = New-Object PSObject

        $memberObj | Add-Member NoteProperty ContainingDomain ($domainDN).tolower().replace("dc=","").replace(",",".")
        $memberObj | Add-Member NoteProperty Name $groupName
        $memberObj | Add-Member NoteProperty DistinguishedName "< GROUP DOES NOT EXIST IN DOMAIN >"
        $memberObj | Add-Member NoteProperty MemberName "< GROUP DOES NOT EXIST IN DOMAIN >"
        $memberObj | Add-Member NoteProperty SAMAccountName $null
        $memberObj | Add-Member NoteProperty MemberType $null
        $memberObj | Add-Member NoteProperty MemberDN $null  
        $memberObj | Add-Member NoteProperty ADSAParentGroupDN $null
        $memberObj | Add-Member NoteProperty ADSAParentGroupName $null
        return $memberObj 
    }
}

# Find an object in AD by searching for the type (user,group,etc.) and name
function Find-ADObject ($name,$type,$domaindn)
{
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher
    $Searcher.Filter = "(&(objectCategory=$type)(name=$name))"
    $Searcher.SearchRoot = "LDAP://$($domaindn)"
    $foundObj = $Searcher.FindOne()
    $searcher.Dispose()

    if ($foundObj)
    {
        # $foundObj is a System.DirectoryServices.SearchResult, but we need a System.DirectoryServices.DirectoryEntry
        # So we need to go from one to another
        $adObj = $foundObj.GetDirectoryEntry()
        return $adobj
    }
    else 
    { 
        $memberObj = New-Object PSObject

        $memberObj | Add-Member NoteProperty ContainingDomain ($domainDN).tolower().replace("dc=","").replace(",",".")
        $memberObj | Add-Member NoteProperty Name $Name
        $memberObj | Add-Member NoteProperty DistinguishedName "< GROUP DOES NOT EXIST IN DOMAIN >"
        $memberObj | Add-Member NoteProperty MemberName "< GROUP DOES NOT EXIST IN DOMAIN >"
        $memberObj | Add-Member NoteProperty SAMAccountName $null
        $memberObj | Add-Member NoteProperty MemberType $null
        $memberObj | Add-Member NoteProperty MemberDN $null  
        $memberObj | Add-Member NoteProperty ADSAParentGroupDN $null
        $memberObj | Add-Member NoteProperty ADSAParentGroupName $null
        $memberObj | Add-Member NoteProperty MemberAdminCount 0
        $memberObj | Add-Member NoteProperty MemberUAC $null
        $memberObj | Add-Member NoteProperty MemberDisplayName $null
        $memberObj | Add-Member NoteProperty MemberDescription $null
        return $memberObj 
    }
}

# Given a SID, find the name of the AD object
function ConvertTo-NTAccountName($sid)
{
   $ID = New-Object System.Security.Principal.SecurityIdentifier($sid)
   $account = $ID.Translate( [System.Security.Principal.NTAccount])
   Return $account.Value
}

# Get the list of privileged groups in the domain
function Get-DomainPrivilegedGroups
{
    Param
    (
        $domainDN,
        $additionalGroupNames = $null
    )
    
    # If we're in the forest root domain, there are additional groups to look for
    if ($domainDN -eq $rootDN) { $bIsForestRoot = $true }

    # Find the SID for the current domain
    $domainSID = get-domainSID $domainDN

    # Well-known SIDs for domain objects (built-in and default).
    # Source is KB 243330
    # A better reference is https://msdn.microsoft.com/en-us/library/cc980032.aspx
    # Skip Domain Users, Domain Computers, and BUILTIN\Users
    # Searching by the SID eliminates potential issues due to non-English installs or renamed groups

    # Put each of the results in an array that we can loop through later
    $domaingroups = @()
    
    # Well-known domain SIDs
    $domaingroups += find-ADObjectBySID ($domainSID + "-512") $domainDN "Domain Admins"
    $domaingroups += Find-ADObjectBySID ($domainSID + "-514") $domainDN "Domain Guests"
    $domaingroups += find-ADObjectBySID ($domainSID + "-516") $domainDN "Domain Controllers"
    $domaingroups += find-ADObjectBySID ($domainSID + "-517") $domainDN "Cert Publishers"
    $domaingroups += find-ADObjectBySID ($domainSID + "-520") $domainDN "Group Policy Creator Owners"
    $domaingroups += find-ADObjectBySID ($domainSID + "-553") $domainDN "RAS and IAS Servers"
    $domaingroups += find-ADObjectBySID ($domainSID + "-498") $domainDN "Enterprise Read-only Domain Controllers" # (2008+) n.b. This group is created once per forest, in the first domain with a 2008+ PDC after RODCPrep is run
    $domaingroups += find-ADObjectBySID ($domainSID + "-521") $domainDN "Read-only Domain Controllers" # (2008+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-571") $domainDN "Allowed RODC Password Replication Group" # (2008+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-572") $domainDN "Denied RODC Password Replication Group" # (2008+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-522") $domainDN "Clonable Domain Controllers" # (2012+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-525") $domainDN "Protected Users" # (2012+)
    # Well-known builtin SIDs
    $domaingroups += find-ADObjectBySID "S-1-5-32-544" $domainDN "Administrators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-546" $domainDN "Guests"
    $domaingroups += find-ADObjectBySID "S-1-5-32-547" $domainDN "Power Users"
    $domaingroups += find-ADObjectBySID "S-1-5-32-548" $domainDN "Account Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-549" $domainDN "Server Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-550" $domainDN "Print Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-551" $domainDN "Backup Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-552" $domainDN "Replicators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-554" $domainDN "Pre-Windows 2000 Compatible Access"
    $domaingroups += find-ADObjectBySID "S-1-5-32-555" $domainDN "Remote Desktop Users"
    $domaingroups += find-ADObjectBySID "S-1-5-32-556" $domainDN "Network Configuration Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-558" $domainDN "Performance Monitor Users"
    $domaingroups += find-ADObjectBySID "S-1-5-32-559" $domainDN "Performance Log Users"
    $domaingroups += find-ADObjectBySID "S-1-5-32-560" $domainDN "Windows Authorization Access Group"
    $domaingroups += find-ADObjectBySID "S-1-5-32-561" $domainDN "Terminal Server License Servers"
    $domaingroups += find-ADObjectBySID "S-1-5-32-562" $domainDN "Distributed COM Users"
    $domaingroups += find-ADObjectBySID "S-1-5-32-568" $domainDN "IIS_IUSRS"
    $domaingroups += find-ADObjectBySID "S-1-5-32-569" $domainDN "Cryptographic Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-573" $domainDN "Event Log Readers"
    $domaingroups += find-ADObjectBySID "S-1-5-32-574" $domainDN "Certificate Service DCOM Access"
    $domaingroups += find-ADObjectBySID "S-1-5-32-575" $domainDN "RDS Remote Access Servers"
    $domaingroups += find-ADObjectBySID "S-1-5-32-576" $domainDN "RDS Endpoint Servers"
    $domaingroups += find-ADObjectBySID "S-1-5-32-577" $domainDN "RDS Management Servers"
    $domaingroups += find-ADObjectBySID "S-1-5-32-578" $domainDN "Hyper-V Administrators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-579" $domainDN "Access Control Assistance Operators"
    $domaingroups += find-ADObjectBySID "S-1-5-32-580" $domainDN "Remote Management Users" 
    # Common domain groups without a well-known SID
    $domaingroups += Find-ADObject "Debugger Users" "group" $domainDN
    $domaingroups += Find-ADObject "DHCP Administrators" "group" $domainDN
    $domaingroups += Find-ADObject "DHCP Users" "group" $domainDN
    $domaingroups += Find-ADObject "DnsAdmins" "group" $domainDN
    $domaingroups += Find-ADObject "DnsUpdateProxy" "group" $domainDN
    $domaingroups += Find-ADObject "Exchange Domain Servers" "group" $domainDN
    $domaingroups += Find-ADObject "Exchange Enterprise Servers" "group" $domainDN
    # TODO (ERHALL 9/28/2015): Explore adding group collection for default Exchange groups for E2007+

    
    if ($bIsForestRoot)
    {

        # Well-known SIDs for forest objects (built-in and default).
        # Source is KB 243330
    
        $domaingroups += find-ADObjectBySID ($domainSID + "-518") $domainDN "Schema Admins"
        $domaingroups += find-ADObjectBySID ($domainSID + "-519") $domainDN "Enterprise Admins"
        $domaingroups += find-ADObjectBySID "S-1-5-32-557" $domainDN "Incoming Forest Trust Builders"
    }

    # Also get additional groups supplied at execution time
    if ($additionalGroupNames)
    {
        foreach ($group in $additionalGroupNames)
        {
            $domaingroups += Find-ADObject $group "group" $domainDN
        }
    }

    return $domaingroups
}

# Put all the attributes about a member into a common format
function New-MemberObject
{
    Param
    (
        $rootgroupname, #string
        $rootgroupdn, #string
        $domain, #string
        $member, #DirectoryEntry           
        $parentDNs,
        $parentNames
    )

    $memberObj = New-Object PSObject

    $memberObj | Add-Member NoteProperty ContainingDomain $domain
    $memberObj | Add-Member NoteProperty Name $rootgroupname
    $memberObj | Add-Member NoteProperty DistinguishedName $rootgroupdn
    $memberObj | Add-Member NoteProperty MemberName $($member.name)
    $memberObj | Add-Member NoteProperty SAMAccountName $($member.samaccountname)
    $memberObj | Add-Member NoteProperty MemberType $($member.schemaclassname)
    $memberObj | Add-Member NoteProperty MemberDN $($member.distinguishedname)
    $memberObj | Add-Member NoteProperty MemberDisplayName $($member.displayname)
    $memberObj | Add-Member NoteProperty MemberDescription $($member.description)
    $memberObj | Add-Member NoteProperty ADSAParentGroupDN $parentDNs
    $memberObj | Add-Member NoteProperty ADSAParentGroupName $parentNames

    if ($($member.schemaclassname) -eq 'User')
    {
        $memberObj | Add-Member NoteProperty MemberAdminCount $($member.admincount)
        if ($memberObj.memberadmincount -notmatch "\d+") { $memberObj.memberadmincount = 0 }
        $memberObj | Add-Member NoteProperty MemberUAC $($member.UserAccountControl)
    }
    else
    {
        $memberObj | Add-Member NoteProperty MemberAdminCount 0
        $memberObj | Add-Member NoteProperty MemberUAC $null
    }    



    return $memberObj
}

<# Recursive function to get the members of a group and each group
    Execution Flow:
    1. Initial function call passes the name of the top-level group, it's DN, 
        the System.DirectoryServices.DirectoryEntry for the group, and the 
        domain name. Userlist is null.
    2. Loop through each member of the group.
        a. Find the DirectoryEntry for the member.
        b. If the member is already in userlist, add an additional parent group
            (the calling group)
        c. If the member is a user, add it to userlist
        d. if the member is a group
            1. If it has no members, add it to userlist (no need for recursion)
            2. If the group is Domain Users, don't recurse because it's pointless
            3. Otherwise:
                a. Call the function again to get the members of the child group.
                b. Assign the output to userlist.
                c. Add the group to userlist
    3. Return userlist

    TODO: Handle case where member is something other than a user or group
        (e.g. a ForeignSecurityPrincipal)
    TODO: Error handling for groups that don't exist.
#>
function Get-GroupMembersRecursive
{
    Param
    (
        $rootgroupname,
        $rootgroupdn,
        $group, # DirectoryEntry object for group
        $domain, # Domain name
        $userlist = @(),
        $ancestors = @()
    )
    write-Verbose "`tGetting recursive members of $($group.name)"
    foreach ($memberDN in $group.member)
    {
        if ($ancestors -contains $memberDN) 
        # Indicates a loop in group membership
        { 
            $warningstring = "Loop detected: " + $memberDN.tostring() + " is both a child and an ancestor of " + $($group.distinguishedname) + ". Exiting recursive loop."
            write-warning $warningstring
            continue 
        }
        $memberDN = replace-ADSpecialChars $memberDN
        $member = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$memberDN")
        
        if ($userlist.memberdn -contains $member.distinguishedname)
        {
            $a = $userlist.memberdn.indexof($($member.distinguishedname))
            $userlist[$a].ADSAParentGroupDN = "$($userlist[$a].ADSAParentGroupDN)|$($group.distinguishedname)"
            $userlist[$a].ADSAParentGroupName= "$($userlist[$a].ADSAParentGroupName)|$($group.name)"
        }
        elseif ($member.objectClass -contains "user")
        {
            $userlist += New-MemberObject $rootgroupname $rootgroupdn $domain $member $($group.distinguishedname) $($group.name)    
        }   
        elseif ($member.objectClass -contains "foreignSecurityPrincipal")
        {
            Add-Content ".\debug.txt" ("MemberName: " + $member.Name)
            $objSID = New-Object System.Security.Principal.SecurityIdentifier($member.Name)
            Add-Content ".\debug.txt" ("SID: " + $objSID.Value)
            $objUser = $objSID.Translate([System.Security.Principal.NTAccount])
            Add-Content ".\debug.txt" ("Translated SID: " + $objUser.Value)
            $member.SAMAccountName = $objUser.Value
            Add-Content ".\debug.txt" ("Member: " + $member.SAMAccountName)
            $userlist += New-MemberObject $rootgroupname $rootgroupdn $domain $member $($group.distinguishedname) $($group.name)    
        } 
        elseif ($member.objectClass -contains "group")
        {           
            if ($member.member.count -eq 0) # Group contains no members
            {
                $userlist += New-MemberObject $rootgroupname $rootgroupdn $domain $member $($group.distinguishedname) $($group.name)
            }
            elseif ($member.name -eq "Domain Users") # Avoid pulling all domain users (this happens with Pre-Windows 2000 Compatible Access group, among others)
            {
                $userlist += New-MemberObject $rootgroupname $rootgroupdn $domain $member $($group.distinguishedname) $($group.name)
            }
            else
            {
                $ancestors += $($group.distinguishedname)
                [array]$userlist = Get-GroupMembersRecursive $rootgroupname $rootgroupdn $member $domain $userlist $ancestors
                $userlist += New-MemberObject $rootgroupname $rootgroupdn $domain $member $($group.distinguishedname) $($group.name)
            }
        }
            
    }     
    return $userlist  
}

function replace-ADSpecialChars($strDN)
{
    $newDN = $strDN.replace("/","\/")
    return $newDN
}

function export-results
{
    Param
    (
        $forestGroupList
    )

    $outputArray = @()

    foreach ($domainKey in $forestGroupList.keys)
    {
        $domainName = $domainkey
        $domainGroupList = $forestGroupList.$domainKey

        foreach ($group in $domainGroupList.keys)
        {
            $outputArray += $domainGroupList.$group | Select-Object `
            @{e={$_.ContainingDomain};n="Domain"},
            @{e={$_.Name};n="Group Name"},
            @{e={$_.DistinguishedName};n="Group DN"},
            @{e={$_.MemberName};n="Member Name"},
            @{e={$_.SAMAccountName};n="Member SAMAccountName"},
            @{e={$_.MemberType};n="Member Type"},
            @{e={$_.MemberDN};n="Member DN"},
            @{e={$_.MemberDisplayName};n="Member Display Name"},            
            @{e={$_.MemberDescription};n="Member Description"},
            @{e={$_.MemberAdminCount};n="Member AdminCount"},
            @{e={$_.MemberUAC};n="Member UserAccountControl"},
            @{e={$_.ADSAParentGroupDN};n="Nested Group Membership DN(s)"},
            @{e={$_.ADSAParentGroupName};n="Nested Group Membership(s)"}
        }
    }

    $outputArray | `
        sort-object -property Domain,'Group Name','Member Type','Member Name' | `
        Export-Csv -NoTypeInformation "$($filePrefix)_GroupMembership.csv"

    $userOutputArray = @()   
    
    
    foreach ($object in $outputArray)
    {    
        if ($object.'Nested Group Membership DN(s)' -eq $null)
        {
            $userEntry = New-Object psobject

            $userEntry | Add-Member NoteProperty Domain $object.domain
            $userEntry | Add-Member NoteProperty "Group Name" $object.'Group Name'
            $userEntry | Add-Member NoteProperty "Nested Group" ""
            $userEntry | Add-Member NoteProperty "Nested Group DN" ""
            $userEntry | Add-Member NoteProperty "AccountGroup" $object.'Member Name'
            $userEntry | Add-Member NoteProperty SamAccountName $object.'Member SAMAccountName'
            $userEntry | Add-Member NoteProperty 'Member DN' $object.'Member DN' 
            $userEntry | Add-Member NoteProperty 'Member Display Name' $object.'Member Display Name'
            $userOutputArray += $userEntry
        }
        else
        {
            $nestedgroups = ($object.'Nested Group Membership(s)').split("|")
            $nestedgroupDNs = ($object.'Nested Group Membership DN(s)').split("|")
            
            for ($i = 0; $i -lt $nestedgroups.count; $i++)
            {
                $userEntry = New-Object psobject

                $userEntry | Add-Member NoteProperty Domain $object.domain
                $userEntry | Add-Member NoteProperty Group $object.'Group Name'
                if ($nestedgroupDNs[$i] -eq $object.'Group DN')
                {
                    $userEntry | Add-Member NoteProperty "Nested Group" ""
                    $userEntry | Add-Member NoteProperty "Nested Group DN" ""
                }
                else
                {
                    $userEntry | Add-Member NoteProperty "Nested Group" $nestedgroups[$i]
                    $userEntry | Add-Member NoteProperty "Nested Group DN" $nestedgroupDNs[$i]
                }
                $userEntry | Add-Member NoteProperty "Account/Group" $object.'Member Name'
                $userEntry | Add-Member NoteProperty SamAccountName $object.'Member SAMAccountName'
                $userEntry | Add-Member NoteProperty 'Member DN' $object.'Member DN'   
                $userEntry | Add-Member NoteProperty 'Member Display Name' $object.'Member Display Name'
                
                $userOutputArray += $userEntry              
            }
        }   
    }
    $userOutputArray | `
        Sort-Object -Property Domain,Group,"Account/Group","Nested Group" |`
        Export-Csv -NoTypeInformation "$($filePrefix)_GroupMembership_Users.csv"             
}
    
####### MAIN FUNCTION #######

# Get the list of custom groups to collect against
if ($filepath) { if (test-path $filepath) { $customgroups = Import-CustomGroups $filepath } }

# Create a hashtable. Each key will be a domain, with the value a hashtable of groups
$forestGroupList = @{}
foreach ($domainObj in $domains_detail)
{
    #Get the groups for the domain
    
    #Get custom groups
    $domaincustomgroups = $customgroups | ? { $_.domain -eq $domainObj.domain }

    $grouplist = Get-DomainPrivilegedGroups $domainObj.domainDN -additionalGroupNames $domaincustomgroups.groupname

    # Create a hashtable. Each key will be a group, with the value an array of objects representing group members
    $domainGroupList = @{}
    foreach ($group in $grouplist)
    {
        Write-Verbose "Collecting membership for group: $($group.name)"
        if ($group.DistinguishedName -eq "< GROUP DOES NOT EXIST IN DOMAIN >") # Non-existant group
        {
           $domainGroupList.Add($group.name,$group)
        }
        elseif ($group.member.count -eq 0) # Empty Group, no need to recurse
        {
            $memberObj = New-Object PSObject

            $memberObj | Add-Member NoteProperty ContainingDomain $domainObj.domain
            $memberObj | Add-Member NoteProperty Name $($group.name)
            $memberObj | Add-Member NoteProperty DistinguishedName $($group.distinguishedname)
            $memberObj | Add-Member NoteProperty MemberName "< GROUP CONTAINS NO MEMBERS >"
            $memberObj | Add-Member NoteProperty SAMAccountName $null
            $memberObj | Add-Member NoteProperty MemberType $null
            $memberObj | Add-Member NoteProperty MemberDN $null  
            $memberObj | Add-Member NoteProperty ADSAParentGroupDN $null
            $memberObj | Add-Member NoteProperty ADSAParentGroupName $null
            $memberObj | Add-Member NoteProperty MemberAdminCount 0
            $memberObj | Add-Member NoteProperty MemberUAC $null
            $memberObj | Add-Member NoteProperty MemberDisplayName $null
            $memberObj | Add-Member NoteProperty MemberDescription $null

            $domainGroupList.Add($($group.name),$memberObj)
        }
        else
        {
            $members = Get-GroupMembersRecursive -rootgroupname $($group.name) -rootgroupdn $($group.distinguishedname) -group $group -domain $domainObj.domain
            $domainGroupList.add($($group.name),$members)
        }
    }
    $forestGroupList.add($domainobj.domain,$domainGroupList)
}

export-results $forestGroupList