﻿[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

if ($Standalone) 
{ 
    Write-Verbose "Running in standalone mode..." 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }
} 


# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

$rootdse = new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
$config = $($rootdse.configurationNamingContext)
$sitescontainer = "LDAP://CN=Sites,$config"
$sitelinkcontainer = "LDAP://CN=Inter-Site Transports,CN=Sites,$config"
$subnetscontainer = "LDAP://CN=Subnets,CN=Sites,$config"

# Get sites
Write-Verbose "Gathering list of Active Directory Sites" 
$searcher = New-Object System.DirectoryServices.DirectorySearcher
$searcher.SearchRoot = $sitescontainer
$searcher.SearchScope = "OneLevel"
$searcher.filter = "objectClass=site"
$searcher.SizeLimit = 0
$searcher.PageSize = 1000
$SiteCol = $searcher.findall()

# Process Sites
Write-Verbose "Processing site list"
$sitedetails = @()
$siteGPOs = @()
foreach ($site in $SiteCol)
{
    $sitename = $($site.properties.name)
    Write-Verbose "Processing site: $sitename"
    $sitedescription = $($site.properties.description)   
    
    # Get the list of servers that have NTDS Settings Objects (i.e. domain controllers)
    $searcher.SearchRoot = $site.path
    $searcher.SearchScope = "Subtree"
    $searcher.filter = "objectClass=nTDSDSA"
    $siteNTDDSACol = $searcher.FindAll()

    $siteservers = $siteNTDDSACol | % { [adsi]([adsi]$_.path).parent }
    
    foreach ($server in $siteservers)
    {
        $serverObj = New-Object psobject
        $serverObj | Add-Member NoteProperty 'Site Name' $sitename
        $serverObj | Add-Member NoteProperty 'Site Description' $sitedescription
        $serverObj | Add-Member NoteProperty 'Server Name' $($server.properties.dnshostname)

        $sitedetails += $serverObj
    }

    # Get GPOs linked to each site
    if ($site.properties.gplink) # Only operate on Sites with a GPLink attribute
    {
        $gpolist = $($site.Properties.gplink.replace("[","").split("]",[System.StringSplitOptions]"RemoveEmptyEntries"))
        
        # Check for the case that $gpolist is an empty string or consists only of whitespace or is null
        # This handles the case where the gplink attribute exists but doesn't actually contain any GPOs
        if ($gpolist -eq "" -or $gpolist -eq $null  -or $gpolist -match "^\s+$") {continue} 
        foreach ($gpo in $gpolist)
        {
            if ($gpo -eq "" -or $gpo -eq $null -or $gpo -match "^\s+$") {continue} # This should never be true; it's here in case the RemoveEmptyEntries option doesn't work right
            $gpolink = $gpo.split(";")[0]
            $gpoattr = $gpo.split(";")[1]
            #Check for existance of the GPO
            try
            {
                if ([adsi]::Exists($gpolink)) # 12/15/16 Added a check that the LDAP path in gplink actually exists
                {
                    $displayname = ([adsi]$gpolink).displayName
                    $dn = ([adsi]$gpolink).distinguishedName
                }
                else
                {
                    $displayname = "< LINKED GPO DOES NOT EXIST IN THE DIRECTORY >"
                    $dn = $gpolink.substring(7) # Strip LDAP:// from the beginning of the DN path
                }
            }
            catch
            {
                $displayname = "< LINKED GPO IS NOT A VALID LDAP PATH >"
                $dn = $gpolink
            }
            switch ($gpoattr)
            {
                0 { $LinkEnabled = $true ; $Enforce = $false }
                1 { $LinkEnabled = $false ; $Enforce = $false }
                2 { $LinkEnabled = $true ; $Enforce = $true }
                3 { $LinkEnabled = $false ; $Enforce = $false }
            }
            $sitegpo = new-object psobject
            $sitegpo | Add-Member NoteProperty Site $sitename
            $sitegpo | Add-Member NoteProperty "GPO Name" $($displayname)
            $sitegpo | Add-Member NoteProperty "GPO DN" $($dn)
            $sitegpo | Add-Member NoteProperty "Link Enabled" $LinkEnabled
            $sitegpo | Add-Member NoteProperty "Enforced" $Enforce
            $siteGPOs += $sitegpo
        }
    }

}

# Get Site Links
Write-Verbose "Gathering list of Sitelinks" 
$searcher.searchroot = $sitelinkcontainer
$searcher.searchscope = "Subtree"
$searcher.filter = "objectClass=sitelink"
$SiteLinkCol = $searcher.FindAll()

# Process Site Links
Write-Verbose "Processing sitelink list" 
$sitelinkdetails = @()
foreach ($sitelink in $SiteLinkCol)
{
    $SLname = $($sitelink.properties.name)
    Write-Verbose "Processing sitelink: $SLname"
    $SLtype = $($sitelink.Properties.distinguishedname).Split(",")[1].replace("CN=","")
    $cost = $($sitelink.properties.cost)
    $options = $($sitelink.properties.options)
    if ($options -notmatch "\d+") { $options = 0 }
    $interval = $($sitelink.properties.replinterval)
    try
    {
        $SLsitelist = ""
        $SLsitelist += $sitelink.Properties.sitelist | % {$_.split(",")[0].replace("CN=","");"|"}
    }
    catch { $SLsitelist = "< MISSING SITE ASSIGNMENT >" }
    $sitecount = $sitelink.properties.sitelist.count


    $SLObj = New-Object psobject
    $SLObj | Add-Member NoteProperty 'Site Link Name' $SLname
    $SLObj | Add-Member NoteProperty Cost $cost
    $SLObj | Add-Member NoteProperty Options $options
    $SLObj | Add-Member NoteProperty 'Replication Interval' $interval
    $SLObj | Add-Member NoteProperty 'Site List' $SLsitelist.TrimEnd("|")
    $SLObj | Add-Member NoteProperty 'Member Count' $sitecount


    $sitelinkdetails += $SLObj
}

# Get Subnets
Write-Verbose "Gathering list of Subnets"
$searcher.searchroot = $subnetscontainer
$searcher.SearchScope = "OneLevel"
$searcher.filter = "objectClass=subnet"
$searcher.cacheresults = $true # Changed 12/15/16. Bug 1663724. Previously set to false, which caused $subnetcol to empty after the first time it was used.
$SubnetCol = $searcher.FindAll()
Write-verbose "Found $($subnetcol.count) subnets"

# Process Subnets
Write-Verbose "Processing subnet list"
$subnetdetails = @()
foreach ($subnet in $SubnetCol)
{
    $subnetName = $($subnet.properties.name)
    Write-Verbose "Processing subnet: $subnetName"
    $location = $($subnet.properties.location)
    $description = $($subnet.properties.description)
    try { $subnetsiteName = $($subnet.properties.siteobject).split(",")[0].replace("CN=","") }
        catch { $subnetsiteName = "< MISSING SITE ASSIGNMENT >" }
    
    $SubnetObj = New-Object psobject
    $SubnetObj | Add-Member NoteProperty 'Subnet Name' $subnetName
    $SubnetObj | Add-Member NoteProperty Description $description
    $SubnetObj | Add-Member NoteProperty Location $location
    $SubnetObj | Add-Member NoteProperty 'Site Name' $subnetsitename

    $subnetdetails += $SubnetObj
}

$sitedetails | Export-Csv -NoTypeInformation "$($filePrefix)_Sites.csv"

if ($sitegpos) { $siteGPOs | Export-Csv -NoTypeInformation "$($filePrefix)_SiteLinkedGPOs.csv" }

$sitelinkdetails | Export-Csv -NoTypeInformation "$($filePrefix)_SiteLinks.csv"

$subnetdetails | Export-Csv -NoTypeInformation "$($filePrefix)_Subnets.csv"




