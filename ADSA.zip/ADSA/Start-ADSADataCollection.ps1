﻿<#
.SYNOPSIS             
Collect ADSA Data

.DESCRIPTION   
Run a full data collection for the forest.         

.PARAMETER  ConfigFile
Configuration file that specifies which data collection tasks to run. The config file is a comma-seperated value file in the format below.
Specify TRUE or FALSE for each task. The default name of the file is configs.csv.

    Name,Value
    SpecifyCreds,FALSE
    ForestInfo,TRUE
    DNS,TRUE
    DSACLs,TRUE
    GroupMembership,TRUE
    GPO,FALSE
    OUs,TRUE
    StaleAccts,TRUE
    Sites,TRUE
    EmptyOUs,TRUE
    EmptyGroups,TRUE
    RevEnc,TRUE
    TrustedForDelegation,TRUE
    OUTree,TRUE
    SoftwareServices,TRUE
    ShareACLs,TRUE
    NTFSAcls,TRUE
    DCDrives,TRUE
    WuSettings,FALSE
    DCQFEs,TRUE
    IESecurityZones,TRUE
    Trusts,TRUE
    PasswordConfig,TRUE
    UserInfo,TRUE

.PARAMETER UseAlternateCredentials
Indicates that the user will enter an alternate set of credentials for each task.

.PARAMETER SelectChecksToRun
Indicates that the user will interactively select which data collection tasks to run.

.PARAMETER OutputFolder
Specify a custom folder for data output. Default is a subfolder of the scripts folder named Output\ADSARun-DD-MMM-YYYY-HH.MM.

.PARAMETER CustomFiles
Specify the path to a CSV file containing information on how select tests should be customized. The format is shown below for the four tasks that allow custom input.
For each task, the CSV file lists the variable name, whether to use the custom file (TRUE/FALSE), and the path to the file
    
    Variable,Use,Path
    CustomACLFile,TRUE,.\CUSTOMACL.TXT
    CustomGroupFile,TRUE,.\CUSTOMGROUP.TXT
    CustomLocalAdminFile,FALSE,.\LOCALADMINS.TXT
    OmitDomains,FALSE,.\OMITDOMAINS.TXT

.PARAMETER SkipPreChecks

#>
[CmdletBinding()]
Param(
    [Parameter(Mandatory=$false)][string]$ConfigFile=".\Configs.csv",
    [Parameter(Mandatory=$false)][Switch]$UseAlternateCredentials,
    [Parameter(Mandatory=$false)][Switch]$SelectChecksToRun,
    [Parameter(Mandatory=$false)][string]$OutputFolder = "Output\" + $("ADSARun-" + (Get-Date -uformat "%d-%b-%Y-%H.%M")) + "\",
    [Parameter(Mandatory=$false)][string]$CustomFiles = ".\CustomFiles.csv",
    [Parameter(Mandatory=$false)][switch]$SkipPreChecks,
    [Parameter(Mandatory=$false)][string]$LogFileName = $("ADSARun-" + (Get-Date -uformat "%d-%b-%Y-%H.%M") + "-Log.txt"),
    [Parameter(Mandatory=$false)][switch]$Quiet
)

# Default to verbose preference = 'Continue' unless 'Quiet' argument is passed.
if (! $Quiet ) { $VerbosePreference = 'Continue' } else { $VerbosePreference = 'SilentlyContinue' }

# Make sure that we are on at least Version 3 of PowerShell
if ($psversiontable -eq $null -or $PSVersionTable.PSVersion.Major -lt 3)
{
    # We are on a lower version of PowerShell
    $errorstring = "PowerShell Version must be 3 or higher for scripts to run successfully. `nPlease download and install Windows Management Framework version 3.0 or higher. `nThe download location is http://www.microsoft.com/en-us/download/details.aspx?id=34595"
    $exception = new-object System.Exception($errorstring)
    $errorID = "ADSAInsufficientPSVersion"
    $errorcat = [System.Management.Automation.ErrorCategory]"NotInstalled"
    $versionerror = New-Object System.Management.Automation.ErrorRecord($exception,$errorID,$errorcat,$PSVersionTable.PSVersion)
    throw $versionerror
}

#Import supporting functions
Try 
{
    Import-Module .\ADSA.psm1
}
Catch
{
    $errorstring = "ADSA required module not loaded."
    $exception = new-object System.Exception($errorstring)
    $errorID = "ADSAModuleLoadFailure"
    $errorcat = [System.Management.Automation.ErrorCategory]"ResourceUnavailable"
    $moduleerror = New-Object System.Management.Automation.ErrorRecord($exception,$errorID,$errorcat,'.\ADSA.psm1')
    throw $moduleerror 
}

#set the Window title to ADSA
$Host.UI.RawUI.WindowTitle = "$($Host.UI.RawUI.WindowTitle.split(':')[0]) : ADSA" 

#Initialize the environment and output locations
$ScriptPath = Initialize-ADSAOutput $OutputFolder
$OutputPath = "$ScriptPath\$OutputFolder"
$filePrefix = ([System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()).name.toUpper().split('.')[0]
$TasksToRun = Initialize-ADSATasks 

#Check Prereqs
if ( $SkipPreChecks -ne $true )
{
    $Prereqs =  Test-ADSAServerPrereq
    if ($Prereqs -eq $false) 
    {
       Write-Warning "Some Prerequisites were not met. Data collection may be impacted."
       # throw "Pre Requirements are not fulfilled" 
    }
}

#make a transcript of the session for reference and/or troubleshooting
Start-Transcript -Path ".\ADSA-Transcript_$(get-date -Format "MM-dd-yyyy_hh.mm.ss").rtf" | Out-Null 

$TasksToRun =  Set-ADSAOptions $TasksToRun $ScriptPath $ConfigFile $UseAlternateCredentials.ToBool() $SelectChecksToRun.ToBool() $CustomFiles

Measure-Command {
Write-Host "`n   ###    ########   ######     ###    
  ## ##   ##     ## ##    ##   ## ##   
 ##   ##  ##     ## ##        ##   ##  
##     ## ##     ##  ######  ##     ## 
######### ##     ##       ## ######### 
##     ## ##     ## ##    ## ##     ## 
##     ## ########   ######  ##     ## 
`n`n[][][][] Starting ADSA Extraction [][][][]`n"

# Get information on the domains and domain controllers for use by other tests
$DC_detail = Get-ADSATargetDCs -omitDomains $TasksToRun[0].CustomFiles 
$domains_detail = Get-ADSATargetDomains -omitDomains $TasksToRun[0].CustomFiles 

#Pre-requirements for network connections per DC (SMB, WMI, Remote Registry, LDAP - all per machine)
# SkipPreChecks if there are more than 50 DCs
if ($dc_detail.count -gt 50) 
{ 
    write-verbose "Due to large DC count, skipping connectivity checks for individual domain controllers."
    $skipPreChecks = $true 
}
if ( $SkipPreChecks -ne $true )
{
    $Prereqs =  Test-ADSANetConnection -DCs $DC_detail
    if ($Prereqs -eq $false) 
    {
        Write-Warning "Not all DCs were reachable. There may be some gaps in data collection." 
    }
}

# Start running the data collection tasks. Run each task as a job

# First remove all pre-existing jobs
remove-job *

Write-Verbose "Starting data collection tasks"

foreach ($task in $TasksToRun)
{
    if ($task.RunTask)
    {
        Write-Verbose "`tStarting task:  $($task.TaskName)"
        if ($task.CustomCreds)
        { start-job -name "ADSA$($task.TaskName)" -FilePath "$ScriptPath\Get-ADSA$($task.TaskName).ps1" -Credential $task.CustomCreds -initializationscript { $VerbosePreference = 'Continue' } -ArgumentList $domains_detail,$DC_detail,$filePrefix,$OutputPath,$task.CustomFiles }
        else
        { start-job -name "ADSA$($task.TaskName)" -FilePath "$ScriptPath\Get-ADSA$($task.TaskName).ps1" -initializationscript { $VerbosePreference = 'Continue' } -ArgumentList $domains_detail,$DC_detail,$filePrefix,$OutputPath,$task.CustomFiles }
    }
}

$jobsinitiated = (get-job -name "ADSA*").count
$jobsfinished = 0
$jobswitherror = 0

Write-Verbose "$jobsinitiated tasks started.`n"

$finishedlist = @()

do 
{
    sleep 1
    $joblist = get-job -name "ADSA*"
    
    $finishedjobs = $joblist | Where-Object {$_.state -eq "Completed" -or $_.state -eq "Failed"}
    
    $jobsrunning = ($joblist | ? state -eq "Running").count
    $jobscompleted = ($joblist | ? state -eq  "Completed").count
    $jobsfailed = ($joblist | ? State -eq "Failed").count

    if ($jobsinitiated -gt 0) # Avoid Div/0 errors
    {
        Write-Progress -Activity "Running ADSA data collection tasks" -Status "$jobsinitiated tasks started; $jobscompleted finished" -PercentComplete ((($jobscompleted + $jobsfailed)/$jobsinitiated) * 100)
    }

    foreach ($job in $finishedjobs)
    {
        if ($finishedlist -notcontains $job.id) 
        {
            Write-verbose "$($job.name) $($job.State)"
            if ($job.hasmoredata) 
            { 
                "`r`n################`r`nBEGIN DATA FROM $($job.name)`r`n" | out-file ".\$LogFileName" -Append
                $job.ChildJobs[0].output.readall() | out-file ".\$LogFileName" -Append
                $job.ChildJobs[0].verbose.readall() | out-file ".\$LogFileName" -Append
                $job.ChildJobs[0].warning.readall() | out-file ".\$LogFileName" -Append
                $job.ChildJobs[0].error.readall() | out-file ".\$LogFileName" -Append                
                "`r`nEND DATA FROM $($job.name)`r`n################`r`n"| out-file ".\$LogFileName" -Append
            }
                
            $finishedlist += $job.id
        }
    }  
         
    

} until ($jobsrunning -eq 0)

Write-Verbose "`n`n$jobsinitiated tasks started.`n$jobscompleted tasks completed.`n$jobsfailed tasks failed."

} # End measure-command

Stop-Transcript
