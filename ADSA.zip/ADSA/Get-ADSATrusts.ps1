﻿<#
.SYNOPSIS
Get information about trusts in the Active Directory forest and domains.

.DESCRIPTION
Collect trust information from the target Active Directory forest and all member
domains.

.PARAMETER domains_detail
Array of objects representing properties of each domain

.PARAMETER All_DCs
Array of objects representing properties of each domain controller

.PARAMETER filePrefix
Prefix to use for file names (typically shortname of forest root domain

.PARAMETER OutputPath
Path to write CSV files

.PARAMETER FilePath
Path to custom files

.EXAMPLE

.INPUTS
None

.OUTPUTS
<ForestName>_Trusts.csv

.NOTES
Created by Microsoft ISRM ACE team for use as part of data collection for Active Directory Security Assessment.
Version 2.0

#>

[CmdletBinding()]
Param
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

# Make sure we're in the OutputPath folder (this is important when running as a job
cd $OutputPath

# Get the current forest
$current_forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
$domains = $current_forest.domains

$All_Trusts = @()

#get all trust relationships
$foresttrusts = $current_forest.getalltrustrelationships()
    
#this holds all the trusts for the forest
$forestTrustsArr = @()
    
#for all the trusts found...
foreach ($ftrust in $foresttrusts)
{
        
    # Create a Trust Object to hold the forest trust info
    $TrustObj = New-Object PSObject
        
    #trust info
        #this is data from the **forest**
    $TrustObj | Add-Member NoteProperty Source $ftrust.sourcename
    $TrustObj | Add-Member NoteProperty Target $ftrust.targetname
    $TrustObj | Add-Member NoteProperty TrustType $ftrust.trusttype
    $TrustObj | Add-Member NoteProperty TrustDirection $ftrust.trustdirection
    $TrustObj | Add-Member NoteProperty SidFilteringStatus $current_forest.GetSidFilteringStatus($ftrust.targetname)
    $TrustObj | Add-Member NoteProperty SelectiveAuthStatus $current_forest.GetSelectiveAuthenticationStatus($ftrust.targetname)
        
    #add this trust to the collection of all trusts
    $ALL_Trusts += $TrustObj
}#end trusts loop

#loop for all the domains...
foreach ($domain in $domains)
{
    $domaintrusts = $domain.getalltrustrelationships()

    #this holds all the trusts per domain
    $domainTrustsArr = @()

    #loop through trusts
    foreach ($dtrust in $domaintrusts)
    {
        rv TrustObj -ErrorAction silentlycontinue
        # Create a Trust Object to hold the domain trust info
        $TrustObj = New-Object PSObject
        
        #trust info
            #this is data from **domains**
        $TrustObj | Add-Member NoteProperty Source $dtrust.sourcename
        $TrustObj | Add-Member NoteProperty Target $dtrust.targetname
        $TrustObj | Add-Member NoteProperty TrustType $dtrust.trusttype
        $TrustObj | Add-Member NoteProperty TrustDirection $dtrust.trustdirection
        Try{$TrustObj | Add-Member NoteProperty SidFilteringStatus $Domain.GetSidFilteringStatus($dtrust.targetname)}Catch{$TrustObj | Add-Member NoteProperty SidFilteringStatus $False}
        Try{$TrustObj | Add-Member NoteProperty SelectiveAuthStatus $Domain.GetSelectiveAuthenticationStatus($dtrust.targetname)}Catch{$TrustObj | Add-Member NoteProperty SelectiveAuthStatus $False}
        
        #add this trust to the collection of all trusts
        $ALL_Trusts += $TrustObj
    }
}

$ALL_Trusts | Select-Object `
                    @{e={$_.source};n="Source"},`
                    @{e={$_.target};n="Trust Partner"},`
                    @{e={$_.trusttype};n="Trust Type"},`
                    @{e={$_.trustdirection};n="Trust Direction"},`
                    @{e={if($_.SidFilteringStatus){"Yes"}else{"No"}};n="SID Filtering Enabled"},`
                    @{e={if($_.SelectiveAuthStatus){"Yes"}else{"No"}};n="Selective Auth Enabled"} `
                | Export-Csv -NoTypeInformation "$($filePrefix)_Trusts.csv"

