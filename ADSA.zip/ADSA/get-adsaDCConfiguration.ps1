﻿<#
.SYNOPSIS
Collect configuration information from each domain controller
#>
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DCList = $null, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null,   

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null,
    [Parameter(mandatory=$false,Position=6)][switch]$verboseOutput
)

# Make sure we're in the OutputPath folder (this is important when running as a job)
$OutputPath = (Get-ItemProperty $outputpath).FullName
cd $OutputPath

if ($Standalone) 
{ 
    if (!($fileprefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }
    if (!($DCList))
    {
        Import-Module .\ADSA.psm1
        $All_DCs = Get-ADSATargetDCs -omitDomains $omitDomains -verboseOutput
        $DCList = $All_DCs | Select-Object -ExpandProperty fqdn
    } 
} 
else
{
    $DCList = $All_DCs | Select-Object -ExpandProperty fqdn
}

if ($verboseOutput) { write-host "List of DCs to collect configuration from:`n`t$DCList" }

# This workflow gathers a number of settings from each of a group of domain controllers
workflow get-ConfigSettings ($DCs,$outputpath)
{ 
    <#
        .SYNOPSIS 
        Get the value of a registry entry in the HKLM hive
    #>
    function Get-RegistrySetting ($computer,$Key,$value)
    {
        $Hive = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine',$computer)
        $Reg = $Hive.opensubkey($Key)
        if ($Reg) 
        { 
            $Setting = $Reg.getvalue($Value) 
            $Reg.close() 
        }
        $Hive.close()
        return $Setting
    }    

    <#
        .SYNOPSIS
        Get the NTFS ACL for a given file or folder path on a given domain controller
    #>
    Function Get-ACLInfo ($NTFSPath, $dcname)
    {
        <#
            .SYNOPSIS
            Given an NTFS path and the name of a computer (DC), convert to a UNC path. Performs minimal path checking.
        #>
        function ConvertTo-UNCPath ($NTFSPath, $dc)
        {
            # Make sure we have a an NTFS path that starts with driveletter:
            $NTFSRegex = "^\p{Ll}:" 
            if ($ntfspath -match $ntfsregex)
            {
                $drive = $NTFSPath.substring(0,1)
                $UNC = $NTFSPath.replace("$drive`:","\\$dc\$drive$")
            }
            else
            {
                Write-Error "Input parameter is not a valid NTFS path. Conversion failed."
                $UNC = $null
            }
            return $UNC
        }
        
        $UNCPath = ConvertTo-UNCPath $NTFSPath $dcname
        $ACLInfo = get-acl $UNCPath -audit
        return $ACLInfo
    }
    
    # Define an array to hold configuration information
    $Config = @()
    
    # Configure path for Group Policy
    $gpresultpath = "$outputpath\gpresult"
    if (!(test-path $gpresultpath)) { new-item -path $outputpath -name "GPResult" -itemtype directory }

    # Setup a set of custom objects for each DC
    foreach ($dc in $DCs)
    {
        $DCConfig = new-object PSObject
        Add-Member -name Domain -type NoteProperty -value ($dc.split(".",2)[1]) -inputobject $dcconfig
        Add-Member -name DCName -type NoteProperty -Value $dc.split(".")[0] -inputobject $dcconfig
        Add-Member -name FQDN -type NoteProperty -value $dc -inputobject $dcconfig
        $config += $dcconfig
    }
    
    # Collect a bunch of data from each DC in the config array (in parellel!)
    ForEach -Parallel ($thisdc in $config)
    {
        $i = $config.indexof($thisdc) # Not sure that this variable is actually used
        $dc = $thisdc.fqdn
        $dcname = $thisdc.dcname
        
        # Run the following sets of commands in parellel      
        Parallel
        {            
            # This sequence uses the Windows Update API to scan for missing hotfixes on the target DC.
            Sequence
            {
                $dcupdates = InlineScript # Using an inline script due to limitations of calling APIs, etc. within a workflow
                {
                    $targetdc = $using:dc # Define the target DC. Using keyword is required to reference an object outside the InlineScript                  
                    $cabtarget = "c:\windows\temp\wsusscn2.cab" # Path where wsusscn2.cab will be copied on the target DC. This file is required for offline scanning.
                    $localcab = "c:\adsa\wsusscn2.cab" # Path of wsusscn2.cab on assessment server.  
                    $remotecab = "\\$targetdc\c$\windows\temp\wsusscn2.cab" # UNC path where the wsusscn2.cab will be copied. This is the UNC version of $cabtarget
                    # Make sure that the cab file is available; break out of the inline script if it isn't
                    if (test-path $localcab) 
                    {
                        copy $localcab $remotecab
                    }
                    else
                    {
                        break
                        # TODO: Code here to attempt to download wsusscn2.cab from the web
                    }
                    
                    # Get ready to create a remote WUA session
                    $remotesession = [system.type]::GetTypeFromProgID("microsoft.update.session", $targetdc)
                    # Create and connect to a remote WUA session
                        # The connection to a remote session requires the following firewall exceptions. 
                        # Need to enable one standard firewall rule, plus allow inbound dynamic RPC. This is basically the same as what MBSA would require.                 
                        # COM+ Network Access (DCOM-In). The line below could be run locally on the DC to enable the rule
                            # Get-NetFirewallRule -displayname "COM+ Network Access (DCOM-In)" | Set-NetFirewallRule -Enabled true
                        # Local port: Dynamic RPC; Remote port: All; Protocol number: 6 (TCP); Executable: %windir%\system32\dllhost.exe; Remote privilege: Administrator
                        # The line below could be run locally on the DC to create a new rule for this
                            # new-netfirewallrule -displayName "Allow inbound RPC for WUA" -Direction Inbound -LocalPort RPC -Protocol 6 -Action Allow -program "$env:windir\system32\dllhost.exe"
                    $updatesession = [System.Activator]::CreateInstance($remotesession)        
                    $updateservicemanager = $updatesession.createupdateservicemanager()
                    # Add the offline scanner to the WUA session
                    $updateservice = $updateservicemanager.AddScanPackageService("Offline Sync Service",$cabtarget)
                    # Create a searcher
                    $updatesearcher = $updatesession.CreateUpdateSearcher()
                    # Pick the WU server to use (Other in this case, since we don't actually want to connect to WU)
                    $UpdateSearcher.ServerSelection = 3 # ssOthers
                    $UpdateSearcher.ServiceID = $UpdateService.ServiceID
                    # This line actually does work (finally!). It searches for all applicable updates that are not installed. 
                    # For other search options, see https://msdn.microsoft.com/en-us/library/windows/desktop/aa386526(v=vs.85).aspx
                    $searchresult = $updatesearcher.Search("IsInstalled=0")
                    $updates = $searchresult.Updates
                    
                    # Array to hold information about each update
                    $updatelist = @()
                    if ($Updates.Count -ne 0)
                    {
                        foreach ($update in $updates)
                        {
                            $updateobj = new-object psobject
                            $updateobj | Add-Member NoteProperty Domain $targetdc.split(".",2)[1]
                            $updateobj | Add-Member NoteProperty "DC Name" $targetdc.split(".",1)
                            $updateobj | add-member noteproperty Title $update.title
                            $updateobj | add-member noteproperty KBArticle ( $update | select KBArticleIDs | % {$_.kbarticleids} )
                            $updateobj | add-member noteproperty SecurityBulletin ( $update | select SecurityBulletinIDs | % { $_.securityBulletinIDs } )
                            $updatelist += $updateobj
                        }    
                    }
                    # Return the array out of the inlinescript                    
                    return $updatelist
                } # End InlineScript             
                # Put the UpdateList array into the Config object for the current DC
                add-member -membertype noteproperty -name UpdateInfo -value $dcupdates -inputobject $thisdc
            } # End Update Info Sequence


            # Get XML RSOP
            $null = get-gpresultantsetofpolicy -computer $dc -reporttype xml -path "$gpresultpath\$dcname.xml"

            # Get HTML RSOP
            $null = get-gpresultantsetofpolicy -computer $dc -reporttype html -path "$gpresultpath\$dcname.html"

            Sequence # Run secedit.exe to export the group policy settings
            {                
                # Command to run
                $seceditstring = "c:\windows\system32\secedit.exe /export /cfg c:\windows\temp\$dcname.inf"                
                # Invoke WMI to create a process on the remote DC. Output to a throwaway variable
                $null0 = Invoke-WMIMethod -Class Win32_Process -Name Create -pscomputer $dc -ArgumentList $seceditstring
                # Make sure the command above has time to run
                sleep 10             
                # Copy the output back to the assessment server
                Copy-Item "\\$dc\c`$\windows\temp\$dcname.inf" "$gpresultpath\$dcname.inf"                                           
            } # End Secedit sequence

            Sequence # Run auditpol.exe to export audit settings
            {               
                # auditpol.exe /backup won't overwrite an existing file
                # TODO: add code to check for file existance and attempt to delete
                # Command to run
                $auditpolstring = "auditpol /backup /file:c:\windows\temp\$dcname.csv"
                # Invoke WMI to create a process on the remote DC. Output to a throwaway variable
                $null0 = Invoke-WMIMethod -Class Win32_Process -Name Create -pscomputer $dc -ArgumentList $auditpolstring
                # Make sure the command above has time to run
                sleep 10
                # Copy the output back to the assessment server
                Copy-Item "\\$dc\c`$\windows\temp\$dcname.csv" "$gpresultpath\$dcname.csv"                                
            } # End Auditpol sequence

            Sequence # Collect Custom Password Filter information
            {
                # Get the registry key that holds password filter data
                $PwFilter = Get-RegistrySetting $dc 'SYSTEM\CurrentControlSet\Control\Lsa' 'Notification Packages'
                Add-Member -name PasswordFilter -membertype NoteProperty -value $PwFilter -inputobject $thisdc
            } # End Password Filter Sequence
            
            Sequence # Get directory location and ACLs for Windows Directory
            {
                $windir = (Get-WmiObject -ComputerName $dc -query "Select WindowsDirectory from win32_operatingsystem").windowsdirectory
                add-member -name WinDirPath -membertype NoteProperty -value $windir -inputobject $thisdc
                $aclinfo = Get-ACLInfo $windir $dc
                add-member -name WinDirACL -membertype NoteProperty -value $aclinfo -inputobject $thisdc
            }
                
            Sequence # Get directory location and ACLs for System32 Directory
            {
                $system32dir = (Get-WmiObject -ComputerName $dc -query "Select SystemDirectory from win32_operatingsystem").systemdirectory
                add-member -name System32Path -membertype NoteProperty -value $system32dir -inputobject $thisdc
                $aclinfo = Get-ACLInfo $system32dir $dc
                add-member -name System32ACL -membertype NoteProperty -value $aclinfo -inputobject $thisdc
            }
                
            Sequence # Get directory location and ACLs for NTDS Logs Directory
            {
                $NTDSLogPath = Get-RegistrySetting $dc 'SYSTEM\CurrentControlSet\Services\NTDS\Parameters' 'Database log files path'
                add-member -name NTDSLogPath -membertype NoteProperty -value $NTDSLogPath -inputobject $thisdc
                $aclinfo = Get-ACLInfo $NTDSLogPath $dc
                add-member -name NTDSLogACL -membertype NoteProperty -value $aclinfo -inputobject $thisdc
            }
            
               
            Sequence # Get directory location and ACLs for NTDS DB File (ntds.dit)
            {
                $NTDSDBPath = Get-RegistrySetting $dc 'SYSTEM\CurrentControlSet\Services\NTDS\Parameters' 'DSA Database file'
                add-member -name NTDSDBPath -membertype NoteProperty -value $NTDSDBPath -inputobject $thisdc
                $aclinfo = Get-ACLInfo $NTDSDBPath $dc
                add-member -name NTDSDBACL -membertype NoteProperty -value $aclinfo -inputobject $thisdc
            }
                
            Sequence # Get directory location and ACLs for Sysvol Directory
            {
                $SYSVOLPath = Get-RegistrySetting $dc 'SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' 'Sysvol'
                add-member -name SYSVOLPath -membertype NoteProperty -value $SYSVOLPath -inputobject $thisdc
                $aclinfo = Get-ACLInfo $SYSVOLPath $dc
                add-member -name SYSVOLACL -membertype NoteProperty -value $aclinfo -inputobject $thisdc
            }                
        
        } # End Per DC Parallel Processing

    } # End Parallel For-Loop

    return $config
} # End Worflow

<#
.SYNOPSIS
Translate hex/decimal ACE string into a value.
.DESCRIPTION
Sometimes get-acl returns a decimal value (like 2147483648) rather than the description of the access entry (READ). Function converts the entry into a readable format.
#>
function get-FileSystemRight ($ace)
{
    $CONST_GENERIC_READ = [MATH]::pow(2,31)
    $CONST_GENERIC_WRITE = [MATH]::pow(2,30)
    $CONST_GENERIC_EXECUTE = [MATH]::pow(2,29)
    $CONST_GENERIC_ALL = [MATH]::pow(2,28)
    $CONST_STD_SYNCHRONIZE = [MATH]::pow(2,20)
    $CONST_STD_WRITE_OWNER = [MATH]::pow(2,19)
    $CONST_STD_WRITE_DAC = [MATH]::pow(2,18)
    $CONST_STD_READ_CONTROL = [MATH]::pow(2,17)
    $CONST_STD_DELETE = [MATH]::pow(2,16)
    $CONST_FILE_WRITEATTR = [MATH]::pow(2,8)
    $CONST_FILE_READATTR = [MATH]::pow(2,7)
    $CONST_FILE_DELETE_CHILD = [MATH]::pow(2,6)
    $CONST_FILE_EXECUTE = [MATH]::pow(2,5)
    $CONST_FILE_WRITE_EA = [MATH]::pow(2,4)
    $CONST_FILE_READ_EA = [MATH]::pow(2,3)
    $CONST_FILE_APPEND_DATA = [MATH]::pow(2,2)
    $CONST_FILE_WRITE_DATA = [MATH]::pow(2,1)
    $CONST_FILE_READ = [MATH]::pow(2,0)
    $FILE_GENERIC_EXECUTE = $CONST_FILE_EXECUTE + $CONST_FILE_READATTR + $CONST_STD_READ_CONTROL + $CONST_STD_SYNCHRONIZE
    $FILE_GENERIC_READ = $CONST_FILE_READATTR + $CONST_FILE_READ + $CONST_FILE_READ_EA + $CONST_STD_READ_CONTROL + $CONST_STD_SYNCHRONIZE
    $FILE_GENERIC_WRITE = $CONST_FILE_APPEND_DATA + $CONST_FILE_WRITEATTR + $CONST_FILE_WRITE_DATA + $CONST_FILE_WRITE_EA + $CONST_STD_READ_CONTROL + $CONST_STD_SYNCHRONIZE
    $FILE_MODIFY = ($FILE_GENERIC_EXECUTE -bor $FILE_GENERIC_READ -bor $file_generic_write -bor $CONST_STD_DELETE) - $CONST_STD_SYNCHRONIZE
    $FILE_FULLCONTROL = $CONST_STD_SYNCHRONIZE -bor $CONST_STD_WRITE_OWNER -bor $CONST_STD_WRITE_DAC -bor $CONST_STD_READ_CONTROL -bor $CONST_STD_DELETE -bor $FILE_MODIFY -bor $CONST_FILE_DELETE_CHILD
    
    # get-acl returns values as int32, which means that values greater than 0x7fffffff are returned as negative integers
    # to get back to positive integers, convert to hex, then to uint32
    if ($ace -lt 0) { $ace = [convert]::touint32(("{0:x}" -f $ace),16) }

    $value = @()
    switch ($ace)
    {
      # TODO: Fix this
      {($CONST_GENERIC_READ -band $ace) -ne 0} {$value += "Read"}
      {($CONST_GENERIC_WRITE -band $ace) -ne 0} {$value += "Write"}
      {($CONST_GENERIC_EXECUTE -band $ace) -ne 0} {$value += "Execute"}
      {($CONST_GENERIC_ALL -band $ace) -ne 0} {$value += "FullControl"}
      {($CONST_SYNCHRONIZE -band $ace) -ne 0} {$value += "Synchronize"}
      {($CONST_WRITE_OWNER -band $ace) -ne 0} {$value += "Take Ownership"}
      {($CONST_WRITE_DAC -band $ace) -ne 0} {$value += "Change Permissions"}
      {($CONST_READ_CONTROL -band $ace) -ne 0} {$value += "Read Permissions"}
      {($CONST_DELETE -band $ace) -ne 0} {$value += "Delete"}
      
    }

    return $value -join ","
}

# ---- MAIN FUNCTION ----
$dcconfiguration = get-ConfigSettings $DCList $outputpath
$importantpaths = "WinDir","System32","NTDSLog","NTDSDB","SYSVOL"

# Process File/Folder ACLs
$acelist = @()
foreach ($dc in $dcconfiguration)
{
    foreach ($pathname in $importantpaths)
    {
        $filepath = $pathname + "Path"
        $ACLobj = $pathname + "ACL"

        foreach ($ace in $dc.$aclobj.access)
        {            
            $ACEObj = new-object psobject
            $aceobj | add-member -name Domain -type noteproperty -Value $dc.domain$
            $aceobj | add-member -name DC -type noteproperty -value $dc.dcname
            $aceobj | add-member -name Resource -type noteproperty -value $pathname
            $aceobj | add-member -name Path -type Noteproperty -value $dc.$filepath
            $ACEObj | Add-Member -name Rights -type NoteProperty -value (get-filesystemright $ace.filesystemrights)
            $ACEObj | Add-Member -name Type -type NoteProperty -value $ace.accesscontroltype
            $ACEObj | Add-Member -name Identity -type NoteProperty -value $ace.identityreference
            $aceobj | add-member -name Inherited -type Noteproperty -value $ace.isinherited 
            $acelist += $aceobj
        }

    }
}

# NTDS and Sysvol Locations
# HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NTDS\Parameters\Database log files path
# HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\NTDS\Parameters\DSA Database file
# HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters\Sysvol
# Systemroot
# HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Systemroot
# (gwmi win32_operatingsystem).windowsdirectory (points to \windows)
# (gwmi win32_operatingsystem).systemdirectory (points to \windows\system32)
# 64 or 32 bit
# (gwmi win32_operatingsystem).osarchitecture
