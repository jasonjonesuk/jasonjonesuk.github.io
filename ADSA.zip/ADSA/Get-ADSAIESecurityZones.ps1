﻿<#
.SYNOPSIS             
Get Internet Explorer Zone security settings

.DESCRIPTION            
Get the templates and customized settings for Internet Explorer zones for each 
user. Compare to defaults and report all settings and templates that are more
permissive than the defaults.

Also get the Internet Explorer Enhanced Security Configuration setting for 
each computer.

.PARAMETER domains_detail
Array of objects representing properties of each domain

.PARAMETER All_DCs
Array of objects representing properties of each domain controller

.PARAMETER filePrefix
Prefix to use for file names (typically shortname of forest root domain)

.PARAMETER OutputPath
Path to write CSV files

.PARAMETER FilePath
Path to custom files

.PARAMETER DCList
Custom list of computers (domain controllers) to collect data against

.PARAMETER Standalone
Run the data collection in standalone mode, rather than as part of the full
ADSA data collection

.OUTPUTS
<FilePrefix>_IEESC.csv
<FilePrefix>_IESettings.csv
<FilePrefix>_IETemplates.csv

.EXAMPLE
get-ADSAIESecurityZones.ps1 -Standalone -DCList ("DC1","DC2","DC3")

Run in standalone mode and get IE settings from DC1, DC2, and DC3

.LINK
http://support.microsoft.com/kb/182569
#>

[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DCList = $null, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null,   

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

if ($Standalone) 
{ 
    if (!($fileprefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }
    if (!($DCList))
    {
        Import-Module .\ADSA.psm1
        $All_DCs = Get-ADSATargetDCs -omitDomains $omitDomains -verbose
        $DCList = $All_DCs | Select-Object -ExpandProperty fqdn
    } 
} 
else
{
    $DCList = $All_DCs | Select-Object -ExpandProperty fqdn
}

write-verbose "List of DCs to collect IE Settings from:`n`t$DCList"

# Script-level constants

# These point to the registry locations of interest for data collection. Preface with HKLM or HKU\<UserSID>
$Script:IEPreferenceReg = "Software\Microsoft\Windows\CurrentVersion\Internet Settings"
$Script:IEPolicyReg = "Software\Policies\Microsoft\Windows\CurrentVersion\Internet Settings"
$Script:IEPreference32Reg = "Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Internet Settings"

<#
.SYNOPSIS             
Convert from a SID to an account name

.DESCRIPTION 
Given a SID string in format S-1-5-*, convert to the corresponding NT account name           

.PARAMETER  SID
A SID string such as S-1-5-21-123-456-789-500

.OUTPUTS
A string representing the NT Account in format DOMAIN\Username
#>
function ConvertFrom-SID
{
    Param 
    (
        $sid
    )
   
   $ID = New-Object System.Security.Principal.SecurityIdentifier($sid)
   $account = $ID.Translate( [System.Security.Principal.NTAccount])
   Return $account.Value
}

<#
.SYNOPSIS             
Get all user SIDs with registry entries in HKU

.DESCRIPTION 
Get the list of user accounts in the HKEY_USERS hive on a remote computer, excluding default and system accounts

.PARAMETER  Reg
A [Microsoft.Win32.RegistryKey] object, pointing to the HKEY_USERS hive on a remote computer

.OUTPUTS
An array of strings listing the SIDs of users with registry entries on the computer
#>
function Get-RegistryUserList
{
    Param (
        $reg # Microsoft.Win32.RegistryKey
    )
    
    # Make sure $reg is the user hive
    if ($reg.name -ne "HKEY_USERS") { write-error "Must pass a user hive to this function."; return -1 }

    $rawUserList = $reg.getsubkeynames()

    # Filter out everything that isn't in format S-1-5-21-<domainSid>-rid
    $userList = $rawUserList -match "^S-1-5-21(-\d+){4}$"
    return $userList
}

<#
.SYNOPSIS             
Establish a connection to a remote registry

.DESCRIPTION 
Establish a connection to a remote registry          

.PARAMETER  Hive
The registry hive to connect to, such as 'LocalMachine' or 'User'

.PARAMETER ComputerName
The name of the remote computer to connect to

.OUTPUTS
A [Microsoft.Win32.RegistryKey] object connected to the $Hive on $ComputerName
#>
function Connect-RemoteRegistry
{
    Param (
        $Hive, # This should be either 'User' or 'LocalMachine'
        $ComputerName # Computer name as a string. FQDN or hostname should work as long as it resolves
    )

    $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($Hive,$ComputerName)
    return $reg
}

# Get the effective zone templates from the registry
function Get-IEZoneTemplates
{
    # For preferences, zones key should point to <blah>\internet settings\zones
    # For policies, zoneskey should point to <blah>\windows\currentversion
    Param (
        $zoneskey # Microsoft.Win32.RegistryKey
    )

    # Check for $zoneskey -eq $null
    if ($zoneskey -eq $null) { return $null }

    # Figure out where we are
    switch -regex ($zoneskey.name)
    {
        "^HKEY_LOCAL_MACHINE\\Software\\Microsoft" { $location = "MachinePreference" }
        "^HKEY_LOCAL_MACHINE\\Software\\Policies" { $location = "MachinePolicy" }
        "^HKEY_LOCAL_MACHINE\\Software\\Wow6432Node\\Microsoft" { $location = "Machine32Preference" }
        "^HKEY_USERS\\S-1-5-21(-\d+){4}\\Software\\Microsoft" { $location = "UserPreference" }
        "^HKEY_USERS\\S-1-5-21(-\d+){4}\\Software\\Policies" { $location = "UserPolicy" }
        "^HKEY_USERS\\S-1-5-21(-\d+){4}\\Software\\Wow6432Node\\Microsoft" { $location = "User32Preference" }
    }

    # Create a hash table to hold the current zone
    $zonetemplates = @{}

    # Get the templates for preference locations ($location ends with Preference)
    if ($location -match "Preference$")
    {
        # The preference location should always end with \Internet Settings\Zones
        if ($zoneskey.name -notmatch "\\Internet Settings\\Zones$")
        {
            Write-Error "Incorrect registry location passed to function"
            return -1
        }

        # Loop through each zone
        for ( $zone = 1; $zone -le 4; $zone++ )
        {
            $subkey = $zoneskey.opensubkey($zone.ToString())
            $template = $subkey.getvalue("CurrentLevel")
            $zonetemplates.add($zone,$template)
            $subkey.close()
        }
    }

    # Get the templates for policy locations
    if ($location -match "Policy$")
    {
        # The group policy implementation is odd, so the code here is strange looking
        
        # Hash Table to hold name of zone
        $zonename = @{}
        $zonename.add(1,"Intranet")
        $zonename.add(2,"Trusted Sites")
        $zonename.add(3,"Internet")
        $zonename.add(4,"Restricted Sites")

        # Array to match GP decimal for zone to the registry hex value
        $zonetemplate = @{}
        $zonetemplate.add(1,0x10000) # Low
        $zonetemplate.add(2,0x10500) # Medium-low
        $zonetemplate.add(3,0x11000) # Medium
        $zonetemplate.add(4,0x12000) # High - this is not a typo
        $zonetemplate.add(5,0x11500) # Medium-High - this is not a typo

        # Loop through zones and collect values if they exist
        for ( $zone = 1; $zone -le 4; $zone++ )
        {
            $keyname = $zonename.get_item($zone)
            if ($zoneskey.getsubkeynames() -match "$keyname Settings") # The zone exists in the policy hive
            {
                $subkey = $zoneskey.opensubkey("$keyname Settings\Template Policies")
                if ($subkey -ne $null)
                {
                    $value = $subkey.getvalue($keyname)
                    $template = $zonetemplate.get_item($value)
                    $zonetemplates.add($zone,$template)
                    $subkey.close()
                }
                else
                {
                    $zonetemplates.add($zone,$null)
                }
            } 
            else
            {
                $zonetemplates.add($zone,$null)
            } 
        }
    }

    $zoneskey.close()

    return $zonetemplates
}

# Get the description (setting name) for a setting based on its hex ID
function Get-IESettingDescription
{
    Param (
        [Parameter(mandatory=$true)]$RegObj # Registry object created by Get-IEZoneSettings
    )

    ## TODO (ERHALL 1/23): Validate the parameter. RegObj.Name should -match "^[1-2]([0-9a-f]{3})$"

    switch ($RegObj.Name)
    {
        # There are some settings that we don't have descriptions for, they aren't listed here and will be assigned $null
        "1001" { $text = "ActiveX controls and plug-ins: Download signed ActiveX controls" ; break }
        "1004" { $text = "ActiveX controls and plug-ins: Download unsigned ActiveX controls" ; break }
        "1200" { $text = "ActiveX controls and plug-ins: Run ActiveX controls and plug-ins" ; break }
        "1201" { $text = "ActiveX controls and plug-ins: Initialize and script ActiveX controls not marked as safe for scripting" ; break }
        "1206" { $text = "Miscellaneous: Allow scripting of Internet Explorer Web browser control" ; break }
        "1207" { $text = "Reserved" ; break }
        "1208" { $text = "ActiveX controls and plug-ins: Allow previously unused ActiveX controls to run without prompt" ; break }
        "1209" { $text = "ActiveX controls and plug-ins: Allow Scriptlets" ; break }
        "120A" { $text = "ActiveX controls and plug-ins: ActiveX controls and plug-ins: Override Per-Site (domain-based) ActiveX restrictions" ; break }
        "120B" { $text = "ActiveX controls and plug-ins: Override Per-Site (domain-based) ActiveX restrictions" ; break }
        "1400" { $text = "Scripting: Active scripting" ; break }
        "1402" { $text = "Scripting: Scripting of Java applets" ; break }
        "1405" { $text = "ActiveX controls and plug-ins: Script ActiveX controls marked as safe for scripting" ; break }
        "1406" { $text = "Miscellaneous: Access data sources across domains" ; break }
        "1407" { $text = "Scripting: Allow Programmatic clipboard access" ; break }
        "1408" { $text = "Reserved" ; break }
        "1409" { $text = "Scripting: Enable XSS Filter" ; break }
        "1601" { $text = "Miscellaneous: Submit non-encrypted form data" ; break }
        "1604" { $text = "Downloads: Font download" ; break }
        "1605" { $text = "Run Java" ; break }
        "1606" { $text = "Miscellaneous: Userdata persistence" ; break }
        "1607" { $text = "Miscellaneous: Navigate sub-frames across different domains" ; break }
        "1608" { $text = "Miscellaneous: Allow META REFRESH" ; break }
        "1609" { $text = "Miscellaneous: Display mixed content" ; break }
        "160A" { $text = "Miscellaneous: Include local directory path when uploading files to a server" ; break }
        "1800" { $text = "Miscellaneous: Installation of desktop items" ; break }
        "1802" { $text = "Miscellaneous: Drag and drop or copy and paste files" ; break }
        "1803" { $text = "Downloads: File Download" ; break }
        "1804" { $text = "Miscellaneous: Launching programs and files in an IFRAME" ; break }
        "1805" { $text = "Launching programs and files in webview" ; break }
        "1806" { $text = "Miscellaneous: Launching applications and unsafe files" ; break }
        "1807" { $text = "Reserved" ; break }
        "1808" { $text = "Reserved" ; break }
        "1809" { $text = "Miscellaneous: Use Pop-up Blocker" ; break }
        "180A" { $text = "Reserved" ; break }
        "180B" { $text = "Reserved" ; break }
        "180C" { $text = "Reserved" ; break }
        "180D" { $text = "Reserved" ; break }
        "180E" { $text = "Allow OpenSearch queries in Windows Explorer" ; break }
        "180F" { $text = "Allow previewing and custom thumbnails of OpenSearch query results in Windows Explorer" ; break }
        "1A00" { $text = "User Authentication: Logon" ; break }
        "1A02" { $text = "Allow persistent cookies that are stored on your computer" ; break }
        "1A03" { $text = "Allow per-session cookies (not stored)" ; break }
        "1A04" { $text = "Miscellaneous: Don't prompt for client certificate selection when no certificates or only one certificate exists" ; break }
        "1A05" { $text = "Allow 3rd party persistent cookies" ; break }
        "1A06" { $text = "Allow 3rd party session cookies" ; break }
        "1A10" { $text = "Privacy Settings" ; break }
        "1C00" { $text = "Java permissions" ; break }
        "1E05" { $text = "Miscellaneous: Software channel permissions" ; break }
        "1F00" { $text = "Reserved" ; break }
        "2000" { $text = "ActiveX controls and plug-ins: Binary and script behaviors" ; break }
        "2001" { $text = ".NET Framework-reliant components: Run components signed with Authenticode" ; break }
        "2004" { $text = ".NET Framework-reliant components: Run components not signed with Authenticode" ; break }
        "2007" { $text = ".NET Framework-Reliant Components: Permissions for Components with Manifests" ; break }
        "2100" { $text = "Miscellaneous: Open files based on content, not file extension" ; break }
        "2101" { $text = "Miscellaneous: Web sites in less privileged web content zone can navigate into this zone" ; break }
        "2102" { $text = "Miscellaneous: Allow script initiated windows without size or position constraints" ; break }
        "2103" { $text = "Scripting: Allow status bar updates via script" ; break }
        "2104" { $text = "Miscellaneous: Allow websites to open windows without address or status bars" ; break }
        "2105" { $text = "Scripting: Allow websites to prompt for information using scripted windows" ; break }
        "2200" { $text = "Downloads: Automatic prompting for file downloads" ; break }
        "2201" { $text = "ActiveX controls and plug-ins: Automatic prompting for ActiveX controls" ; break }
        "2300" { $text = "Miscellaneous: Allow web pages to use restricted protocols for active content" ; break }
        "2301" { $text = "Miscellaneous: Use Phishing Filter" ; break }
        "2400" { $text = ".NET Framework: XAML browser applications" ; break }
        "2401" { $text = ".NET Framework: XPS documents" ; break }
        "2402" { $text = ".NET Framework: Loose XAML" ; break }
        "2500" { $text = "Turn on Protected Mode [Vista only setting]" ; break }
        "2600" { $text = "Enable .NET Framework setup" ; break }
        "2702" { $text = "ActiveX controls and plug-ins: Allow ActiveX Filtering" ; break }
        "2708" { $text = "Miscellaneous: Allow dragging of content between domains into the same window" ; break }
        "2709" { $text = "Miscellaneous: Allow dragging of content between domains into separate windows" ; break }
        "270B" { $text = "Miscellaneous: Render legacy filters" ; break }
        "270C" { $text = "ActiveX Controls and plug-ins: Run Antimalware software on ActiveX controls" ; break }
        default { $text = $null }
    }
    $RegObj | Add-Member -Name "Description" -Type NoteProperty -Value $text

    return $RegObj
}

# Initialize an array of hashtables holding the default values
function Initialize-IEZoneDefaults
{
    $zonemap = @() # Array to hold hashtable for each zone
    $zone1map = @{} # Hashtable for Local Intranet zone
    $zone2map = @{} # Hashtable for Trusted Sites zone
    $zone3map = @{} # Hashtable for Internet zone
    $zone4map = @{} # Hashtable for Restricted Sites zone

    # Build the hash tables (long)
    $zone1map.add("1001",0x1); $zone2map.add("1001",0x1); $zone3map.add("1001",0x3); $zone4map.add("1001",0x3); 
    $zone1map.add("1004",0x3); $zone2map.add("1004",0x3); $zone3map.add("1004",0x3); $zone4map.add("1004",0x3); 
    $zone1map.add("1200",0x0); $zone2map.add("1200",0x0); $zone3map.add("1200",0x3); $zone4map.add("1200",0x3); 
    $zone1map.add("1201",0x3); $zone2map.add("1201",0x3); $zone3map.add("1201",0x3); $zone4map.add("1201",0x3); 
    $zone1map.add("1206",0x0); $zone2map.add("1206",0x3); $zone3map.add("1206",0x3); $zone4map.add("1206",0x3); 
    $zone1map.add("1207",0x0); $zone2map.add("1207",0x0); $zone3map.add("1207",0x3); $zone4map.add("1207",0x3); 
    $zone1map.add("1208",0x0); $zone2map.add("1208",0x0); $zone3map.add("1208",0x3); $zone4map.add("1208",0x3); 
    $zone1map.add("1209",0x0); $zone2map.add("1209",0x3); $zone3map.add("1209",0x3); $zone4map.add("1209",0x3); 
    $zone1map.add("120A",0x3); $zone2map.add("120A",0x3); $zone3map.add("120A",0x3); $zone4map.add("120A",0x3); 
    $zone1map.add("120B",0x0); $zone2map.add("120B",0x0); $zone3map.add("120B",0x3); $zone4map.add("120B",0x3); 
    $zone1map.add("1400",0x0); $zone2map.add("1400",0x0); $zone3map.add("1400",0x3); $zone4map.add("1400",0x3); 
    $zone1map.add("1402",0x0); $zone2map.add("1402",0x0); $zone3map.add("1402",0x3); $zone4map.add("1402",0x3); 
    $zone1map.add("1405",0x0); $zone2map.add("1405",0x0); $zone3map.add("1405",0x3); $zone4map.add("1405",0x3); 
    $zone1map.add("1406",0x1); $zone2map.add("1406",0x3); $zone3map.add("1406",0x3); $zone4map.add("1406",0x3); 
    $zone1map.add("1407",0x0); $zone2map.add("1407",0x1); $zone3map.add("1407",0x3); $zone4map.add("1407",0x3); 
    $zone1map.add("1408",0x0); $zone2map.add("1408",0x0); $zone3map.add("1408",0x3); $zone4map.add("1408",0x3); 
    $zone1map.add("1409",0x3); $zone2map.add("1409",0x0); $zone3map.add("1409",0x0); $zone4map.add("1409",0x0); 
    $zone1map.add("1601",0x0); $zone2map.add("1601",0x0); $zone3map.add("1601",0x1); $zone4map.add("1601",0x1); 
    $zone1map.add("1604",0x0); $zone2map.add("1604",0x0); $zone3map.add("1604",0x3); $zone4map.add("1604",0x3); 
    $zone1map.add("1605",0x0); $zone2map.add("1605",0x0); $zone3map.add("1605",0x0); $zone4map.add("1605",0x0); 
    $zone1map.add("1606",0x0); $zone2map.add("1606",0x0); $zone3map.add("1606",0x3); $zone4map.add("1606",0x3); 
    $zone1map.add("1607",0x0); $zone2map.add("1607",0x3); $zone3map.add("1607",0x3); $zone4map.add("1607",0x3); 
    $zone1map.add("1608",0x0); $zone2map.add("1608",0x0); $zone3map.add("1608",0x3); $zone4map.add("1608",0x3); 
    $zone1map.add("1609",0x1); $zone2map.add("1609",0x1); $zone3map.add("1609",0x1); $zone4map.add("1609",0x1); 
    $zone1map.add("160A",0x0); $zone2map.add("160A",0x0); $zone3map.add("160A",0x3); $zone4map.add("160A",0x3); 
    $zone1map.add("1800",0x0); $zone2map.add("1800",0x0); $zone3map.add("1800",0x0); $zone4map.add("1800",0x0); 
    $zone1map.add("1802",0x0); $zone2map.add("1802",0x0); $zone3map.add("1802",0x1); $zone4map.add("1802",0x1); 
    $zone1map.add("1803",0x0); $zone2map.add("1803",0x0); $zone3map.add("1803",0x3); $zone4map.add("1803",0x3); 
    $zone1map.add("1804",0x1); $zone2map.add("1804",0x1); $zone3map.add("1804",0x3); $zone4map.add("1804",0x3); 
    $zone1map.add("1805",0x0); $zone2map.add("1805",0x0); $zone3map.add("1805",0x0); $zone4map.add("1805",0x0); 
    $zone1map.add("1806",0x0); $zone2map.add("1806",0x0); $zone3map.add("1806",0x0); $zone4map.add("1806",0x0); 
    $zone1map.add("1807",0x0); $zone2map.add("1807",0x0); $zone3map.add("1807",0x0); $zone4map.add("1807",0x0); 
    $zone1map.add("1808",0x0); $zone2map.add("1808",0x0); $zone3map.add("1808",0x0); $zone4map.add("1808",0x0); 
    $zone1map.add("1809",0x3); $zone2map.add("1809",0x0); $zone3map.add("1809",0x0); $zone4map.add("1809",0x0); 
    $zone1map.add("180A",0x0); $zone2map.add("180A",0x0); $zone3map.add("180A",0x0); $zone4map.add("180A",0x0); 
    $zone1map.add("180B",0x0); $zone2map.add("180B",0x0); $zone3map.add("180B",0x1); $zone4map.add("180B",0x1); 
    $zone1map.add("180C",0x0); $zone2map.add("180C",0x0); $zone3map.add("180C",0x0); $zone4map.add("180C",0x0); 
    $zone1map.add("180D",0x0); $zone2map.add("180D",0x0); $zone3map.add("180D",0x0); $zone4map.add("180D",0x0); 
    $zone1map.add("180E",0x0); $zone2map.add("180E",0x0); $zone3map.add("180E",0x0); $zone4map.add("180E",0x0); 
    $zone1map.add("180F",0x0); $zone2map.add("180F",0x0); $zone3map.add("180F",0x0); $zone4map.add("180F",0x0); 
    $zone1map.add("1812",0x0); $zone2map.add("1812",0x0); $zone3map.add("1812",0x1); $zone4map.add("1812",0x1); 
    $zone1map.add("1A00",0x20000); $zone2map.add("1A00",0x20000); $zone3map.add("1A00",0x10000); $zone4map.add("1A00",0x10000); 
    $zone1map.add("1A02",0x0); $zone2map.add("1A02",0x0); $zone3map.add("1A02",0x3); $zone4map.add("1A02",0x3); 
    $zone1map.add("1A03",0x0); $zone2map.add("1A03",0x0); $zone3map.add("1A03",0x3); $zone4map.add("1A03",0x3); 
    $zone1map.add("1A04",0x0); $zone2map.add("1A04",0x3); $zone3map.add("1A04",0x3); $zone4map.add("1A04",0x3); 
    $zone1map.add("1A05",0x0); $zone2map.add("1A05",0x1); $zone3map.add("1A05",0x3); $zone4map.add("1A05",0x3); 
    $zone1map.add("1A06",0x0); $zone2map.add("1A06",0x0); $zone3map.add("1A06",0x3); $zone4map.add("1A06",0x3); 
    $zone1map.add("1A10",0x0); $zone2map.add("1A10",0x0); $zone3map.add("1A10",0x0); $zone4map.add("1A10",0x0); 
    $zone1map.add("1C00",0x20000); $zone2map.add("1C00",0x10000); $zone3map.add("1C00",0x0); $zone4map.add("1C00",0x0); 
    $zone1map.add("1E05",0x0); $zone2map.add("1E05",0x0); $zone3map.add("1E05",0x0); $zone4map.add("1E05",0x0); 
    $zone1map.add("1F00",0x0); $zone2map.add("1F00",0x0); $zone3map.add("1F00",0x0); $zone4map.add("1F00",0x0); 
    $zone1map.add("2000",0x0); $zone2map.add("2000",0x0); $zone3map.add("2000",0x3); $zone4map.add("2000",0x3); 
    $zone1map.add("2001",0x0); $zone2map.add("2001",0x0); $zone3map.add("2001",0x3); $zone4map.add("2001",0x3); 
    $zone1map.add("2004",0x0); $zone2map.add("2004",0x0); $zone3map.add("2004",0x3); $zone4map.add("2004",0x3); 
    $zone1map.add("2005",0x0); $zone2map.add("2005",0x0); $zone3map.add("2005",0x3); $zone4map.add("2005",0x3); 
    $zone1map.add("2007",0x10000); $zone2map.add("2007",0x10000); $zone3map.add("2007",0x3); $zone4map.add("2007",0x3); 
    $zone1map.add("2100",0x0); $zone2map.add("2100",0x0); $zone3map.add("2100",0x3); $zone4map.add("2100",0x3); 
    $zone1map.add("2101",0x0); $zone2map.add("2101",0x0); $zone3map.add("2101",0x3); $zone4map.add("2101",0x3); 
    $zone1map.add("2102",0x0); $zone2map.add("2102",0x3); $zone3map.add("2102",0x3); $zone4map.add("2102",0x3); 
    $zone1map.add("2103",0x0); $zone2map.add("2103",0x0); $zone3map.add("2103",0x3); $zone4map.add("2103",0x3); 
    $zone1map.add("2104",0x0); $zone2map.add("2104",0x0); $zone3map.add("2104",0x3); $zone4map.add("2104",0x3); 
    $zone1map.add("2105",0x0); $zone2map.add("2105",0x0); $zone3map.add("2105",0x3); $zone4map.add("2105",0x3); 
    $zone1map.add("2106",0x0); $zone2map.add("2106",0x0); $zone3map.add("2106",0x3); $zone4map.add("2106",0x3); 
    $zone1map.add("2107",0x0); $zone2map.add("2107",0x0); $zone3map.add("2107",0x3); $zone4map.add("2107",0x3); 
    $zone1map.add("2108",0x3); $zone2map.add("2108",0x3); $zone3map.add("2108",0x0); $zone4map.add("2108",0x0); 
    $zone1map.add("2200",0x0); $zone2map.add("2200",0x3); $zone3map.add("2200",0x3); $zone4map.add("2200",0x3); 
    $zone1map.add("2201",0x0); $zone2map.add("2201",0x3); $zone3map.add("2201",0x3); $zone4map.add("2201",0x3); 
    $zone1map.add("2300",0x1); $zone2map.add("2300",0x1); $zone3map.add("2300",0x3); $zone4map.add("2300",0x3); 
    $zone1map.add("2301",0x3); $zone2map.add("2301",0x0); $zone3map.add("2301",0x0); $zone4map.add("2301",0x0); 
    $zone1map.add("2302",0x3); $zone2map.add("2302",0x3); $zone3map.add("2302",0x3); $zone4map.add("2302",0x3); 
    $zone1map.add("2400",0x0); $zone2map.add("2400",0x0); $zone3map.add("2400",0x3); $zone4map.add("2400",0x3); 
    $zone1map.add("2401",0x0); $zone2map.add("2401",0x0); $zone3map.add("2401",0x3); $zone4map.add("2401",0x3); 
    $zone1map.add("2402",0x0); $zone2map.add("2402",0x0); $zone3map.add("2402",0x3); $zone4map.add("2402",0x3); 
    $zone1map.add("2500",0x0); $zone2map.add("2500",0x0); $zone3map.add("2500",0x0); $zone4map.add("2500",0x0); 
    $zone1map.add("2600",0x0); $zone2map.add("2600",0x0); $zone3map.add("2600",0x3); $zone4map.add("2600",0x3); 
    $zone1map.add("2700",0x3); $zone2map.add("2700",0x3); $zone3map.add("2700",0x0); $zone4map.add("2700",0x0); 
    $zone1map.add("2701",0x0); $zone2map.add("2701",0x0); $zone3map.add("2701",0x3); $zone4map.add("2701",0x3); 
    $zone1map.add("2702",0x3); $zone2map.add("2702",0x0); $zone3map.add("2702",0x0); $zone4map.add("2702",0x0); 
    $zone1map.add("2703",0x0); $zone2map.add("2703",0x0); $zone3map.add("2703",0x3); $zone4map.add("2703",0x3); 
    $zone1map.add("2704",0x0); $zone2map.add("2704",0x0); $zone3map.add("2704",0x3); $zone4map.add("2704",0x3); 
    $zone1map.add("2708",0x3); $zone2map.add("2708",0x3); $zone3map.add("2708",0x3); $zone4map.add("2708",0x3); 
    $zone1map.add("2709",0x3); $zone2map.add("2709",0x3); $zone3map.add("2709",0x3); $zone4map.add("2709",0x3); 
    $zone1map.add("270B",0x0); $zone2map.add("270B",0x0); $zone3map.add("270B",0x3); $zone4map.add("270B",0x3); 
    $zone1map.add("270C",0x3); $zone2map.add("270C",0x3); $zone3map.add("270C",0x0); $zone4map.add("270C",0x0); 
    $zone1map.add("270D",0x0); $zone2map.add("270D",0x0); $zone3map.add("270D",0x3); $zone4map.add("270D",0x3); 


    $zonemap += $zone1map
    $zonemap += $zone2map
    $zonemap += $zone3map
    $zonemap += $zone4map

    return $zonemap

}

function Initialize-IETemplateDefaults
{
    $templatemap = @{}
    $low = @{}
    $mlo = @{}
    $med = @{}
    $mhi = @{}
    $high = @{}

    # Build the hash tables (long)
    $low.add("1001",0x0); $mlo.add("1001",0x1); $med.add("1001",0x1); $mhi.add("1001",0x1); $high.add("1001",0x3)
    $low.add("1004",0x4); $mlo.add("1004",0x3); $med.add("1004",0x3); $mhi.add("1004",0x3); $high.add("1004",0x3)
    $low.add("1200",0x0); $mlo.add("1200",0x0); $med.add("1200",0x0); $mhi.add("1200",0x0); $high.add("1200",0x3)
    $low.add("1201",0x1); $mlo.add("1201",0x3); $med.add("1201",0x3); $mhi.add("1201",0x3); $high.add("1201",0x3)
    $low.add("1206",0x0); $mlo.add("1206",0x0); $med.add("1206",0x3); $mhi.add("1206",0x3); $high.add("1206",0x3)
    $low.add("1207",0x0); $mlo.add("1207",0x0); $med.add("1207",0x0); $mhi.add("1207",0x3); $high.add("1207",0x3)
    $low.add("1208",0x0); $mlo.add("1208",0x0); $med.add("1208",0x0); $mhi.add("1208",0x3); $high.add("1208",0x3)
    $low.add("1209",0x0); $mlo.add("1209",0x0); $med.add("1209",0x3); $mhi.add("1209",0x3); $high.add("1209",0x3)
    $low.add("120A",0x3); $mlo.add("120A",0x3); $med.add("120A",0x3); $mhi.add("120A",0x3); $high.add("120A",0x3)
    $low.add("120B",0x0); $mlo.add("120B",0x0); $med.add("120B",0x0); $mhi.add("120B",0x3); $high.add("120B",0x3)
    $low.add("1400",0x0); $mlo.add("1400",0x0); $med.add("1400",0x0); $mhi.add("1400",0x0); $high.add("1400",0x3)
    $low.add("1402",0x0); $mlo.add("1402",0x0); $med.add("1402",0x0); $mhi.add("1402",0x0); $high.add("1402",0x3)
    $low.add("1405",0x0); $mlo.add("1405",0x0); $med.add("1405",0x0); $mhi.add("1405",0x0); $high.add("1405",0x3)
    $low.add("1406",0x0); $mlo.add("1406",0x1); $med.add("1406",0x3); $mhi.add("1406",0x3); $high.add("1406",0x3)
    $low.add("1407",0x0); $mlo.add("1407",0x0); $med.add("1407",0x1); $mhi.add("1407",0x1); $high.add("1407",0x3)
    $low.add("1408",0x0); $mlo.add("1408",0x0); $med.add("1408",0x0); $mhi.add("1408",0x3); $high.add("1408",0x3)
    $low.add("1409",0x3); $mlo.add("1409",0x3); $med.add("1409",0x0); $mhi.add("1409",0x0); $high.add("1409",0x0)
    $low.add("1601",0x0); $mlo.add("1601",0x0); $med.add("1601",0x0); $mhi.add("1601",0x0); $high.add("1601",0x1)
    $low.add("1604",0x0); $mlo.add("1604",0x0); $med.add("1604",0x0); $mhi.add("1604",0x0); $high.add("1604",0x3)
    $low.add("1605",0x0); $mlo.add("1605",0x0); $med.add("1605",0x0); $mhi.add("1605",0x0); $high.add("1605",0x0)
    $low.add("1606",0x0); $mlo.add("1606",0x0); $med.add("1606",0x0); $mhi.add("1606",0x0); $high.add("1606",0x3)
    $low.add("1607",0x0); $mlo.add("1607",0x0); $med.add("1607",0x3); $mhi.add("1607",0x3); $high.add("1607",0x3)
    $low.add("1608",0x0); $mlo.add("1608",0x0); $med.add("1608",0x0); $mhi.add("1608",0x0); $high.add("1608",0x3)
    $low.add("1609",0x1); $mlo.add("1609",0x1); $med.add("1609",0x1); $mhi.add("1609",0x1); $high.add("1609",0x1)
    $low.add("160A",0x0); $mlo.add("160A",0x0); $med.add("160A",0x0); $mhi.add("160A",0x3); $high.add("160A",0x3)
    $low.add("1800",0x0); $mlo.add("1800",0x0); $med.add("1800",0x0); $mhi.add("1800",0x0); $high.add("1800",0x0)
    $low.add("1802",0x0); $mlo.add("1802",0x0); $med.add("1802",0x0); $mhi.add("1802",0x0); $high.add("1802",0x1)
    $low.add("1803",0x0); $mlo.add("1803",0x0); $med.add("1803",0x0); $mhi.add("1803",0x0); $high.add("1803",0x3)
    $low.add("1804",0x0); $mlo.add("1804",0x1); $med.add("1804",0x1); $mhi.add("1804",0x1); $high.add("1804",0x3)
    $low.add("1805",0x0); $mlo.add("1805",0x0); $med.add("1805",0x0); $mhi.add("1805",0x0); $high.add("1805",0x0)
    $low.add("1806",0x0); $mlo.add("1806",0x0); $med.add("1806",0x0); $mhi.add("1806",0x0); $high.add("1806",0x0)
    $low.add("1807",0x0); $mlo.add("1807",0x0); $med.add("1807",0x0); $mhi.add("1807",0x0); $high.add("1807",0x0)
    $low.add("1808",0x0); $mlo.add("1808",0x0); $med.add("1808",0x0); $mhi.add("1808",0x0); $high.add("1808",0x0)
    $low.add("1809",0x3); $mlo.add("1809",0x3); $med.add("1809",0x0); $mhi.add("1809",0x0); $high.add("1809",0x0)
    $low.add("180A",0x0); $mlo.add("180A",0x0); $med.add("180A",0x0); $mhi.add("180A",0x0); $high.add("180A",0x0)
    $low.add("180B",0x0); $mlo.add("180B",0x0); $med.add("180B",0x0); $mhi.add("180B",0x0); $high.add("180B",0x1)
    $low.add("180C",0x0); $mlo.add("180C",0x0); $med.add("180C",0x0); $mhi.add("180C",0x0); $high.add("180C",0x0)
    $low.add("180D",0x0); $mlo.add("180D",0x0); $med.add("180D",0x0); $mhi.add("180D",0x0); $high.add("180D",0x0)
    $low.add("180E",0x0); $mlo.add("180E",0x0); $med.add("180E",0x0); $mhi.add("180E",0x0); $high.add("180E",0x0)
    $low.add("180F",0x0); $mlo.add("180F",0x0); $med.add("180F",0x0); $mhi.add("180F",0x0); $high.add("180F",0x0)
    $low.add("1812",0x0); $mlo.add("1812",0x0); $med.add("1812",0x0); $mhi.add("1812",0x1); $high.add("1812",0x1)
    $low.add("1A00",0x0); $mlo.add("1A00",0x20000); $med.add("1A00",0x20000); $mhi.add("1A00",0x20000); $high.add("1A00",0x10000)
    $low.add("1A02",0x0); $mlo.add("1A02",0x0); $med.add("1A02",0x0); $mhi.add("1A02",0x0); $high.add("1A02",0x3)
    $low.add("1A03",0x0); $mlo.add("1A03",0x0); $med.add("1A03",0x0); $mhi.add("1A03",0x0); $high.add("1A03",0x3)
    $low.add("1A04",0x0); $mlo.add("1A04",0x0); $med.add("1A04",0x3); $mhi.add("1A04",0x3); $high.add("1A04",0x3)
    $low.add("1A05",0x0); $mlo.add("1A05",0x0); $med.add("1A05",0x1); $mhi.add("1A05",0x1); $high.add("1A05",0x3)
    $low.add("1A06",0x0); $mlo.add("1A06",0x0); $med.add("1A06",0x0); $mhi.add("1A06",0x0); $high.add("1A06",0x3)
    $low.add("1A10",0x0); $mlo.add("1A10",0x0); $med.add("1A10",0x0); $mhi.add("1A10",0x0); $high.add("1A10",0x0)
    $low.add("1C00",0x30000); $mlo.add("1C00",0x20000); $med.add("1C00",0x10000); $mhi.add("1C00",0x10000); $high.add("1C00",0x0)
    $low.add("1E05",0x0); $mlo.add("1E05",0x0); $med.add("1E05",0x0); $mhi.add("1E05",0x0); $high.add("1E05",0x0)
    $low.add("1F00",0x0); $mlo.add("1F00",0x0); $med.add("1F00",0x0); $mhi.add("1F00",0x0); $high.add("1F00",0x0)
    $low.add("2000",0x0); $mlo.add("2000",0x0); $med.add("2000",0x0); $mhi.add("2000",0x0); $high.add("2000",0x3)
    $low.add("2001",0x0); $mlo.add("2001",0x0); $med.add("2001",0x0); $mhi.add("2001",0x0); $high.add("2001",0x3)
    $low.add("2004",0x0); $mlo.add("2004",0x0); $med.add("2004",0x0); $mhi.add("2004",0x0); $high.add("2004",0x3)
    $low.add("2005",0x0); $mlo.add("2005",0x0); $med.add("2005",0x0); $mhi.add("2005",0x3); $high.add("2005",0x3)
    $low.add("2007",0x10000); $mlo.add("2007",0x10000); $med.add("2007",0x10000); $mhi.add("2007",0x10000); $high.add("2007",0x3)
    $low.add("2100",0x0); $mlo.add("2100",0x0); $med.add("2100",0x0); $mhi.add("2100",0x0); $high.add("2100",0x3)
    $low.add("2101",0x1); $mlo.add("2101",0x0); $med.add("2101",0x0); $mhi.add("2101",0x0); $high.add("2101",0x3)
    $low.add("2102",0x0); $mlo.add("2102",0x0); $med.add("2102",0x3); $mhi.add("2102",0x3); $high.add("2102",0x3)
    $low.add("2103",0x0); $mlo.add("2103",0x0); $med.add("2103",0x0); $mhi.add("2103",0x3); $high.add("2103",0x3)
    $low.add("2104",0x0); $mlo.add("2104",0x0); $med.add("2104",0x0); $mhi.add("2104",0x3); $high.add("2104",0x3)
    $low.add("2105",0x0); $mlo.add("2105",0x0); $med.add("2105",0x0); $mhi.add("2105",0x3); $high.add("2105",0x3)
    $low.add("2106",0x0); $mlo.add("2106",0x0); $med.add("2106",0x0); $mhi.add("2106",0x0); $high.add("2106",0x3)
    $low.add("2107",0x0); $mlo.add("2107",0x0); $med.add("2107",0x0); $mhi.add("2107",0x3); $high.add("2107",0x3)
    $low.add("2108",0x3); $mlo.add("2108",0x3); $med.add("2108",0x3); $mhi.add("2108",0x0); $high.add("2108",0x0)
    $low.add("2200",0x0); $mlo.add("2200",0x0); $med.add("2200",0x3); $mhi.add("2200",0x3); $high.add("2200",0x3)
    $low.add("2201",0x0); $mlo.add("2201",0x0); $med.add("2201",0x3); $mhi.add("2201",0x3); $high.add("2201",0x3)
    $low.add("2300",0x1); $mlo.add("2300",0x1); $med.add("2300",0x1); $mhi.add("2300",0x1); $high.add("2300",0x3)
    $low.add("2301",0x3); $mlo.add("2301",0x3); $med.add("2301",0x0); $mhi.add("2301",0x0); $high.add("2301",0x0)
    $low.add("2302",0x3); $mlo.add("2302",0x3); $med.add("2302",0x3); $mhi.add("2302",0x3); $high.add("2302",0x3)
    $low.add("2400",0x0); $mlo.add("2400",0x0); $med.add("2400",0x0); $mhi.add("2400",0x3); $high.add("2400",0x3)
    $low.add("2401",0x0); $mlo.add("2401",0x0); $med.add("2401",0x0); $mhi.add("2401",0x0); $high.add("2401",0x3)
    $low.add("2402",0x0); $mlo.add("2402",0x0); $med.add("2402",0x0); $mhi.add("2402",0x3); $high.add("2402",0x3)
    $low.add("2500",0x0); $mlo.add("2500",0x0); $med.add("2500",0x0); $mhi.add("2500",0x0); $high.add("2500",0x0)
    $low.add("2600",0x0); $mlo.add("2600",0x0); $med.add("2600",0x0); $mhi.add("2600",0x0); $high.add("2600",0x3)
    $low.add("2700",0x3); $mlo.add("2700",0x3); $med.add("2700",0x3); $mhi.add("2700",0x0); $high.add("2700",0x0)
    $low.add("2701",0x0); $mlo.add("2701",0x0); $med.add("2701",0x0); $mhi.add("2701",0x0); $high.add("2701",0x3)
    $low.add("2702",0x3); $mlo.add("2702",0x3); $med.add("2702",0x0); $mhi.add("2702",0x0); $high.add("2702",0x0)
    $low.add("2703",0x0); $mlo.add("2703",0x0); $med.add("2703",0x0); $mhi.add("2703",0x3); $high.add("2703",0x3)
    $low.add("2704",0x0); $mlo.add("2704",0x0); $med.add("2704",0x0); $mhi.add("2704",0x0); $high.add("2704",0x3)
    $low.add("2708",0x3); $mlo.add("2708",0x3); $med.add("2708",0x3); $mhi.add("2708",0x3); $high.add("2708",0x3)
    $low.add("2709",0x3); $mlo.add("2709",0x3); $med.add("2709",0x3); $mhi.add("2709",0x3); $high.add("2709",0x3)
    $low.add("270B",0x0); $mlo.add("270B",0x0); $med.add("270B",0x0); $mhi.add("270B",0x3); $high.add("270B",0x3)
    $low.add("270C",0x3); $mlo.add("270C",0x3); $med.add("270C",0x3); $mhi.add("270C",0x0); $high.add("270C",0x0)
    $low.add("270D",0x0); $mlo.add("270D",0x0); $med.add("270D",0x0); $mhi.add("270D",0x3); $high.add("270D",0x3)

    $templatemap.add(0x10000,$low)
    $templatemap.add(0x10500,$mlo)
    $templatemap.add(0x11000,$med)
    $templatemap.add(0x11500,$mhi)
    $templatemap.add(0x12000,$high)

    return $templatemap
}

# Get the default value for a setting based on the zone
function Get-IESettingTemplateDefault
{
    Param (
        [Parameter(mandatory=$true)]$RegObj, # Registry object created by Get-IEZoneSettings
        [Parameter(mandatory=$true)]$zonemap
    )

    $zone = $RegObj.zone
    $name = $RegObj.name
    
    # Figure out the correct template to use based on the default template for the zone
    switch ($zone)
    {
        1 { $defzone = 0x10500; $template = $zonemap.$defzone; break }
        2 { $defzone = 0x11000; $template = $zonemap.$defzone; break }
        3 { $defzone = 0x12000; $template = $zonemap.$defzone; break }
        4 { $defzone = 0x12000; $template = $zonemap.$defzone; break }
    }

    $defvalue = $template.$name
    $RegObj | Add-Member -Name "DefaultTemplate" -type NoteProperty -value $defzone
    $RegObj | Add-Member -Name "DefaultData" -Type NoteProperty -Value $defvalue

    return $RegObj    
}

# Get the settings for a single zone
function Get-IEZoneSettings
{
    Param (
        $zoneskey # Microsoft.Win32.RegistryKey, pointing to <something>\internet settings\zones
    )

    # Validate that $zoneskey is pointing to the right place, and set a value for locations
    
    # Check for $zoneskey -eq $null
    if ($zoneskey -eq $null) { return $null }

    # The location should always end up at \Internet Settings\Zones
    if ($zoneskey.name -notmatch "\\Internet Settings\\Zones$")
    {
        Write-Error "Incorrect registry location passed to function, or zones subkey does not exist"
        return $null
    }
    # Now figure out where we are
    switch -regex ($zoneskey.name)
    {
        "^HKEY_LOCAL_MACHINE\\Software\\Microsoft" { $location = "MachinePreference" }
        "^HKEY_LOCAL_MACHINE\\Software\\Policies" { $location = "MachinePolicy" }
        "^HKEY_LOCAL_MACHINE\\Software\\Wow6432Node\\Microsoft" { $location = "Machine32Preference" }
        "^HKEY_USERS\\S-1-5-21(-\d+){4}\\Software\\Microsoft" { $location = "UserPreference" }
        "^HKEY_USERS\\S-1-5-21(-\d+){4}\\Software\\Policies" { $location = "UserPolicy" }
        "^HKEY_USERS\\S-1-5-21(-\d+){4}\\Software\\Wow6432Node\\Microsoft" { $location = "User32Preference" }
    }

    # Create an array to hold objects for each setting
    $zonesettings = @()

    # Loop through each zone
    for ( $zone = 1; $zone -le 4; $zone++ )
    {
        $subkey = $zoneskey.opensubkey($zone.ToString())
        if ($subkey -ne $null)
        {
            $valuelist = $subkey.getvaluenames()
            foreach ($valuename in $valuelist)
            {
            
                if ($valuename -match "^[1-2]([0-9a-f]{3})$") # Reprsents hex values between 1000 - 2FFF
                {
                    $RegObj = New-Object psobject
                    $RegObj | Add-Member -Name "Zone" -Type NoteProperty -Value $zone
                    $RegObj | Add-Member -Name "Name" -type NoteProperty -Value $valuename
                    $RegObj | Add-Member -Name "Data" -type NoteProperty -Value ($subkey.getvalue($valuename))
                    $RegObj | Add-Member -Name "Source" -type NoteProperty -Value $location
                    $RegObj = Get-IESettingDescription $RegObj
                    $RegObj = Get-IESettingTemplateDefault $RegObj $Script:templatemap
                    $zonesettings += $RegObj
                }
            }
            $subkey.close()
        }
    }

    $zoneskey.close()
        
    return $zonesettings
}


# Check whether "Security Zones: use only machine settings" is enabled
function Test-IEMachineOnly
{
    Param (
        $reg # Microsoft.Win32.RegistryKey
    )

    # Make sure $reg is the machine hive
    if ($reg.name -ne "HKEY_LOCAL_MACHINE") { write-error "Must pass a machine hive to this function."; return -1 }

    $valuename = "Security_HKLM_Only"
    $key = $reg.OpenSubKey($Script:IEPolicyReg)
    if ($key -ne $null -and $key.GetValueNames() -match $valuename )
    {
        $value = $key.GetValue($valuename)
        if ($valuename -eq 1) { return $true } else { return $false }
    }
    else { return $false }
}

# Merge the user and machine policy and preference hives; generating the resultant templates
function Merge-IETemplates
{
    Param
    (
        [parameter(Mandatory=$true)][AllowNull()]$MachinePol,
        [parameter(Mandatory=$true)][AllowNull()]$MachinePref,

        [parameter(Mandatory=$true,ParameterSetName="Machine")][Switch]$MachineOnly,

        [parameter(Mandatory=$true,ParameterSetName="User")][AllowNull()]$UserPol,
        [parameter(Mandatory=$true,ParameterSetName="User")][AllowNull()]$UserPref
    )  

    $mergedZoneList = @{}

    # Loop through zones
    for ($zone = 1; $zone -le 4; $zone++)
    {
        if ($MachinePol -ne $null -and $MachinePol.get_item($zone) -ne $null) { $level = $MachinePol.get_item($zone) ; $source = "MachinePolicy" }
        elseif (!($MachineOnly) -and $UserPol -ne $null -and $UserPol.get_item($zone) -ne $null){ $level = $UserPol.get_item($zone) ; $source = "UserPolicy" }
        elseif (!($MachineOnly) -and $UserPref -ne $null -and $UserPref.get_item($zone) -ne $null){ $level = $UserPref.get_item($zone) ; $source = "UserPreference" }
        elseif ($MachinePref -ne $null -and $MachinePref.get_item($zone) -ne $null) { $level = $MachinePref.get_item($zone) ; $source = "MachinePreference" }
        else { $level = 0 ; $source = "NotSet" }

        $templateObj = New-Object psobject
        $templateObj | Add-Member NoteProperty TemplateSource $source
        $templateObj | Add-Member NoteProperty Level $level

        $mergedZoneList.add($zone,$templateObj)
    }

    return $mergedZoneList
}

# Merge the user and machine policy and preference hives; generate the resultant settings
function Merge-IESettings
{
    Param
    (
        [parameter(Mandatory=$true)][AllowNull()]$MachinePol,
        [parameter(Mandatory=$true)][AllowNull()]$MachinePref,

        [parameter(Mandatory=$true,ParameterSetName="Machine")][Switch]$MachineOnly,

        [parameter(Mandatory=$true,ParameterSetName="User")][AllowNull()]$UserPol,
        [parameter(Mandatory=$true,ParameterSetName="User")][AllowNull()]$UserPref
    )  

    $mergedSettings = @()
    $settinglist = $script:zonemap[0].keys

    # Loop through the zones
    for ($zone = 1; $zone -le 4; $zone++)
    {
        # Loop through the settings
        foreach ($setting in $settinglist)
        {
            $MachinePolSetting = $MachinePol | Where-Object {$_.zone -eq $zone -and $_.name -eq $setting}
            $MachinePrefSetting = $MachinePref | Where-Object {$_.zone -eq $zone -and $_.name -eq $setting}
            if (!($MachineOnly))
            {
                $UserPolSetting = $UserPol | Where-Object {$_.zone -eq $zone -and $_.name -eq $setting}
                $UserPrefSetting = $UserPref | Where-Object {$_.zone -eq $zone -and $_.name -eq $setting}
            }
            if ($MachinePolSetting -ne $null) { $result = $MachinePolSetting; $source = "MachinePolicy"}
            elseif ($UserPolSetting -ne $null) { $result = $UserPolSetting; $source = "UserPolicy" }
            elseif ($UserPrefSetting -ne $null) { $result = $UserPrefSetting; $source = "UserPreference" }
            elseif ($MachinePrefSetting -ne $null) { $result = $MachinePrefSetting; $source = "MachinePreference" }
            else { $result = $null }

            if ($result -ne $null) 
            { 
                $result | Add-Member NoteProperty SettingSource $source -Force
                $mergedSettings += $result                     
            }

        }
    }
    if ($mergedsettings.count -eq 0) { return $null }
    else {return $mergedSettings}
}

# Convert hex value to name of security template
function ConvertTo-SecurityTemplateName
{
    Param
    (
        $intTemplate
    )

    switch ($intTemplate)
    {
    0x10000 { $strTemplate = "Low"; break }
    0x10500 { $strTemplate = "Medium-Low"; break }
    0x11000 { $strTemplate = "Medium"; break }
    0x11500 { $strTemplate = "Medium-High"; break }
    0x12000 { $strTemplate = "High"; break }
    default { $strTemplate = "Custom" }
    }

    return $strTemplate
}

# Get risky templates 
function Get-IERiskyTemplates
{
    Param
    (
        $DCName,
        $Username,
        $Template,
        $WOW64 = $false
    )
    
    # Are there any risky settings to return?
    $bRisksFound = $false

    # Create a template object to use
    $Risk = New-Object psobject
    $risk | Add-Member -name DCName -type NoteProperty -Value $DCName
    $risk | Add-Member -name Username -type NoteProperty -Value $Username
    $risk | Add-Member -name 32-bit -Type NoteProperty -value $WOW64

    if ($template.item(1).level -lt 0x10500) 
    { 
        $bRisksFound = $true
        $risk | Add-Member -name "Local Intranet" -type NoteProperty -value (ConvertTo-SecurityTemplateName $template.item(1).level)
        $risk | Add-Member -name "Local Intranet Source" -type NoteProperty -value $template.item(1).templatesource
    } 
    if ($template.item(2).level -lt 0x11000) 
    { 
        $bRisksFound = $true
        $risk | Add-Member -name "Trusted Sites" -type NoteProperty -value (ConvertTo-SecurityTemplateName $template.item(2).level) 
        $risk | Add-Member -name "Trusted Sites Source" -type NoteProperty -value $template.item(2).templatesource
    } 
    if ($template.item(3).level -lt 0x12000) 
    { 
        $bRisksFound = $true
        $risk | Add-Member -name "Internet" -type NoteProperty -value (ConvertTo-SecurityTemplateName $template.item(3).level)
        $risk | Add-Member -name "Internet Source" -type NoteProperty -value $template.item(3).templatesource
    } 
    if ($template.item(4).level -lt 0x12000) 
    { 
        $bRisksFound = $true
        $risk | Add-Member -name "Restricted Sites" -type NoteProperty -value (ConvertTo-SecurityTemplateName $template.item(4).level)
        $risk | Add-Member -name "Restricted Sites Source" -type NoteProperty -value $template.item(4).templatesource
    }                
 
    if ($bRisksFound) 
    {
        
        return $risk
        
    }
}
  
        
# Get the risky settings
# A setting is risky if:
#   1. It is less secure than the default
#   AND
#   2. It is less secure than the default for the current template
function Get-IERiskySettings
{
    Param
    (
        $DCName,
        $Username,
        $SettingList,
        $Templates,
        $WOW64 = $false
    )
    
    # Are there any risky settings to return?
    $RisksFound = 0
    
    # Create a setting object to use
    $Risk = New-Object psobject
    $risk | Add-Member -name DCName -type NoteProperty -Value $DCName
    $risk | Add-Member -name Username -type NoteProperty -Value $Username
    $risk | Add-Member -name 32-bit -Type NoteProperty -value $WOW64

    foreach ($setting in $SettingList)
    {
        $bRiskFound = $false
        # Find out if the setting is at the default for the current template
        $currentTemplate = $Templates.($setting.zone)

        # Find out the default value for the setting in the current template
        $templateDefault = $Script:templatemap.$currentTemplate.($setting.name)

        #Default case (the final elseif statement) assumes that a lower data value is more secure
        #The rest of the if-ifelse block handle cases where this is not the case
        if ("1809","2301","270c","1c00","2007" -contains $setting.name)
        {
            # Lower value is more secure for these settings
            if ($setting.data -gt $templateDefault -and $setting.data -gt $setting.defaultdata)
            {
                $bRiskFound = $true
            }
        }
        elseif ("1200","2000" -contains $setting.name)
        {
            # Possible values (from least to most secure are 0, 0x10000, 3)
            switch ($setting.data)
            {
                0 { if ( $templateDefault -gt 0 -and $setting.defaultdata -gt 0 ) { $bRiskFound = $true } ; break }
                0x10000 { if ($templateDefault -eq 3 -or $setting.defaultdata -eq 3) { $bRiskFound = $true } ; break }
                3 { $bRiskFound = $False ; break } # Most secure setting
            }
        }

        elseif ($setting.data -lt $templateDefault -and $setting.data -lt $setting.defaultdata)
        {
            # Higher value is more secure (most settings)
            $bRiskFound = $true
        }
        
        if ($bRiskFound)
        {
            $RisksFound ++
            $risk | Add-Member -name $RisksFound -type NoteProperty -value $setting
        }
    }

    if ($RisksFound -gt 0) 
    {
        $risk | Add-Member -Name SettingCount -type NoteProperty -Value $RisksFound
        return $risk
    }

}

# Get the IE ESC settings
function Get-IEESCSettings
{
    Param
    (
        $machinehive,
        $DCName
    )

    # Make sure none of our variables have values
    rv UserEnabled,AdminEnabled,ESC -ErrorAction SilentlyContinue

    $UserRegPath = "SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
    $AdminRegPath = "SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"

    $UserReg = $machinehive.opensubkey($UserRegPath)
    $AdminReg = $machinehive.opensubkey($AdminRegPath)

    if ($UserReg) { $UserEnabled = $UserReg.getvalue("IsInstalled") ; $UserReg.close() }
    if ($AdminReg) { $AdminEnabled = $AdminReg.getvalue("IsInstalled") ; $AdminReg.close() }

    if ($userenabled -ne $null -or $adminenabled -ne $null)
    {
        $ESC = new-object psobject
        $ESC | Add-Member -name DCName -type NoteProperty -Value $DCName
        $ESC | Add-Member -name Admin -type NoteProperty -Value $AdminEnabled
        $ESC | Add-Member -Name User -Type NoteProperty -Value $UserEnabled  
    }
    return $ESC
}

# Create an object to hold a single line of Template output
function New-IETemplateOutput
{
    Param
    (
        $templateset,
        $zone
    )

    $template = New-Object psobject
    $template | Add-Member -name DC -type NoteProperty -Value $templateset.DCName
    $template | Add-Member -name User -Type NoteProperty -Value $templateset.UserName
    $template | Add-Member -name 32-bit -type NoteProperty -Value $templateset.'32-bit'
    $template | Add-Member -Name Zone -type NoteProperty -Value $zone
    $template | Add-Member -name Setting -Type NoteProperty -Value $templateset.$zone
    $template | Add-Member -Name Source -Type NoteProperty -Value $templateset."$zone Source"

    return $template
}


# Write the results to CSV files
function Export-IEResults
{
    Param
    (
        $Templates,
        $Settings,
        $ESC
    )

    $TemplateFilePath = "$OutputPath\$filePrefix" + "_IETemplates.csv"
    $SettingFilePath = "$OutputPath\$filePrefix" + "_IESettings.csv"
    $ESCFilePath = "$OutputPath\$filePrefix" + "_IEESC.csv"

    # Output for Templates
    $TemplateOutput = @()
    foreach ($templateSet in $templates)
    {
        if ($templateSet.'Local Intranet' -ne $null)
        {
            $TemplateOutput += new-IETemplateOutput $templateset 'Local Intranet'
        }
        if ($templateSet.'Trusted Sites' -ne $null)
        {
            $TemplateOutput += new-IETemplateOutput $templateset 'Trusted Sites'
        }
        if ($templateSet.Internet -ne $null)
        {
            $TemplateOutput += new-IETemplateOutput $templateset 'Internet'
        }
        if ($templateSet.'Restricted Sites' -ne $null)
        {
            $TemplateOutput += new-IETemplateOutput $templateset 'Restricted Sites'
        }
    }
    
    $TemplateOutput | Export-Csv -NoTypeInformation -Path $TemplateFilePath

    # Output for Settings
    $SettingOutput = @()
    foreach ($settingSet in $Settings)
    {
        for ($i = 1 ; $i -le $Settingset.settingcount ; $i++)
        {
            $setting = New-Object psobject
            $setting | Add-Member -Name DC -Type NoteProperty -value $settingSet.DCName
            $setting | Add-Member -Name User -Type NoteProperty -value $settingSet.UserName
            $setting | Add-Member -Name 32-bit -Type NoteProperty -value $settingSet.'32-bit'
            $setting | Add-Member -Name Zone -Type NoteProperty -value (ConvertTo-ZoneName $settingSet.$i.zone)
            if ($settingset.$i.Description -ne $null)
            {
                $setting | Add-Member -Name Setting -Type NoteProperty -value $settingSet.$i.description
            }
            else
            {
                $setting | Add-Member -Name Setting -Type NoteProperty -value $settingSet.$i.name
            }
            $setting | Add-Member -Name Value -Type NoteProperty -value (ConvertTo-FriendlySetting $settingSet.$i.name $settingSet.$i.Data)
            $setting | Add-Member -Name 'Default Value' -Type NoteProperty -value (ConvertTo-FriendlySetting $settingSet.$i.name $settingSet.$i.defaultdata)
            $setting | Add-Member -Name SettingSource -Type NoteProperty -Value $settingset.$i.settingsource
            $SettingOutput += $setting
        }
    }

    $SettingOutput | Export-Csv -NoTypeInformation -Path $SettingFilePath

    # Output for ESC
    $ESC | Select-Object `
            @{e={$_.dcname};n="DC"},
            @{e={if($_.admin -eq 1){"Yes"}else{"No"}};n="Admin Enabled"},
            @{e={if($_.user -eq 1){"Yes"}else{"No"}};n="User Enabled"}`
        | Export-Csv -NoTypeInformation -Path $ESCFilePath
}

function ConvertTo-FriendlySetting
{
    Param
    (
        $setting,
        $value
    )

    $bValueFound = $false

    if ("1200","2000","1A00","1C00","2007" -contains $setting)
    {
        switch ($setting)
        {
            "1200" {if ($value -eq 0x10000) { $friendly = "Admin Approved" ; $bValueFound = $true ; break }}
            "2000" {if ($value -eq 0x10000) { $friendly = "Admin Approved" ; $bValueFound = $true ; break }}
            "1A00" { switch ($value) {
                        0 { $friendly = "Automatically logon with current username and password" ; $bValueFound = $true ; break }
                        0x10000 { $friendly = "Prompt for username and password" ; $bValueFound = $true ; break }
                        0x20000 { $friendly = "Automatic logon only in Intranet zone" ; $bValueFound = $true ; break }
                        0x30000 { $friendly = "Anonymous logon" ; $bValueFound = $true ; break }
                }
            }
            "1C00" { switch ($value) {
                        0 { $friendly = "Disable Java" ; $bValueFound = $true ; break }
                        0x10000 { $friendly = "High Safety" ; $bValueFound = $true ; break }
                        0x20000 { $friendly = "Medium Safety" ; $bValueFound = $true ; break }
                        0x30000 { $friendly = "Low Safety" ; $bValueFound = $true ; break }
                        default { $friendly = "Custom" ; $bValueFound = $true ; break }
                }
            }
            "2007" {if ($value -eq 0x10000) { $friendly = "High Safety" ; $bValueFound = $true ; break }}
        }
    }
    elseif ($setting -ne "1A00" -and $setting -ne "1C00")
    {
        switch ($value)
        {
            0 { $friendly = "Enabled" ; $bValueFound = $true ; break }
            1 { $friendly = "Prompt" ; $bValueFound = $true ; break }
            3 { $friendly = "Disabled" ; $bValueFound = $true ; break }
        }
    }
        
    if ($bValueFound) { return $friendly }
    else { return $value }
}

function ConvertTo-ZoneName
{
    Param
    (
        $zonenumber
    )

    switch ($zonenumber)
    {
        1 { $zonename = "Local Intranet"; break }
        2 { $zonename = "Trusted Sites"; break }
        3 { $zonename = "Internet"; break }
        4 { $zonename = "Restricted Sites"; break }
    }

    return $zonename
}

#### Main Function Execution ####

#Define a variable to hold all the IE settings
$All_IESettings = @()
$IE_ESC = @()
$Script:zonemap = Initialize-IEZoneDefaults
$Script:templatemap = Initialize-IETemplateDefaults

Write-Verbose "Beginning collection of Internet Explorer settings"
# Loop through each DC and collect it's IE settings
foreach ($dc in $DCList)
{
    # Establish a connection to HKEY_LOCAL_MACHINE
    try { $machinehive = Connect-RemoteRegistry 'LocalMachine' $dc }
    catch { Write-Warning "Could not connect to Domain controller ($dc)"; continue }
  
    Write-Verbose "Collecting Internet Explorer settings for $dc"
    # Get the Internet Explorer Enhanced Security Configuration settings
    $IE_ESC += get-IEESCSettings $machinehive $dc
    
    write-verbose "`tCollecting machine settings"
    # Check whether the DC is set to only use machine policy. If it is, we don't have to check user hives
    $bMachineOnly = Test-IEMachineOnly $machinehive

    # Get the settings for the Machine Policy Hive
    $MachinePolTemplates = Get-IEZoneTemplates $machinehive.opensubkey("software\policies\microsoft\windows\currentversion")
    $MachinePolSettings = Get-IEZoneSettings $machinehive.opensubkey("$Script:IEPolicyReg\Zones")

    # Get the settings for the Machine Preference Hive (64-bit)
    $MachinePrefTemplates = Get-IEZoneTemplates $machinehive.opensubkey("$Script:IEPreferenceReg\Zones")
    $MachinePrefSettings = Get-IEZoneSettings $machinehive.opensubkey("$Script:IEPreferenceReg\Zones")

    # Get the settings for the Machine Preference Hive (32-bit)
    $MachinePrefTemplates32 = Get-IEZoneTemplates $machinehive.opensubkey("$Script:IEPreference32Reg\Zones")
    $MachinePrefSettings32 = Get-IEZoneSettings $machinehive.opensubkey("$Script:IEPreference32Reg\Zones")


    if ($bMachineOnly)
    {
        $MachineTemplates = Merge-IETemplates -MachineOnly -MachinePol $MachinePolTemplates -MachinePref $MachinePrefTemplates
        $MachineTemplates32 = Merge-IETemplates -MachineOnly -MachinePol $MachinePolTemplates -MachinePref $MachinePrefTemplates32
        
        $MachineSettings = Merge-IESettings -MachineOnly -MachinePol $MachinePolSettings -MachinePref $MachinePrefSettings 
        $MachineSettings32 = Merge-IESettings -MachineOnly -MachinePol $MachinePolSettings -MachinePref $MachinePrefSettings32 

        $DCConfig = New-Object PSObject
        $DCConfig | Add-Member -name DCName -type NoteProperty -Value $dc
        $DCConfig | Add-Member -Name Username -type NoteProperty -Value "<MACHINE_ONLY>"
        $DCConfig | Add-Member -name Templates -type NoteProperty -Value $MachineTemplates
        $DCConfig | Add-Member -Name Templates32 -Type NoteProperty -Value $MachineTemplates32
        $DCConfig | Add-Member -Name Settings -Type NoteProperty -Value $MachineSettings
        $DCConfig | Add-Member -Name Settings32 -Type NoteProperty -Value $MachineSettings32

        $All_IESettings += $DCConfig
        
    }
    else 
    {
        # Establish a connection to HKEY_USERS
        try { $userhive = Connect-RemoteRegistry 'Users' $dc }
        catch { Write-Warning "Could not connect to Domain controller ($dc)"; continue }
        
        Write-Verbose "`tCollecting user settings"
        # Get the list of users with registry settings
        $userlist = Get-RegistryUserList $userhive

        # Loop through the users and get the User settings for each
        foreach ($user in $userlist)
        {
            # Keep track of where we are at
            try { $username = ConvertFrom-SID $user } catch { $username = $user }

            Write-Verbose "`t`tCollecting user settings for $username"
            # Get the settings for the Machine Policy Hive
            $UserPolTemplates = Get-IEZoneTemplates $Userhive.opensubkey("$user\software\policies\microsoft\windows\currentversion")
            $UserPolSettings = Get-IEZoneSettings $Userhive.opensubkey("$user\$Script:IEPolicyReg\Zones")

            # Get the settings for the User Preference Hive (64-bit)
            $UserPrefTemplates = Get-IEZoneTemplates $Userhive.opensubkey("$user\$Script:IEPreferenceReg\Zones")
            $UserPrefSettings = Get-IEZoneSettings $Userhive.opensubkey("$user\$Script:IEPreferenceReg\Zones")

            # Get the settings for the User Preference Hive (32-bit)
            $UserPrefTemplates32 = Get-IEZoneTemplates $Userhive.opensubkey("$user\$Script:IEPreference32Reg\Zones")
            $UserPrefSettings32 = Get-IEZoneSettings $Userhive.opensubkey("$user\$Script:IEPreference32Reg\Zones") 
        
            $UserTemplates = Merge-IETemplates -MachinePol $MachinePolTemplates -MachinePref $MachinePrefTemplates -UserPol $UserPolTemplates -UserPref $UserPrefTemplates
            $UserTemplates32 = Merge-IETemplates -MachinePol $MachinePolTemplates -MachinePref $MachinePrefTemplates32 -UserPol $UserPolTemplates -UserPref $UserPrefTemplates32

            $UserSettings = Merge-IESettings -MachinePol $MachinePolSettings -MachinePref $MachinePreSettings -UserPol  $UserPolSettings -UserPref $UserPrefSettings
            $UserSettings32 = Merge-IESettings -MachinePol $MachinePolSettings -MachinePref $MachinePreSettings32 -UserPol  $UserPolSettings -UserPref $UserPrefSettings32

            $UserConfig = New-Object PSObject
            $UserConfig | Add-Member -name DCName -type NoteProperty -Value $dc
            $UserConfig | Add-Member -Name Username -type NoteProperty -Value $username
            $UserConfig | Add-Member -name Templates -type NoteProperty -Value $UserTemplates
            $UserConfig | Add-Member -Name Templates32 -Type NoteProperty -Value $UserTemplates32
            $UserConfig | Add-Member -Name Settings -Type NoteProperty -Value $UserSettings
            $UserConfig | Add-Member -Name Settings32 -Type NoteProperty -Value $UserSettings32

            $All_IESettings += $UserConfig     
        }  
        $userhive.close()
    }
    $machinehive.close()
}

# Extract the templates and settings that are riskier than default
$RiskyTemplates = @()
$RiskySettings = @()

foreach ($setting in $All_IESettings)
{
    Write-Verbose "Evaluating security settings for $($setting.dcname)"
    $riskyTemplates += get-IERiskyTemplates $setting.dcname $setting.username $setting.templates
    $riskyTemplates += get-IERiskyTemplates $setting.dcname $setting.username $setting.templates32 $true

    $riskySettings += get-IERiskySettings $setting.dcname $setting.username $setting.settings $setting.templates
    $riskySettings += get-IERiskySettings $setting.dcname $setting.username $setting.settings32 $setting.templates32 $true        
}

# Output to CSV files
Export-IEResults $RiskyTemplates $RiskySettings $IE_ESC