[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DomainList,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null,
    [Parameter(mandatory=$false,Position=6)][alias("noscril")][switch]$ExcludeSCRIL
)

if ($Standalone) 
{ 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }

    if ($DomainList)
    {
        $domains_detail = @()
        foreach ($domain in $domainlist)
        {
            # Convert FQDN to DN
            $domainnamearray = $domain.split(".")
            $domainDN = "dc=" + $domainnamearray[0]
            for ($i=1;$i -lt $domainnamearray.count; $i++) { $domaindn += ",dc=" + $domainnamearray[$i] }

            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $domain
            $domainobj | Add-Member NoteProperty DomainDN $domaindn
            $domains_detail += $domainobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose        
    } 
} 

if ($ExcludeSCRIL)
{
    $Script:SCRILInUAC = $false
}
else
{
    $Script:SCRILInUAC = $true
}

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

# Given a Primary Group ID, find the name of the AD group
function ConvertTo-GroupName($pgid,$domain)
{
    # Get the domain SID
    $byteObjectSID = ([adsi]"LDAP://$domain").properties.objectsid
    $strObjectSID = (New-Object System.Security.Principal.SecurityIdentifier($($byteObjectSID),0)).value
   
    $ID = New-Object System.Security.Principal.SecurityIdentifier("$strObjectSID" + "-" + $pgid)
    $groupname = $ID.Translate( [System.Security.Principal.NTAccount])
    Return $groupname.value.split("\")[1]
}

function convertTo-datetime($int64)
{
    return [datetime]::FromFileTimeUTC($int64)
}

function checkAccountEnabled($uac)
{
    #check to see if the account is enabled or disabled.
    
    $disabledTest = 0x2
    
    if(($disabledTest -band $uac) -ne 0)
    {
        #account is disabled
        return $false
    }
    else
    {
        #account is enabled
        return $true
    }
}

function get-threshold($domainDN)
{
    #This function will get the domain's password maximum age value and convert it to days
    #Then will multiply the result by 3 to establish the "stale" threshold
    #Stale threshold value is in FileTimeUTC format
    
    #Get the password max age from the domain
    $pwdMaxAge = [ADSI]"LDAP://$($domainDN)"
    #convert this from ADSLargeInt to a workable int64
    $pwdMaxAge = $pwdMaxAge.ConvertLargeIntegerToInt64($pwdMaxAge.maxPwdAge.value)
    #establish the timespan from 'beginning of time' to the when the pwdmaxage is setting, then convert to days
    $pwdMaxAgeDays = (New-TimeSpan (get-date 1/1/1601).addticks($pwdMaxAge) (get-date 1/1/1601)).days
    
    #set the threshold as 3x the pwdmaxage
    $staleThreshold = ($pwdMaxAgeDays * 3)
    
    #convert the threshold days into FileTimeUTC format to be used for LDAP queries
    $date = date
    $thresholdUTC = $date.addDays(-$staleThreshold)
    $thresholdUTC = $thresholdUTC.ToFileTimeUTC()
    
    # Create a password object holder
    $pwdSettingsObj = new-Object PSObject
    $pwdSettingsObj | Add-Member NoteProperty PwdMaxAge $pwdMaxAgeDays
    $pwdSettingsObj | Add-Member NoteProperty StaleThreshold $staleThreshold
    $pwdSettingsObj | Add-Member NoteProperty ThresholdUTC $thresholdUTC
    
    
    return $pwdSettingsObj
}

function get-Accounts($domainDN,$domain,$pwdMaxAge)
{
    <#
        .SYNOPSIS
            Get all the accounts and filter the ones we want
        .PARAMETERS domainDN
            Distinguished name of the domain
        .PARAMETERS domain
            DNS name of the domain
    #>

    $staledays = $pwdMaxAge * 3
    $staledate = ((get-date).AddDays(-$staledays)).ToFileTimeUtc()
    $oneyearago = ((get-date).adddays(-365)).ToFileTimeUtc()

    $AcctSearcher = New-Object System.DirectoryServices.DirectorySearcher
    $AcctSearcher.searchRoot = [ADSI]"LDAP://$($domainDN)"
    $AcctSearcher.searchscope = "Subtree"
    $AcctSearcher.CacheResults = $true
    $AcctSearcher.PageSize = 100    
    $AcctSearcher.SizeLimit = 0
    $AcctSearcher.PropertiesToLoad.Add("admincount") | out-null
    $AcctSearcher.PropertiesToLoad.Add("distinguishedname") | out-null
    $AcctSearcher.PropertiesToLoad.Add("msDS-ResultantPso") | out-null
    $AcctSearcher.PropertiesToLoad.Add("name") | out-null
    $AcctSearcher.PropertiesToLoad.Add("SamAccountName") | out-null
    $AcctSearcher.PropertiesToLoad.Add("Description") | out-null
    $AcctSearcher.PropertiesToLoad.Add("lastLogonTimestamp") | out-null
    $AcctSearcher.PropertiesToLoad.Add("pwdLastSet") | out-null
    $AcctSearcher.PropertiesToLoad.Add("userAccountControl") | out-null
    $AcctSearcher.PropertiesToLoad.Add("whenChanged") | out-null
    $AcctSearcher.PropertiesToLoad.Add("whenCreated") | out-null
    $AcctSearcher.PropertiesToLoad.Add("primaryGroupID") | out-null

    $interesting = @()
    
    
    <#
    Filter for where UserAccountControl is set with one of the following non-standard values:
    Property Flag                  Description                                    Value
    PASSWD_NOTREQD                 Password Not Required                          0x000020
    PASSWD_CANT_CHANGE             User cannot change password                    0x000040
    ENCRYPTED_TEXT_PWD_ALLOWED     Store Password Using Reversible Encryption     0x000080
    DONT_EXPIRE_PASSWORD           Password Never Expires                         0x010000
    SMARTCARD_REQUIRED             Smartcard is required for interactive logon    0x040000
    TRUSTED_FOR_DELEGATION         Account trusted for delegation to a service    0x080000
    NOT_DELEGATED                  Account is sensitive and cannot be delegated   0x100000
    USE_DES_KEY_ONLY               Use Kerberos DES Encryption types              0x200000
    DONT_REQ_PREAUTH               Do not require Kerberos preauthentication      0x400000  

    Sum = 0x7d00e0 = 8192224
    If all accounts in the environment use Smartcard, use 0x7900e0 = 7930080
    
    
    http://support.microsoft.com/kb/305144   
    #>    
    if ($Script:SCRILInUAC)
    {
        $targetUAC = 0x7d00e0
    }
    else
    {
        $targetUAC = 0x7900e0
    }
    
    # Filtering interesting accounts via an LDAP query doesn't work well because a number of the attributes we're interested in are not indexed.
    # Instead, we get all user accounts (based on sAMAccountType=805306368) and perform the filter operation client side

    Write-Verbose "`t`tSearching for accounts. This may take a while for large environments."
    $AcctSearcher.filter = "(sAMAccountType=805306368)"
    $Accts = $AcctSearcher.FindAll()
    $interesting +=  $accts | where { 
                                $($_.properties.admincount) -eq 1 -or   # Users with admincount = 1
                                ($($_.properties.useraccountcontrol) -band $targetUAC) -ne 0 -or # Users with non-default UserAccountControl Flags
                                $($_.properties.'msds-resultantpso') -ne $null -or # Users with a FGPP configured
                                ($($_.properties.pwdlastset) -lt $staledate -and $($_.properties.lastlogontimestamp) -lt $staledate) -or # stale users
                                ($($_.properties.pwdlastset) -lt $oneyearago -and ($($_.properties.useraccountcontrol) -band 0x2) -ne 0) -or # enabled users with passwords over 1 year old
                                ($($_.properties.primarygroupid) -ne 513) # users whose primary group is not "Domain Users"
                                }
    Write-Verbose "`t`tCollected $($interesting.count) accounts so far."
     

    $interestingAccounts = @()
    
    foreach ($account in $interesting)
    {
        $Acct = new-Object PSObject
        $Acct | Add-Member NoteProperty Domain $domain
        $Acct | Add-Member NoteProperty Name $($account.properties.name)
        $Acct | Add-Member NoteProperty SAMAccountName $($account.properties.samaccountname)
        $Acct | Add-Member NoteProperty DN $($account.properties.distinguishedname)
        $Acct | Add-Member NoteProperty Description $($account.properties.description)
        $Acct | Add-Member NoteProperty LastPasswordChange (convertTo-datetime $($account.properties.pwdlastset))
        $Acct | Add-Member NoteProperty DaysPwdUnchanged ((new-TimeSpan (convertTo-datetime $($account.properties.pwdlastset)) $(Get-Date)).days)
        $Acct | Add-Member NoteProperty LastLogonTimestamp (convertTo-datetime $($account.properties.lastlogontimestamp))
        $Acct | Add-Member NoteProperty DaysSinceLastLogon ((new-TimeSpan (convertTo-datetime $($account.properties.lastlogontimestamp)) $(Get-Date)).days) 
        $Acct | Add-Member NoteProperty UAC $($account.properties.useraccountcontrol)
        $Acct | Add-Member NoteProperty ResultantPSO $($account.Properties.'msds-resultantpso')
        $Acct | Add-Member NoteProperty AdminCount $($account.properties.admincount)
        if ($acct.admincount -notmatch "\d+") { $acct.admincount = 0 }
        if ( $($account.properties.primarygroupid) -eq 513 )
        {
            $Acct | Add-Member NoteProperty PrimaryGroup "Domain Users"
        }
        else
        {
            $Acct | Add-Member NoteProperty PrimaryGroup (convertto-groupname $($account.properties.primarygroupid) $domain)
        }
        $Acct | Add-Member NoteProperty WhenChanged $($account.properties.whenchanged)
        $Acct | Add-Member NoteProperty WhenCreated $($account.properties.whencreated)
            
        $interestingAccounts += $Acct
        if ($interestingAccounts.count % 100 -eq 0) { Write-Verbose "Processed $($interestingAccounts.count) accounts." }
    }

    $acctsearcher.dispose()
    return $interestingAccounts
}

########################
########################
## Main Execution Start

$NonStdAccounts = @()

foreach ($domain in $domains_detail)
{
    $threshhold = get-threshold $domain.domainDN
    
    Write-Verbose "`tExtracting accounts from domain: $($domain.domain)"
    
    $results = get-Accounts $domain.domainDN $domain.domain $threshhold.pwdmaxage
    
    #check that there are results
    if($results)
    {
        $NonStdAccounts += $results
    }
}#end loop

#export all accounts to CSV  
Write-Verbose "`tWriting output to $($filePrefix)_Interesting_Accts.csv"  
$NonStdAccounts | Select-Object `
    Domain,
    Name,
    SAMAccountName,
    DN,
    Description,
    @{e={if ($_.AdminCount -match "\d") { $_.AdminCount } else { 0 }};n="AdminCount"},
    @{e={$_.LastPasswordChange};n="Last Password Change"},
    @{e={$_.DaysPwdUnchanged};n="Days Password Unchanged"},
    @{e={$_.LastLogonTimestamp};n="Last Logon Timestamp"},
    @{e={$_.DaysSinceLastLogon};n="Days Since Last Logon"},
    @{e={if (($_.uac -band 0x2) -eq 0) { $true } else { $false }};n="Account Enabled"},
    @{e={if (($_.uac -band 0x20) -ne 0) { $true } else { $false }};n="Password Not Required"},
    @{e={if (($_.uac -band 0x40) -ne 0) { $true } else { $false }};n="User cannot change password"},
    @{e={if (($_.uac -band 0x80) -ne 0) { $true } else { $false }};n=" Store Password Using Reversible Encryption"},
    @{e={if (($_.uac -band 0x10000) -ne 0) { $true } else { $false }};n="Password Never Expires"},
    @{e={if (($_.uac -band 0x40000) -ne 0) { $true } else { $false }};n="Smartcard is required for interactive logon"},
    @{e={if (($_.uac -band 0x100000) -ne 0) { $true } else { $false }};n="Account is sensitive and cannot be delegated"},
    @{e={if (($_.uac -band 0x200000) -ne 0) { $true } else { $false }};n="Use Kerberos DES Encryption types"},
    @{e={if (($_.uac -band 0x400000) -ne 0) { $true } else { $false }};n="Do not require Kerberos preauthentication"},
    @{e={$_.uac};n="Raw UserAccountControl value"},
    @{e={$_.resultantpso};n="Effective Password Settings Object"},
    @{e={$_.primarygroup};n="Primary Group"},
    @{e={$_.WhenChanged};n="Modified Time"},
    @{e={$_.WhenCreated};n="Created Time"} | `
Export-Csv -NoTypeInformation "$($filePrefix)_Interesting_Accts.csv"

Write-Verbose "###############################" 