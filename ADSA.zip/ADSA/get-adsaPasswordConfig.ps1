﻿<#
.SYNOPSIS
Collect information on domain password policy and fine-grained password policies (Password Settings Objects)
#>

[CmdletBinding()]
Param
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DomainList,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null,

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
{
    $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
}

if ($Standalone)
{
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }

    if ($DomainList)
    {
        $domains_detail = @()
        foreach ($domain in $domainlist)
        {
            # Convert FQDN to DN
            $domainnamearray = $domain.split(".")
            $domainDN = "dc=" + $domainnamearray[0]
            for ($i=1;$i -lt $domainnamearray.count; $i++) { $domaindn += ",dc=" + $domainnamearray[$i] }

            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $domain
            $domainobj | Add-Member NoteProperty DomainDN $domaindn
            $domains_detail += $domainobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose      
    } 
} 

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

function convertto-intervaldays ($FileTimeInterval)
{
    # 100 nano seconds in seconds
    $100nanoseconds = [math]::pow(10,-7)
    
    # number of seconds in a day
    $secondsinday = 86400
    
    # Convert the number of 100-nanosecond intervals to seconds, then divide by the number of seconds in a day
    $dayinterval = $FileTimeInterval * $100nanoseconds / $secondsinday

    # return the absolute value, since we want to deal with positive numbers of days
    return [math]::abs($dayinterval)
}

function convertto-intervalminutes ($FileTimeInterval)
{
    # 100 nano seconds in seconds
    $100nanoseconds = [math]::pow(10,-7)
    
    # number of seconds in a minute
    $secondsinmin = 60
    
    # Convert the number of 100-nanosecond intervals to seconds, then divide by the number of seconds in a day
    $dayinterval = $FileTimeInterval * $100nanoseconds / $secondsinmin

    # return the absolute value, since we want to deal with positive numbers of days
    return [math]::abs($dayinterval)
}

function get-domainPasswordPolicy ($domainDN)
{
    Write-Verbose "Collecting information on domain password policy."
    $pwdObj = New-Object PSObject
    $domain = [adsi]"LDAP://$domainDN"
    $domainFQDN = $domaindn.tolower().replace(",dc=",".").replace("dc=","")
    $pwdObj | Add-Member NoteProperty Domain $domainFQDN
    $pwdObj | Add-Member NoteProperty Name "Default Password Policy"
    $pwdObj | Add-Member NoteProperty Precedence 0
    $pwdobj | Add-Member NoteProperty History $($domain.pwdHistoryLength)
    
    $maxpwdage = $domain.ConvertLargeIntegerToInt64($($domain.maxPwdAge))
    $pwdobj | Add-Member NoteProperty MaxAge (convertto-intervaldays $maxpwdage)

    $minpwdage = $domain.ConvertLargeIntegerToInt64($($domain.minPwdAge))
    $pwdobj | Add-Member NoteProperty MinAge (convertto-intervaldays $minpwdage)

    $pwdObj | Add-Member NoteProperty MinLen $($domain.minPwdLength)

    $pwdComplex = if (($($domain.pwdProperties) -band 0x1) -eq 0x1) {$true} else {$false}
    $pwdObj | Add-Member NoteProperty Complex $pwdComplex

    $pwdPlainText = if (($($domain.pwdProperties) -band 0x10) -eq 0x10) {$true} else {$false}
    $pwdObj | Add-Member NoteProperty RevEnc $pwdPlainText

    $pwdObj | Add-Member NoteProperty LockoutAttempts $($domain.lockoutThreshold)
    if ($pwdObj.LockoutAttempts -notmatch "\d+") {$pwdObj.LockoutAttempts = 0}
    
    $lockoutWindow = $domain.ConvertLargeIntegerToInt64($($domain.lockoutobservationwindow))
    $pwdObj | Add-Member NoteProperty LockoutWindow (convertto-intervalminutes $lockoutWindow)
    if ($pwdObj.LockoutWindow -notmatch "\d+") {$pwdObj.LockoutWindow = 0}
    
    $lockoutDuration = $domain.ConvertLargeIntegerToInt64($($domain.lockoutduration))
    $pwdObj | Add-Member NoteProperty LockoutDuration (convertto-intervalminutes $lockoutDuration)

    return $pwdObj
}

function get-passwordSettingsObjects ($domainDN)
{
    Write-Verbose "Collecting information on fine-grained password policies"
    $domain = [adsi]"LDAP://$domainDN"
    $rootdse = new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
    $schema = $($rootdse.schemaNamingContext)
    $psoSearcher = New-Object System.DirectoryServices.DirectorySearcher

    $psoSearcher.filter = "objectCategory=CN=ms-DS-Password-Settings,$schema"
    $psoSearcher.SearchRoot = "LDAP://$domainDN"
    $psoSearcher.SearchScope = "Subtree"
    $psoSearcher.CacheResults = $true
    $psoSearcher.SizeLimit = 0
    $psoSearcher.PageSize = 1000

    $pwdSettingsObjects = $psoSearcher.findall()
    
    Write-Verbose ("Found " + $pwdSettingsObjects.count + " password settings objects.")
    
    if ($pwdSettingsObjects.count -eq 0) {return} else { $psoArray = @() }
    
    $domainFQDN = $domaindn.tolower().replace(",dc=",".").replace("dc=","")

    foreach ($pso in $pwdSettingsObjects)
    {
    
        $pwdObj = New-Object PSObject
    
        $pwdObj | Add-Member NoteProperty Domain $domainFQDN
        $pwdObj | Add-Member NoteProperty Name $($pso.properties.name)
        $pwdObj | Add-Member NoteProperty Precedence $($pso.properties.'msds-passwordsettingsprecedence')    
        if ($pwdObj.Precedence -notmatch "\d+") {$pwdObj.Precedence = 0}
        $pwdObj | Add-Member NoteProperty AppliesTo (@($($pso.Properties.'msds-psoappliesto')) -join ' | ')
        $pwdobj | Add-Member NoteProperty History $($pso.properties.'msds-passwordhistorylength')    
        $pwdobj | Add-Member NoteProperty MaxAge (convertto-intervaldays $($pso.properties.'msds-maximumpasswordage'))
        $pwdobj | Add-Member NoteProperty MinAge (convertto-intervaldays $($pso.properties.'msds-minimumpasswordage'))
        $pwdObj | Add-Member NoteProperty MinLen $($pso.properties.'msds-minimumpasswordlength')
        $pwdObj | Add-Member NoteProperty Complex $($pso.properties.'msds-passwordcomplexityenabled')
        $pwdObj | Add-Member NoteProperty RevEnc $($pso.properties.'msds-passwordreversibleencryptionenabled')
        $pwdObj | Add-Member NoteProperty LockoutAttempts $($pso.properties.'msds-lockoutthreshold')
        if ($pwdObj.LockoutAttempts -notmatch "\d+") {$pwdObj.LockoutAttempts = 0}
        $pwdObj | Add-Member NoteProperty LockoutWindow (convertto-intervalminutes $($pso.properties.'msds-lockoutobservationwindow'))
        if ($pwdObj.LockoutWindow -notmatch "\d+") {$pwdObj.LockoutWindow = 0}
        $pwdObj | Add-Member NoteProperty LockoutDuration (convertto-intervalminutes $($pso.properties.'msds-lockoutduration'))
        $psoArray += $pwdObj
    }

    return $psoArray
}

# Create an array to hold all of the Password Info
$PasswordConfigs = @()

foreach ($domain in $domains_detail)
{
    Write-Verbose ("`tCollecting password information for domain: " + $($domain).domain)
    # Get domain password info
    $PasswordConfigs += get-domainPasswordPolicy $($domain).domaindn
    # Get domain PSO info
    $PasswordConfigs += get-passwordSettingsObjects $($domain).domaindn
}

$configtable = $passwordconfigs | Select-Object `
    @{e={$_.Domain};n="Domain"},
    @{e={$_.Name};n="Name"},
    @{e={$_.Precedence};n="PSO Precedence"},
    @{e={$_.History};n="Enforce Password History"},
    @{e={$_.MaxAge};n="Maximum Password Age"},
    @{e={$_.MinAge};n="Minimum Password Age"},
    @{e={$_.MinLen};n="Minimum Password Length"},            
    @{e={$_.Complex};n="Complex Passwords Required"},
    @{e={$_.RevEnc};n="Reversible Encryption Enabled"},
    @{e={$_.LockoutAttempts};n="Failed logon attempts allowed"},
    @{e={$_.LockoutWindow};n="Reset failed attempts after (min)"},
    @{e={$_.LockoutDuration};n="Lockout duration (min)"},
    @{e={$_.AppliesTo};n="PSO Applies to"}

$configtable | Export-Csv -NoTypeInformation "$($filePrefix)_PasswordConfig.csv"
