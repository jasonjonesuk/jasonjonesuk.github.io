﻿[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DCList, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null,   

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

# Make sure we have appropriate input for running standalone
if ($Standalone) 
{ 
    $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring()
    if ($DCList)
    {
        $All_DCs = @()
        foreach ($dc in $dclist)
        {
            $dcnamearray = $dc.split(".",2)
            $dcobj = New-Object psobject
            $dcobj | Add-Member NoteProperty Name $dcnamearray[0]
            $dcobj | Add-Member NoteProperty Domain $dcnamearray[1]
            $dcobj | Add-Member NoteProperty FQDN $dc
            $All_DCs += $dcobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $All_DCs = Get-ADSATargetDCs -omitDomains $omitDomains -verbose
        
    } 
}

if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
{
    $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
}

#make sure no stale variables exist, remove them if they do
rv dns_servers, ver, zones, dns_zones -ErrorAction silentlycontinue

Set-Variable -Name DNS_Servers -Value @() -Scope script

Write-Verbose "Gathering DNS zones from all DCs.`n###############################"

###### DNS lists
function Convert-Zones($servername)
{#converts zone info to an easier format to work with
    function  Convert-Delimited([regex]$from,[string]$to)
    {
        #wicked regex and string replace....kudos to the internets
        #takes specified char and replaces with a specified char
      process
      {
        $_ = $_ -replace "(?:`"((?:(?:[^`"]|`"`"))+)(?:`"$from|`"`$))|(?:((?:.(?!$from))*.)(?:$from|`$))","Þ`$1`$2Þ$to"
        $_ = $_ -replace "Þ(?:$to|Þ)?`$","Þ"
        $_ = $_ -replace "`"`"","`"" -replace "`"","`"`""
        $_ = $_ -replace "Þ((?:[^Þ`"](?!$to))+)Þ($to|`$)","`$1`$2"
        $_ = $_ -replace "Þ","`"" -replace "Þ","`""
        $_
      }
    }

    function parseZones($zones)
    {
        #first, get the version of dnscmd that is being used.  Yes this is kludgy
        $ver = (gcm dnscmd).fileversioninfo.productversion
        $EOF = 0
        ##This needs some robustness work
        switch($ver)
        {
            #Win XP SP2 dnscmd
            '5.1.2600.0' {$EOF = 3}
            #Win 2003 x64 SP2 dnscmd
            '5.2.3790.1830' {$EOF = 3}
            #Win 2003 x86 SP2 dnscmd
            '5.2.3790.0' {$EOF = 3}
            #Win 2008 SP2 x86/x64 dnscmd
            '6.0.6001.18000' {$EOF = 5}
            #Win 2008R2/7 x64 RTM dnscmd
            '6.1.7600.16385' {$EOF = 5}
            #Win 2012/8 x64 RTM dnscmd
            '6.2.9200.16384' {$EOF = 5}
            #Win 20128R2/8.1 x64 RTM dnscmd
            '6.3.9600.16384' {$EOF = 5}



        }
        #trim the zone output, then change to csv from space separated values if one or more spaces exist
        $zones = $zones[6..($zones.Length-$EOF)] | Convert-Delimited " +" ","
        $zones = ConvertFrom-Csv $zones -Delimiter "," -Header "ZoneName","Type","Storage","Properties" 
        #delete the temp zones file which was only used to convert to pretty csv format
        return $zones
    }

    #enum and get zones from specified server
    $zones = dnscmd $servername /enumzones
    
    if($zones -match "RPC_S_SERVER_UNAVAILABLE")
    {
        #Return the error to skip this server because server cannot be accessed via RPC
        return "Error|RPC Server Unavailable"
    }
    elseif($zones -match "ERROR_ACCESS_DENIED")
    {
        #Return the error to skip this server because server returns access denied 
        #Note: one possible reason is running 2003 version dnscmd against Server2008R2
        return "Error|Access Denied"
    }
    elseif($zones -match "failed")
    {
        #Return the error to skip this server because server returns other error 
        return "Error|dnscmd.exe error: $zones"
    }
    else
    {
        #parse the zones and convert delimiter to a ',' then RETURN the object
        return parseZones $zones
    }    
}    

function extract_zones($servername,$domain)    
{    
    #this array will contain all the zones for all servers
    $DNS_Zones = @()
    
    # Create DNS Server Object to hold the server's info
    $serverObj = New-Object PSObject
    $serverObj | Add-Member NoteProperty Domain $domain
    $serverObj | Add-Member NoteProperty ServerName $servername
        
    # get the server info
    ## TODO: do something with this info    
    $dns_serverinfo += dnscmd $servername /info    
   
    # Convert the dnscmd output per zone into something useful
    Convert-Zones $servername | %{

        # Create DNS Zone Object to hold the zone's info
        $zoneObj = New-Object PSObject
        #if there was an RPC or access denied error then alert and create the zone object with error info
        if(($_.gettype().name -eq "String") -and ($_.split('|')[0] -match "Error"))
        {
            #the server is unreachable via RPC or access denied, inform via inserting txt
            Write-warning "`t Cannot connect to server: $($servername) $($_.split('|')[1])" 
            $zoneObj | Add-Member NoteProperty Domain $domain
            $zoneObj | Add-Member NoteProperty ServerName $servername
            $zoneObj | Add-Member NoteProperty ZoneName "ERROR connecting to server $($_.split('|')[1])"
            $zoneObj | Add-Member NoteProperty ZoneType $null
            $zoneObj | Add-Member NoteProperty SecureUpdates $null
            $zoneObj | Add-Member NoteProperty ADIntegrated $null
            $zoneObj | Add-Member NoteProperty Partition $null
            $DNS_Zones += $zoneObj
        }
        else
        {
            Write-Verbose "`tSifting DNS Zone: $($_.zonename)"
        
        # Get the zone info and process it to extract desired info                             
        $zoneInfo = dnscmd $servername /zoneinfo $_.zonename

            $zonetype = $_.type
            $DSintegrated = $zoneInfo | Select-String "ds integrated"
                $DSintegrated = $DSintegrated.toString()
                $DSintegrated = $DSintegrated.substring($DSintegrated.indexof("=")+1).trim()
            $secureUpdate = $zoneInfo | Select-String "update"
                $secureUpdate = $secureUpdate.toString()
                $secureUpdate = $secureUpdate.substring($secureUpdate.indexof("=")+1).trim()
            $partition = $zoneInfo | Select-String "directory partition"
            #check that the partition field is not blank.  it can be blank and ok for zones like GlobalNamesCache
            if(!$partition){$partition = ""}
            else
            {
                $partition = $partition.toString()
                $partition = $partition.substring($partition.indexof("=")+1,$partition.indexof(" ")).trim()
             }

        #convert secureupdate value to friendly names
        switch ($secureupdate)
         {
            0 {$secureupdate = "No Dynamic Update"}
            1 {$secureupdate = "Non-secure and Secure"}
            2 {$secureupdate = "Secure Only"}
         }

        #Assemble the zone object with the collected properties
        $zoneObj | Add-Member NoteProperty Domain $domain
        $zoneObj | Add-Member NoteProperty ServerName $servername
        $zoneObj | Add-Member NoteProperty ZoneName $_.zonename
        $zoneObj | Add-Member NoteProperty ZoneType $zoneType
        $zoneObj | Add-Member NoteProperty SecureUpdates $secureUpdate
        $zoneObj | Add-Member NoteProperty ADIntegrated $DSintegrated
        $zoneObj | Add-Member NoteProperty Partition $partition
        
        $DNS_Zones += $zoneObj
        }
    }
    
    # add the DNS_Zones to the server object
    $serverObj | Add-Member NoteProperty Zones $DNS_Zones

    # add the server object to the DNS_Servers array collection
    Return $serverObj
    
}
########################
########################
## Main Execution Start


#for all the DCs collect DNS info and extract zones
$all_dcs | %{
    Write-Verbose "Collecting from DC: $($_.name)"
    $DNS_Servers += extract_zones $_.fqdn $_.domain
}
#output the DNS info to CSV
$DNS_Servers | % {$_.zones} | Select-Object `
    domain,
    @{e={$_.servername.split('.')[0]};n="Server Name"},
    @{e={$_.zonename};n="Zone Name"},@{e={$_.zonetype};n="Zone Type"},
    @{e={$_.secureUpdates};n="Secure Updates"},
    @{e={if($_.adintegrated -eq 1){"Yes"}else{"No"}};n="Active Directory Integrated"},
    Partition | `
Export-Csv -NoTypeInformation "$($filePrefix)_DNS_Zones.csv"

Write-Verbose "###############################"