﻿[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DomainList,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

if ($Standalone) 
{ 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }

    $All_DCs = Get-ADSATargetDCs
    
    if ($DomainList)
    {
        $domains_detail = @()
        foreach ($domain in $domainlist)
        {
            # Convert FQDN to DN
            $domainnamearray = $domain.split(".")
            $domainDN = "dc=" + $domainnamearray[0]
            for ($i=1;$i -lt $domainnamearray.count; $i++) { $domaindn += ",dc=" + $domainnamearray[$i] }

            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $domain
            $domainobj | Add-Member NoteProperty DomainDN $domaindn
            $domains_detail += $domainobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose        
    } 
} 

if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
{
    $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
}

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

#remove any stale variables in use
rv All_ACLs -ErrorAction silentlycontinue
#make a script wide variable to hold all ACLs
Set-Variable -Name All_ACLs -Value @() -Scope script

Write-Verbose "Gathering ACLs.`n###############################"

#####################################
### Custom File README
### 
### When supplying a custom file to collect ACLS
### the file must be TAB separated values of three (3) columns with NO headers
### First Column: Domain (Format: extranet.microsoft.com)
### Second Column: ObjectType (Format:Group)
### Third Column: DistinguishedName  (Format: CN=name,DC=extranet,DC=microsoft,DC=com)
###
###  The domain is used for display and differentiation purposes. 
###     This should be the domain where the object/container exists
###
###  The objectType is used for display and differentiation purposes of the object's type. 
###     This should be the type of object/container, like the administrator's group
###     or OU or DNS Record etc.
###
###  The distinguishedName is used to actually locate the object in the directory. 
###     This should be the DistinguishedName of the object/container you wish to get ACLs for
###
#####################################

$root = [ADSI]"LDAP://RootDSE"
$rootDN = $($root.rootDomainNamingContext)
$current_forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()

# Legacy code, doesn't appear anywhere in the script
#$Root = [ADSI]"LDAP://$(([ADSI]"LDAP://RootDSE").Get('rootDomainNamingContext'))"

#CONSTANT Directory Entries for general AD containers in a forest
    $configuration = [ADSI]"LDAP://CN=Configuration,$($rootDN)"
    $sitesDN = [ADSI]"LDAP://CN=Sites,$($configuration.distinguishedName)"
    $services = [ADSI]"LDAP://CN=Services,$($configuration.distinguishedName)"
    $pki = [ADSI]"LDAP://CN=Public Key Services,$($services.distinguishedName)"
    $schema = [ADSI]"LDAP://CN=Schema,$($configuration.distinguishedName)"
    $wellKnown = [ADSI]"LDAP://CN=WellKnown Security Principals,$($configuration.distinguishedName)"
    $users = [ADSI]"LDAP://CN=Users,$($rootDN)"
    $ExtendedRightsCN = [ADSI]"LDAP://CN=Extended-Rights,$($configuration.distinguishedName)"

#objectType field is used to differentiate different object types when looking at the output
    $objectTypeContainer = "Container"
    $objectTypeOU = "OU"
    $objectTypeGroup = "Group"
    $objectTypeDNSZone = "DNS_Zone"
    $objectTypeDNSRecord = "DNS_Record"   
    $objectTypeDomain = "Domain" 

# Given the distinguished name of the domain, get the Domain portion of the SID
function get-domainSID($domainDN)
{
    # Use ADSI interface to get the object
    $domain = [ADSI]"LDAP://$($domainDN)"

    # Get the objectSID, which is stored in byte format.
    $byteObjectSID = $($domain.objectsid)
    $strObjectSID = (New-Object System.Security.Principal.SecurityIdentifier($byteObjectSID,0)).value

    return $strObjectSID
}

function find-ADObjectBySID ($sid, $domaindn)
{
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher
    $Searcher.Filter = "objectSID=$SID"
    $Searcher.SearchRoot = "LDAP://$($domaindn)"
    $foundObj = $Searcher.FindOne()
    $searcher.Dispose()
    
    if ($foundObj -eq $null) 
    {
        # Object not found, so return $null
        return $null
    }
    else
    {
        # $foundObj is a System.DirectoryServices.SearchResult, but we need a System.DirectoryServices.DirectoryEntry
        # So we need to go from one to another
        $adObj = $foundObj.GetDirectoryEntry()
        return $adobj
    }

}


#convert inheritance type to friendlyname
function convert_inheritance_name($InheritanceType)
{
    Switch ($InheritanceType) {
          "None"            { $InheritanceType = "This object only" }
          "Descendents"     { $InheritanceType = "All child objects" }
          "SelfAndChildren" { $InheritanceType = "This object and one level Of child objects" }
          "Children"        { $InheritanceType = "One level of child objects" }
          "All"             { $InheritanceType = "This object and all child objects" }
        }
   return $InheritanceType     
}

function get-extended-right-name($ext_rightGuid)
{ #this can be slow, need to find a better way to DS search possibly with ADSISearcher

## TODO (ERHALL 1/22): Build an extended rights hash table (once) and search that instead
     $ext_RightCN = [ADSI]"LDAP://CN=Extended-Rights,$($configuration.distinguishedName)"
     
     $ext_Right_Name = $ext_RightCN.children | where {$_.rightsGuid -match $ext_rightGuid} | select displayname
     
     return $ext_Right_Name.displayname
}

function convertSidto-name($sid)
{
   $ID = New-Object System.Security.Principal.SecurityIdentifier($sid)
   $account = $ID.Translate( [System.Security.Principal.NTAccount])
   Return $account.Value
}

function createACLObject($DE, $domain = $current_forest.name, $objectType = "")
{
    Write-Verbose "`tCollecting ACLs from: $($DE.name)"
    rv ACLs,appliesToObjectType,appliesToProperty -ErrorAction silentlycontinue
    $ACLs = @()

    $DE.PSbase.ObjectSecurity.GetAccessRules($true,$true,[Security.Principal.NTAccount]) | %{
    
    rv appliesToObjectType,appliesToProperty,objType,ext_rightsresult -ErrorAction silentlycontinue
    
        #leave this here, it is redundant yes but will break if this is removed
        $objType = $_.ObjectType
    
        If ($_.InheritedObjectType.ToString() -NotMatch "0{8}.*") 
        {
          #
          # Search for the Object Type in the Schema
          #
          $filter = $("(SchemaIDGUID=\$($_.InheritedObjectType.ToByteArray() | %{'{0:X2}' -f $_ }))").replace(" ","\")
          $schemaObjSearcher = [ADSISearcher]$filter
          $schemaObjSearcher.SearchRoot = $schema
          $schemaObjSearcher.CacheResults = $true
          $schemaObjResult = $schemaObjSearcher.FindOne()
          $appliesToObjectType = $($schemaObjResult.Properties["ldapdisplayname"])
        
        } 
        Else { $appliesToObjectType = "All" }

        If ($_.ObjectType.ToString() -NotMatch "0{8}.*") 
        {
          #
          # Search for a possible Extended-Right or Property Set
          #
          $LdapFilter = "(rightsGuid=$($_.ObjectType.ToString()))"
          $ext_rightResult = (New-Object DirectoryServices.DirectorySearcher($ExtendedRightsCN, $LdapFilter)).FindOne()
          #check if an extended right is found
          If ($ext_rightResult) 
          {
            $appliesToProperty = $($ext_rightResult.Properties["displayname"])
          } 
          #extended right is now found, search the schema
          Else 
          {
            #
            # Search for the attribute name in the Schema
            #
            $filter = $("(SchemaIDGUID=\$($_.ObjectType.ToByteArray() | %{'{0:X2}' -f $_ }))").replace(" ","\")
            $schemaSearcher = [ADSISearcher]$filter
            $schemaSearcher.SearchRoot = $schema
            $schemaSearcher.CacheResults = $true
            #find one in the schema, this can fail if the object is deleted
            try
            {
                $schemaResult = $schemaSearcher.FindOne()
                $displayname = $($schemaResult.Properties["ldapdisplayname"])
            }
            catch [system.exception]
            {
                Write-warning "`t`tObject: $($ObjType) type not found in schema or extended-right containers" 
                $displayname = $ObjType.tostring()
            }
            finally
            {
                $appliesToProperty = $displayname
            }
          }
        } 
        Else { $appliesToproperty = "All" }
        
        #determine if the IDReference is a SID and try to convert it
        if($_.IdentityReference.value -match [regex]'^S-\d-\d-*')
        {                
            try
            {#try to translate the SID to account name (this may not work hence catch)
                $account = Convertsidto-name $_.IdentityReference.value
            }
            catch [system.exception]
            {#this occurs when the SID cannot be translated
             
            }
        }
        else{$account = $_.IdentityReference}
        # Create a ACL Object to hold the ACL info
        $ACLobj = New-Object PSObject
        
        $ACLobj | Add-Member NoteProperty Domain $domain
        $ACLobj | Add-Member NoteProperty ObjectName $DE.Name.tostring()
        $ACLobj | Add-Member NoteProperty ObjectDN $DE.distinguishedName.tostring()
        $ACLobj | Add-Member NoteProperty AccessControlType $_.AccessControlType
        #ACL either contains additional/other rights or is not an extendedright
        $ACLobj | Add-Member NoteProperty ADRights $_.ActiveDirectoryRights
        $ACLobj | Add-Member NoteProperty Identity $account
        $ACLobj | Add-Member NoteProperty AppliesTo $(convert_inheritance_name $_.InheritanceType)
        $ACLobj | Add-Member NoteProperty AppliesToObjectType $appliesToObjectType
        $ACLobj | Add-Member NoteProperty AppliesToProperty $appliesToProperty
        $ACLobj | Add-Member NoteProperty Inherited $_.IsInherited
        $ACLobj | Add-Member NoteProperty ObjectType $objectType
        
        $ACLs += $ACLobj
    }
    return $ACLs
}

function extract_ACLs($domainDN,$domain)
{#this function extracts ACLs from a domain
    rv domain_ACLs -ErrorAction silentlycontinue

    #objectType field is used to differentiate different object types when looking at the output
    $objectTypeContainer = "Container"
    $objectTypeOU = "OU"
    $objectTypeGroup = "Group"
    $objectTypeDNSZone = "DNS_Zone"
    $objectTypeDNSRecord = "DNS_Record"
    $objectTypeDomain = "Domain"

    #CONSTANT Directory Entries for general AD containers in a domain
    $domainroot = [ADSI]"LDAP://$($domaindn)"
    $builtin = [ADSI]"LDAP://CN=Builtin,$($domainDN)"
    $computers = [ADSI]"LDAP://CN=Computers,$($domainDN)"
    $system = [ADSI]"LDAP://CN=System,$($domainDN)"
    $adminSDHolder = [ADSI]"LDAP://CN=AdminSDHolder,$($system.distinguishedName)"
    $DCsOU = [ADSI]"LDAP://OU=Domain Controllers,$($domainDN)"
    $users = [ADSI]"LDAP://CN=Users,$($domainDN)"
    $legacydns = [ADSI]"LDAP://CN=MicrosoftDNS,CN=System,$($domainDN)"
    
    # The following container (Managed Service Accounts) only exists after 2008R2 domainprep has been run
    # so search for it and assign it to $null if not found 
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher
    $Searcher.Filter = "CN=Managed Service Accounts"
    $Searcher.SearchRoot = "LDAP://$($domainDN)"
    $searcher.searchscope = "Onelevel"
    $ResultObj = $Searcher.FindOne()
    $searcher.Dispose()
    if ($ResultObj -ne $null) { $msa = $ResultObj.getdirectoryentry() } else { $msa = $null }    
    
    # Get the domain SID so we can construct SIDs for default groups/accounts
    $domainSID = get-domainSID $domainDN

    # Well-known SIDs for domain objects (built-in and default).
    # Source is KB 243330
    
    # Put each of the results in an array that we can loop through later
    $domaingroups = @()
    <# Commented out three user accounts for now
    $domainaccounts = @()
    $domainaccounts += find-ADObjectBySID ($domainSID + "-500") $domainDN # Administrator
    $domainaccounts += find-ADObjectBySID ($domainSID + "-501") $domainDN # Guest
    $domainaccounts += find-ADObjectBySID ($domainSID + "-502") $domainDN # KRBTGT
    #>
    $domaingroups += find-ADObjectBySID ($domainSID + "-512") $domainDN # Domain Admins
    $domaingroups += find-ADObjectBySID ($domainSID + "-513") $domainDN # Domain Users
    $domaingroups += find-ADObjectBySID ($domainSID + "-514") $domainDN # Domain Guests
    $domaingroups += find-ADObjectBySID ($domainSID + "-515") $domainDN # Domain Computers
    $domaingroups += find-ADObjectBySID ($domainSID + "-516") $domainDN # Domain Controllers
    $domaingroups += find-ADObjectBySID ($domainSID + "-517") $domainDN # Cert Publishers
    $domaingroups += find-ADObjectBySID ($domainSID + "-520") $domainDN # Group Policy Creator Owners
    $domaingroups += find-ADObjectBySID ($domainSID + "-553") $domainDN # RAS and IAS Servers
    $domaingroups += find-ADObjectBySID ($domainSID + "-498") $domainDN # Enterprise Read-only Domain Controllers (2008+) n.b. This group is created once per forest, in the first domain with a 2008+ PDC after RODCPrep is run
    $domaingroups += find-ADObjectBySID ($domainSID + "-521") $domainDN # Read-only Domain Controllers (2008+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-571") $domainDN # Allowed RODC Password Replication Group (2008+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-572") $domainDN # Denied RODC Password Replication Group ((2008+)
    $domaingroups += find-ADObjectBySID ($domainSID + "-522") $domainDN # Clonable Domain Controllers (2012+)
    $domaingroups += find-ADObjectBySID "S-1-5-32-544" $domainDN # Builtin\Administrators
    $domaingroups += find-ADObjectBySID "S-1-5-32-545" $domainDN # Builtin\Users
    $domaingroups += find-ADObjectBySID "S-1-5-32-546" $domainDN # Builtin\Guests
    $domaingroups += find-ADObjectBySID "S-1-5-32-547" $domainDN # Builtin\Power Users
    $domaingroups += find-ADObjectBySID "S-1-5-32-548" $domainDN # Builtin\Account Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-549" $domainDN # Builtin\Server Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-550" $domainDN # Builtin\Print Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-551" $domainDN # Builtin\Backup Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-552" $domainDN # Builtin\Replicators
    $domaingroups += find-ADObjectBySID "S-1-5-32-554" $domainDN # Builtin\Pre-Windows 2000 Compatible Access
    $domaingroups += find-ADObjectBySID "S-1-5-32-555" $domainDN # Builtin\Remote Desktop Users
    $domaingroups += find-ADObjectBySID "S-1-5-32-556" $domainDN # Builtin\Network Configuration Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-558" $domainDN # Builtin\Performance Monitor Users
    $domaingroups += find-ADObjectBySID "S-1-5-32-559" $domainDN # Builtin\Performance Log Users
    $domaingroups += find-ADObjectBySID "S-1-5-32-560" $domainDN # Builtin\Windows Authorization Access Group
    $domaingroups += find-ADObjectBySID "S-1-5-32-561" $domainDN # Builtin\Terminal Server License Servers
    $domaingroups += find-ADObjectBySID "S-1-5-32-562" $domainDN # Builtin\Distributed COM Users
    $domaingroups += find-ADObjectBySID "S-1-5-32-569" $domainDN # Builtin\Cryptographic Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-573" $domainDN # Builtin\Event Log Readers
    $domaingroups += find-ADObjectBySID "S-1-5-32-574" $domainDN # Builtin\Certificate Service DCOM Access
    $domaingroups += find-ADObjectBySID "S-1-5-32-575" $domainDN # Builtin\RDS Remote Access Servers
    $domaingroups += find-ADObjectBySID "S-1-5-32-576" $domainDN # Builtin\RDS Endpoint Servers
    $domaingroups += find-ADObjectBySID "S-1-5-32-577" $domainDN # Builtin\RDS Management Servers
    $domaingroups += find-ADObjectBySID "S-1-5-32-578" $domainDN # Builtin\Hyper-V Administrators
    $domaingroups += find-ADObjectBySID "S-1-5-32-579" $domainDN # Builtin\Access Control Assistance Operators
    $domaingroups += find-ADObjectBySID "S-1-5-32-580" $domainDN # Builtin\Remote Management Users
    
    #collect from containers
    $domain_ACLs += createACLObject -DE $domainroot -domain $domain -objectType $objectTypeDomain
    $domain_ACLs += createACLObject -DE $builtin -domain $domain -objectType $objectTypeContainer
    $domain_ACLs += createACLObject -DE $computers -domain $domain -objectType $objectTypeContainer
    $domain_ACLs += createACLObject -DE $system -domain $domain -objectType $objectTypeContainer
    $domain_ACLs += createACLObject -DE $adminSDHolder -domain $domain -objectType $objectTypeContainer
    $domain_ACLs += createACLObject -DE $DCsOU -domain $domain -objectType $objectTypeOU
    $domain_ACLs += createACLObject -DE $users -domain $domain -objectType $objectTypeContainer
    if ($msa -ne $null)
    { $domain_ACLs += createACLObject -DE $msa -domain $domain -objectType $objectTypeContainer }

    foreach ($group in $domaingroups)
    {
        if ($group -eq $null) { continue } # Not all groups exist in all environments
        else
        {
            $domain_ACLs += createACLObject -DE $group -domain $domain -objectType $objectTypeGroup
        }
    }

    #collect from legacy DNS container
            Write-Verbose "`tExtracting ACLs from legacy DNS container"
    #go thru each zone in MiscorosftDNS container
    $legacydns.Children | %{
    
        #this is the zone's entry point via DN
        $zoneEntry = [ADSI]"$($_.path)"
    
        Write-Verbose "`t`tCollecting ACLs from zone: $($zoneEntry.name) ..."
        $domain_ACLs += createACLObject $zoneEntry $domain $objectTypeDNSZone
        
           #determine if this zone is the domain where DC records are
            if($domain -match $zoneEntry.dc)
            {
                $All_DCs | %{
                    
                    $dnsrecordDE = [ADSI]$(get-dnsrecordacl $_.name $zoneEntry.distinguishedName)
                    #make sure the record was found before adding it
                    #record might not be found if the DC's A record is in another partition
                    if($dnsrecordDE)
                    {
                        Write-Verbose "`t`t`t Collecting ACLs for $($_.name) DNS A record ..."
                        $domain_ACLs += createACLObject $dnsrecordDE $domain $objectTypeDNSRecord
                    }   
                }#end loop of all DCs
            }#end if zone is in domain where DC records are
    }#end loop of zones in MicrosoftDNS contianer

    return $domain_ACLs
}

function get-dnsrecordacl($recordname,$zoneDN)
{
    # This used to use the dc attribute, but it's not indexed, so switched to name.
    $recordSearcher = [ADSISearcher]"(&(objectClass=dnsNode)(name=$($recordName)))"
    $recordsearcher.SearchRoot = [ADSI]"LDAP://$($zoneDN)"
    $result = $recordsearcher.findOne()
    #the dns record might not be found, only return if its found
    if($result)
    {
        return $result.properties['adspath']
    }    
}

#function to dump all ACLs to csv    
function Do-Output
{
    $All_ACLs | Select-Object `
            domain,
            @{e={$_.objectname};n="Object Name"},
            @{e={$_.objectDN};n="Object DN"},
            @{e={$_.accessControlType};n="Access Control Type"},
            @{e={$_.ADRights};n="AD Rights"},
            identity,
            @{e={$_.appliesto};n="Applies To"},
            @{e={$_.appliesToObjectType};n="Applies to object type"},
            @{e={$_.appliestoProperty};n="Applies to property"},
            @{e={if($_.inherited){"Yes"}else{"No"}};n="Inherited"},
            @{e={$_.objectType};n="Object Type"}  `
        | Export-Csv -NoTypeInformation "$($filePrefix)_ACLs.csv"

    Write-Verbose "###############################"
}

#Collect ACLs for custom request from file
function Process-Customfile($custom_file,$exclusive)
{
    $custom_file | %{
        
        #break each line from the tab delimited file into three chunks
        $textLine = $_.split("`t")
        
        #assign the chunks to variables to be used to gather the acls
        $Domain = $textLine[0]
        $objectType = $textLine[1]
        $DN = $textLine[2]
        
        #collect ACLs from the custom supplied file
        Write-Verbose "`tCollecting ACLs from custom object/container: $($DN)"
        $CustomDE = [ADSI]"LDAP://$($DN)"
        if ($customde.Properties)
        {
            $All_ACLs += createACLObject -DE $CustomDE -domain $domain -objectType $objectType
        }
        else
        {
            Write-Warning "`tThe custom object/container with distinguished name $($DN) was not found."
        }
    }
    #this is run only if the custom file is run in exclusive mode (only custom file groups are extracted)
    if($exclusive)
    {
       $filePrefix = "Exclusive"
       Do-Output
       Exit
    }
    return $All_ACLs
}

# Get the forest root domain SID so we can construct SIDs for default groups/accounts
$forestSID = get-domainSID $rootDN

# Well-known SIDs for forest objects (built-in and default).
# Source is KB 243330
    
# Put each of the results in an array that we can loop through later
$forestgroups = @()

$forestgroups += find-ADObjectBySID ($forestSID + "-518") $rootDN #Schema Admins
$forestgroups += find-ADObjectBySID ($forestSID + "-519") $rootDN #Enterprise Admins
$forestgroups += find-ADObjectBySID "S-1-5-32-557" $rootDN # Builtin\Incoming Forest Trust Builders

########################
########################
## Main Execution Start

#check if a custom ACL request file is offered via argument, then run process-customfile function
if($filepath)
{
    if(Test-Path $filepath)
    {
        #get the contents of the custom file and process it. 
        #if the exclusive flag is set only process the file then exit script
        $custom_file = gc $filepath
        
        ## TODO: (ErHall 1/19) Fix this up so we can run exclusive if the task is run outside the framework
        $All_ACLs += Process-Customfile -custom_file $custom_file -exclusive $false
    }
    else{"Custom ACLs file $($filepath) could not be found. Check the path and filename and try again.";Exit}
}


#Collect ACLs for forest wide containers
   Write-Verbose "Extracting ACLs from forest wide containers"
    $All_ACLs += createACLObject -DE $sitesDN -domain $current_forest.name -objectType $objectTypeContainer
    $All_ACLs += createACLObject -DE $services -domain $current_forest.name -objectType $objectTypeContainer
    $All_ACLs += createACLObject -DE $pki -domain $current_forest.name -objectType $objectTypeContainer
    $All_ACLs += createACLObject -DE $schema -domain $current_forest.name -objectType $objectTypeContainer
    $All_ACLs += createACLObject -DE $wellKnown -domain $current_forest.name -objectType $objectTypeContainer
    $All_ACLs += createACLObject -DE $configuration -domain $current_forest.name -objectType $objectTypeContainer
        
foreach ($group in $forestgroups)
    {
        if ($group -eq $null) { continue } # Not all groups exist in all environments
        else
        {
            $All_ACLs += createACLObject -DE $group -domain $current_forest.name -objectType $objectTypeGroup
        }
    }
 
#collect ACs for the application partitions, namely DNSzones
    Write-Verbose "Extracting ACLs from AD DNS"
    
    # Updated to get the list of app partitions since $ADObj was originally used and is not passed to the script now.

        $PartitionDN = [ADSI]"LDAP://CN=Partitions,$($configuration.distinguishedName)"
        $ForestDNSfilter = "dnsRoot=ForestDNSZones*"
        $DomainDNSfilter = "dnsRoot=DomainDNSZones*"
        $ForestZonesearch = [ADSISearcher]$ForestDNSFilter
        $ForestZonesearch.searchroot = $PartitionDN
        $ForestZoneResult = $ForestZoneSearch.findone()
        $DomainZonesearch = [ADSISearcher]$DomainDNSFilter
        $DomainZonesearch.searchroot = $PartitionDN
        $DomainZoneResult = $DomainZoneSearch.findall()

        $ZoneList = @()
        $ZoneList += $ForestZoneResult
        $ZoneList += $DomainZoneResult


    $zonelist | %{

        #create the entry point to MicrosoftDNS container in the partition
        $partitionentry = [ADSI]"LDAP://CN=MicrosoftDNS,$($_.properties.ncname)"
        $partitionDN = $_.properties.ncname
        #convert partition domain DN to FQDN for display purposes
        
        $partitiondomain = $($_.properties.dnsroot)
        Write-Verbose "`tExtracting ACLs from: $($partitionentry.psbase.parent.dc) for $($partitiondomain) ..."
        
        #go thru each zone in MiscorosftDNS container
        $partitionentry.Children | %{
        
            #this is the zone's entry point via DN
            $zoneEntry = [ADSI]"$($_.path)"
        
            Write-Verbose "`t`tCollecting ACLs from zone: $($zoneEntry.name) ..."
            $ALL_ACLs += createACLObject -DE $zoneEntry -domain $partitiondomain -objectType $objectTypeDNSZone
            
            #determine if this zone is the domain where DC records are
            if($partitiondomain -match $zoneEntry.dc )
            {
                #select the DCs for which are 
                $All_DCs | where domain -eq $zoneEntry.dc | %{

                    $dnsrecordDE = [ADSI]$(get-dnsrecordacl $_.name $zoneEntry.distinguishedName)
                    #make sure the record was found before adding it
                    #record might not be found if the DC's A record is in another partition
                    if($dnsrecordDE)
                    {
                        Write-Verbose "`t`t Collecting ACLs for $($_.name) DNS A record ..."
                        $All_ACLs += createACLObject -DE $dnsrecordDE -domain $($partitiondomain) -objectType $objectTypeDNSRecord
                    }#end if dns record found on DC

                }#end all DC loop
                
            }#end if zone is in domain where DC records are
        }#end loop of zones in MicrosoftDNS container
    }#end loop of application partitions

    
#Collect ACLs for all domains in forest    
$domains_detail | %{

    Write-Verbose "Extracting ACLs from domain:  $($_.domain)"
    $All_ACLs += extract_ACLs -domainDN $_.domainDN -domain $_.domain
}

#run the output regular, not in exclusive custom file mode
Do-Output