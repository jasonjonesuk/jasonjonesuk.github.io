﻿Param ($GPOBackupPath="c:")

# Backup.xml file
$backupxml = @"
<?xml version="1.0" encoding="utf-8"?>
<!-- Copyright (c) Microsoft Corporation.  All rights reserved. -->
<GroupPolicyBackupScheme bkp:version="2.0" bkp:type="GroupPolicyBackupTemplate" xmlns:bkp="http://www.microsoft.com/GroupPolicy/GPOOperations" xmlns="http://www.microsoft.com/GroupPolicy/GPOOperations">
    <GroupPolicyObject>
        <SecurityGroups>
            <Group bkp:Source="FromDACL">
                <Sid>
                    <![CDATA[S-1-5-21-313387930-2272000091-2532780421-519]]>
                </Sid>
                <SamAccountName>
                    <![CDATA[Enterprise Admins]]>
                </SamAccountName>
                <Type>
                    <![CDATA[UniversalGroup]]>
                </Type>
                <NetBIOSDomainName>
                    <![CDATA[CONTOSO]]>
                </NetBIOSDomainName>
                <DnsDomainName>
                    <![CDATA[contoso.com]]>
                </DnsDomainName>
                <UPN>
                    <![CDATA[Enterprise Admins@contoso.com]]>
                </UPN>
            </Group>
            <Group bkp:Source="FromDACL">
                <Sid>
                    <![CDATA[S-1-5-21-313387930-2272000091-2532780421-512]]>
                </Sid>
                <SamAccountName>
                    <![CDATA[Domain Admins]]>
                </SamAccountName>
                <Type>
                    <![CDATA[GlobalGroup]]>
                </Type>
                <NetBIOSDomainName>
                    <![CDATA[CONTOSO]]>
                </NetBIOSDomainName>
                <DnsDomainName>
                    <![CDATA[contoso.com]]>
                </DnsDomainName>
                <UPN>
                    <![CDATA[Domain Admins@contoso.com]]>
                </UPN>
            </Group>
        </SecurityGroups>
        <FilePaths/>
        <GroupPolicyCoreSettings>
            <ID>
                <![CDATA[{FACCA114-6E57-4027-AB08-D891F66A4A24}]]>
            </ID>
            <Domain>
                <![CDATA[contoso.com]]>
            </Domain>
            <SecurityDescriptor>01 00 04 9c 00 00 00 00 00 00 00 00 00 00 00 00 14 00 00 00 04 00 ec 00 08 00 00 00 05 02 28 00 00 01 00 00 01 00 00 00 8f fd ac ed b3 ff d1 11 b4 1d 00 a0 c9 68 f9 39 01 01 00 00 00 00 00 05 0b 00 00 00 00 00 24 00 ff 00 0f 00 01 05 00 00 00 00 00 05 15 00 00 00 9a eb ad 12 5b f8 6b 87 85 29 f7 96 00 02 00 00 00 02 24 00 ff 00 0f 00 01 05 00 00 00 00 00 05 15 00 00 00 9a eb ad 12 5b f8 6b 87 85 29 f7 96 00 02 00 00 00 02 24 00 ff 00 0f 00 01 05 00 00 00 00 00 05 15 00 00 00 9a eb ad 12 5b f8 6b 87 85 29 f7 96 07 02 00 00 00 02 14 00 94 00 02 00 01 01 00 00 00 00 00 05 09 00 00 00 00 02 14 00 94 00 02 00 01 01 00 00 00 00 00 05 0b 00 00 00 00 02 14 00 ff 00 0f 00 01 01 00 00 00 00 00 05 12 00 00 00 00 0a 14 00 ff 00 0f 00 01 01 00 00 00 00 00 03 00 00 00 00</SecurityDescriptor>
            <DisplayName>
                <![CDATA[Local Policy Export]]>
            </DisplayName>
            <Options>
                <![CDATA[0]]>
            </Options>
            <UserVersionNumber>
                <![CDATA[65537]]>
            </UserVersionNumber>
            <MachineVersionNumber>
                <![CDATA[393222]]>
            </MachineVersionNumber>
            <MachineExtensionGuids>
                <![CDATA[[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F72-3407-48AE-BA88-E8213C6761F1}][{827D319E-6EAC-11D2-A4EA-00C04F79F83A}{803E14A0-B4FB-11D0-A0D0-00A0C90F574B}]]]>
            </MachineExtensionGuids>
            <UserExtensionGuids>
                <![CDATA[[{35378EAC-683F-11D2-A89A-00C04FBBCFA2}{D02B1F73-3407-48AE-BA88-E8213C6761F1}]]]>
            </UserExtensionGuids>
            <WMIFilter/>
        </GroupPolicyCoreSettings> 
        <GroupPolicyExtension bkp:ID="{35378EAC-683F-11D2-A89A-00C04FBBCFA2}" bkp:DescName="Registry">
            <FSObjectFile bkp:Path="%GPO_MACH_FSPATH%\registry.pol" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\registry.pol" bkp:Location="DomainSysvol\GPO\Machine\registry.pol"/>
            <FSObjectFile bkp:Path="%GPO_USER_FSPATH%\registry.pol" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\User\registry.pol" bkp:Location="DomainSysvol\GPO\User\registry.pol"/>
            <FSObjectFile bkp:Path="%GPO_FSPATH%\Adm\*.*" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Adm\*.*"/>
        </GroupPolicyExtension>
        <GroupPolicyExtension bkp:ID="{827D319E-6EAC-11D2-A4EA-00C04F79F83A}" bkp:DescName="Security">
            <FSObjectFile bkp:Path="%GPO_MACH_FSPATH%\microsoft\windows nt\SecEdit\GptTmpl.inf" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\microsoft\windows nt\SecEdit\GptTmpl.inf" bkp:ReEvaluateFunction="SecurityValidateSettings" bkp:Location="DomainSysvol\GPO\Machine\microsoft\windows nt\SecEdit\GptTmpl.inf"/>
        </GroupPolicyExtension>
        <GroupPolicyExtension bkp:ID="{F15C46CD-82A0-4C2D-A210-5D0D3182A418}" bkp:DescName="Unknown Extension">
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Microsoft" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Microsoft" bkp:Location="DomainSysvol\GPO\Machine\Microsoft"/>
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Microsoft\Windows NT" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Microsoft\Windows NT" bkp:Location="DomainSysvol\GPO\Machine\Microsoft\Windows NT"/>
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Microsoft\Windows NT\Audit" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Microsoft\Windows NT\Audit" bkp:Location="DomainSysvol\GPO\Machine\Microsoft\Windows NT\Audit"/>
            <FSObjectFile bkp:Path="%GPO_MACH_FSPATH%\Microsoft\Windows NT\Audit\audit.csv" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Microsoft\Windows NT\Audit\audit.csv" bkp:Location="DomainSysvol\GPO\Machine\Microsoft\Windows NT\Audit\audit.csv"/>
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Microsoft\Windows NT\SecEdit" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Microsoft\Windows NT\SecEdit" bkp:Location="DomainSysvol\GPO\Machine\Microsoft\Windows NT\SecEdit"/>
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Scripts" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Scripts" bkp:Location="DomainSysvol\GPO\Machine\Scripts"/>
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Scripts\Shutdown" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Scripts\Shutdown" bkp:Location="DomainSysvol\GPO\Machine\Scripts\Shutdown"/>
            <FSObjectDir bkp:Path="%GPO_MACH_FSPATH%\Scripts\Startup" bkp:SourceExpandedPath="\\DC01.contoso.com\sysvol\contoso.com\Policies\{FACCA114-6E57-4027-AB08-D891F66A4A24}\Machine\Scripts\Startup" bkp:Location="DomainSysvol\GPO\Machine\Scripts\Startup"/>
        </GroupPolicyExtension>
    </GroupPolicyObject>
</GroupPolicyBackupScheme>
"@

#bkupinfo.xml file
$bkupinfo = @"
<BackupInst xmlns="http://www.microsoft.com/GroupPolicy/GPOOperations/Manifest">
    <GPOGuid>
        <![CDATA[{FACCA114-6E57-4027-AB08-D891F66A4A24}]]>
    </GPOGuid>
    <GPODomain>
        <![CDATA[contoso.com]]>
    </GPODomain>
    <GPODomainGuid>
        <![CDATA[{8d345ac4-636f-4d69-8650-335cb5d903a9}]]>
    </GPODomainGuid>
    <GPODomainController>
        <![CDATA[DC01.contoso.com]]>
    </GPODomainController>
    <BackupTime>
        <![CDATA[2010-01-01T12:00:00]]>
    </BackupTime>
    <ID>
        <![CDATA[{07BDCD6A-3F72-473C-82B9-67BB69DBE54D}]]>
    </ID>
    <Comment>
        <![CDATA[Backup GPO created by LocalGPO tool]]>
    </Comment>
    <GPODisplayName>
        <![CDATA[Local Policy Export]]>
    </GPODisplayName>
</BackupInst>
"@

$regpol = @"
PReg   
"@

$backupGUID = [System.Guid]::NewGuid().toString()

if ((test-path $GPOBackupPath) -ne $true) { throw "GPO Backup path not found" }

new-item -path "$GPOBackupPath\$backupGUID" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\microsoft" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\microsoft\windows nt" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\microsoft\windows nt\SecEdit" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\microsoft\windows nt\Audit" -ItemType Directory | Out-Null
new-item -path "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\User" -ItemType Directory | Out-Null

$infpath = "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\microsoft\windows nt\SecEdit\GptTmpl.inf"
$csvpath = "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\microsoft\windows nt\Audit\audit.csv"
$MachinePolPath = "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\registry.pol"
$UserPolPath = "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\User\registry.pol"

$backupxml | out-file "$GPOBackupPath\$backupGUID\backup.xml"

$datestring = "[CDATA[" + (get-date -f s) + "]]"
$bkupinfo = $bkupinfo.replace("[CDATA[2010-01-01T12:00:00]]",$datestring) 
$computernamestring = "[CDATA[Backup GPO created on " + $env:computername + " by LocalGPO tool]]"
$bkupinfo = $bkupinfo.replace("[CDATA[Backup GPO created by LocalGPO tool]]",$computernamestring)

$bkupinfo | Out-File "$GPOBackupPath\$backupGUID\bkupinfo.xml"

if (test-path -Path "$env:windir\system32\grouppolicy\Machine\Registry.pol") 
    
{ copy-item "$env:windir\system32\grouppolicy\Machine\Registry.pol" "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\Registry.pol" }
else
    { $regpol | Out-File "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\Machine\Registry.pol" }

if (test-path -Path "$env:windir\system32\grouppolicy\User\Registry.pol") 
    { copy-item "$env:windir\system32\grouppolicy\Machine\Registry.pol" "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\User\Registry.pol" }
else
    { $regpol | Out-File "$GPOBackupPath\$backupGUID\DomainSysvol\GPO\User\Registry.pol" }

secedit.exe /export /cfg $infpath
auditpol /backup /file:$csvpath

$audit = gc $csvpath
$audit = $audit -replace "$env:computername,System",",System"
$audit = $audit -replace "$env:computername,,",",," 
$audit | sc $csvpath