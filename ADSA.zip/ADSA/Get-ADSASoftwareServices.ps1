﻿[CmdLetBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DCList = $null, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null,   

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

if ($Standalone) 
{ 
    $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring()
    if ($DCList)
    {
        $All_DCs = @()
        foreach ($dcname in $dclist)
        { 
            $dc = New-Object psobject 
            $dc | Add-Member NoteProperty FQDN $dcname 
            $dc | Add-Member NoteProperty Domain $dcname.split(".",2)[1]
            $All_DCs += $dc 
        }
    }
    else
    {
        Import-Module .\ADSA.psm1
        $All_DCs = Get-ADSATargetDCs -omitDomains $omitDomains -verbose
    } 
} 

<#
.SYNOPSIS             
Establish a connection to a remote registry

.DESCRIPTION 
Establish a connection to a remote registry          

.PARAMETER  Hive
The registry hive to connect to, such as 'LocalMachine' or 'User'

.PARAMETER ComputerName
The name of the remote computer to connect to

.OUTPUTS
A [Microsoft.Win32.RegistryKey] object connected to the $Hive on $ComputerName
#>
function Connect-RemoteRegistry
{
    Param 
    (
        $Hive, # This should be either 'User' or 'LocalMachine'
        $ComputerName # Computer name as a string. FQDN or hostname should work as long as it resolves
    )

    try
    {
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($Hive,$ComputerName)
    }
    catch 
    {
        Write-Error -message "Opening the remote registry hive failed." -Category ConnectionError -CategoryActivity "[Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey" `
            -CategoryTargetName $ComputerName -TargetObject $reg -ErrorId "ADSARegConnError" -CategoryReason "Connection Failed"
        $reg = $null
    }

    return $reg
    
}

<#
.SYNOPSIS             
Convert from a SID to an account name

.DESCRIPTION 
Given a SID string in format S-1-5-*, convert to the corresponding NT account name           

.PARAMETER  SID
A SID string such as S-1-5-21-123-456-789-500

.OUTPUTS
A string representing the NT Account in format DOMAIN\Username
#>
function ConvertFrom-SID
{
    Param 
    (
        $sid
    )
   
   $ID = New-Object System.Security.Principal.SecurityIdentifier($sid)
   $account = $ID.Translate( [System.Security.Principal.NTAccount])
   Return $account.Value
}

function Get-RegistryUserList
{
    Param 
    (
        $reg # Microsoft.Win32.RegistryKey
    )
    
    # Make sure $reg is the user hive
    if ($reg.name -ne "HKEY_USERS") { write-error "Must pass a user hive to this function."; return -1 }

    $rawUserList = $reg.getsubkeynames()

    # Filter out everything that isn't in format S-1-5-21-<domainSid>-rid
    $userList = $rawUserList -match "^S-1-5-21(-\d+){4}$"
    return $userList
}

function Get-ProductList
{
    Param
    (
        $reg, # Microsoft.Win32.RegistryKey
        $path, # Registry Path
        $domain,
        $dc
    )

    $productlist = @()

    $productkeys = $reg.OpenSubKey($path)

    if ($productkeys)
    {
        foreach ($productID in $productkeys.getsubkeynames())
        {
            $product = $productkeys.opensubkey("$productID")
            if ($product -and $product.getvalue("displayname") -ne $null)
            {
                if ($product.getvalue("displayname") -match "KB\d{6}") { continue }
                $productObj = new-object psobject
                $productObj | Add-Member NoteProperty Domain $domain
                $productObj | Add-Member NoteProperty 'Domain Controller' $dc
                $productObj | Add-Member NoteProperty 'Display Name' $product.getvalue("displayname")
                $productObj | Add-Member NoteProperty 'Display Version' $product.getvalue("displayversion")
                $installdate = $product.getvalue("installdate")
                try
                {
                    $installdate = [datetime]::ParseExact($installdate,"yyyyMMdd",[System.Globalization.CultureInfo]::CurrentCultureInvariantCulture)
                    $date = "{0:d MMM yyyy}" -f $installdate
                }
                catch
                {
                    $date = $installdate
                }
                $productObj | Add-Member NoteProperty 'Install Date' $date
                $productObj | Add-Member NoteProperty 'Install Location' $product.getvalue("installlocation")
                $productObj | Add-Member NoteProperty Publisher $product.getvalue("publisher") 
        
                $productlist += $productObj
            }
        }
    }

    return $productlist
}

$All_Products = @()
$All_services = @()
foreach ($dc in $All_DCs)
{
    Write-Verbose "Gathering information for $($dc.fqdn)"
    # Get Product information
    
    Write-Verbose "`tGetting Product information"
    $dc_products = @()
    
    # Get admin-installed products from machine hive
    Write-Verbose "`tConnecting to machine hive on $($dc.fqdn)"
    $machinereg = Connect-RemoteRegistry -Hive LocalMachine -ComputerName $dc.fqdn    
    if ($machinereg)
    {
        Write-Verbose "`t`tGetting admin-installed products"
        $dc_products += Get-ProductList $machinereg "SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" $dc.domain $dc.fqdn
        $dc_products += Get-ProductList $machinereg "SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" $dc.domain $dc.fqdn
        # Close the registry connection
        $machinereg.close()
    }
    else
    {
        write-warning "Could not connect to machine registry hive on $($dc.fqdn). Applications installed by an administrator will not be returned."
    }   
    

    $userreg = Connect-RemoteRegistry -Hive Users -ComputerName $dc.fqdn
    if ($userreg)
    {
        $userlist = Get-RegistryUserList -reg $userreg
        foreach ($user in $userlist)
        {
            Write-Verbose "`t`tGetting user-installed products for $user"
            $dc_products += Get-ProductList $userreg "Software\Microsoft\Windows\CurrentVersion\Uninstall" $dc.domain $dc.fqdn
            $dc_products += Get-ProductList $userreg "Wow6432Node\Software\Microsoft\Windows\CurrentVersion\Uninstall" $dc.domain $dc.fqdn
        }
        $userreg.close()
    }
    else
    {
        Write-Warning "Could not retrieve list of users for $($dc.fqdn). Applications installed in user hives will not be returned."
    }   
    
    if ($dc_products.count -le 0)
    {
        
        Write-Warning "`tNo installed products found on $($dc.fqdn). This usually indicates a connectivity or permissions problem with the server."
        $productObj = new-object psobject
        $productObj | Add-Member NoteProperty Domain $dc.domain
        $productObj | Add-Member NoteProperty 'Domain Controller' $dc.fqdn
        $productObj | Add-Member NoteProperty 'Display Name' "< NO INSTALLED PRODUCTS >"
        $productObj | Add-Member NoteProperty 'Display Version' $null
        $productObj | Add-Member NoteProperty 'Install Date' $null
        $productObj | Add-Member NoteProperty 'Install Location' $null
        $productObj | Add-Member NoteProperty Publisher $null  

        $dc_products += $productObj
    }

    $All_Products += $dc_products   
    
    # Get Service information
    $DCServices = @()
    Try
    {
        Write-Verbose "`tGetting Services information"
        $SystemServices = Get-WmiObject win32_service -ComputerName $dc.fqdn | select caption,displayname,pathname,startmode,state,description,startname,name
    
        #Make sure there are services returned...
        If(($SystemServices -eq "") -or ($SystemServices -eq $Null))
        {
            Write-Verbose "`tNO SERVICES FOUND"
            $Service = New-Object PSObject
            $Service | Add-Member NoteProperty Domain $dc.domain
            $Service | Add-Member NoteProperty 'Domain Controller' $dc.fqdn
            $Service | Add-Member NoteProperty 'Service Name' ""
            $Service | Add-Member NoteProperty Caption " <NO SERVICES RETURNED> "
            $Service | Add-Member NoteProperty 'Display Name' ""
            $Service | Add-Member NoteProperty Description ""
            $Service | Add-Member NoteProperty State ""
            $Service | Add-Member NoteProperty 'Start Mode' ""
            $Service | Add-Member NoteProperty 'Service Account' ""
            $Service | Add-Member NoteProperty Path ""
                                        
            $DCServices += $Service                    
        }
        Else #Otherwise create the list of services found
        {                
            $SystemServices | %{
            $Service = New-Object PSObject
            $Service | Add-Member NoteProperty Domain $dc.domain
            $Service | Add-Member NoteProperty 'Domain Controller' $dc.fqdn
            $Service | Add-Member NoteProperty 'Service Name' $_.Name
            $Service | Add-Member NoteProperty Caption $_.Caption
            $Service | Add-Member NoteProperty 'Display Name' $_.displayname
            $Service | Add-Member NoteProperty Description $_.Description
            $Service | Add-Member NoteProperty State $_.State
            $Service | Add-Member NoteProperty 'Start Mode' $_.StartMode
            $Service | Add-Member NoteProperty 'Service Account' $_.StartName
            $Service | Add-Member NoteProperty Path $_.pathname
                                            
            $DCServices += $Service
            }
        }
    }
    Catch [System.Exception]
    {
        Write-Verbose "`tUNABLE TO CONNECT"
        $Service = New-Object PSObject
        $Service | Add-Member NoteProperty Domain $dc.domain
        $Service | Add-Member NoteProperty 'Domain Controller' $dc.fqdn
        $Service | Add-Member NoteProperty 'Service Name' ""
        $Service | Add-Member NoteProperty Caption " <UNABLE TO CONNECT> "
        $Service | Add-Member NoteProperty 'Display Name' ""
        $Service | Add-Member NoteProperty Description ""
        $Service | Add-Member NoteProperty State ""
        $Service | Add-Member NoteProperty 'Start Mode' ""
        $Service | Add-Member NoteProperty 'Service Account' ""
        $Service | Add-Member NoteProperty Path ""
                                    
        $DCServices += $Service
    }
    $All_services += $DCServices     
}

$All_Products | Export-Csv -NoTypeInformation "$($filePrefix)_DCSoftware.csv"
$All_services | Export-Csv -NoTypeInformation "$($filePrefix)_DCServices.csv"
