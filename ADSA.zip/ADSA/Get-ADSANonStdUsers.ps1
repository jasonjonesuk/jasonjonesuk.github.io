
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DomainList,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null,
    [Parameter(mandatory=$false,Position=6)][switch]$verboseOutput
)

if ($Standalone) 
{ 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }

    if ($DomainList)
    {
        $domains_detail = @()
        foreach ($domain in $domainlist)
        {
            # Convert FQDN to DN
            $domainnamearray = $domain.split(".")
            $domainDN = "dc=" + $domainnamearray[0]
            for ($i=1;$i -lt $domainnamearray.count; $i++) { $domaindn += ",dc=" + $domainnamearray[$i] }

            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $domain
            $domainobj | Add-Member NoteProperty DomainDN $domaindn
            $domains_detail += $domainobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose      
    } 
} 

# Make sure we're in the OutputPath folder (this is important when running as a job
cd $OutputPath

function convertTo-datetime($int64)
{
    return [datetime]::FromFileTimeUTC($int64)
}

function checkAccountEnabled($uac)
{
    #check to see if the account is enabled or disabled.
    
    $disabledTest = 0x2
    
    if(($disabledTest -band $uac) -ne 0)
    {
        #account is disabled
        return $false
    }
    else
    {
        #account is enabled
        return $true
    }
}

function get-Accountlist($domainDN,$domain)
{
    <#
    Filter for where UserAccountControl is set with one of the following non-standard values:
    Property Flag                  Description                                    Value
    PASSWD_NOTREQD                 Password Not Required                          0x000020
    PASSWD_CANT_CHANGE             User cannot change password                    0x000040
    ENCRYPTED_TEXT_PWD_ALLOWED     Store Password Using Reversible Encryption     0x000080
    DONT_EXPIRE_PASSWORD           Password Never Expires                         0x010000
    SMARTCARD_REQUIRED             Smartcard is required for interactive logon    0x040000
    NOT_DELEGATED                  Account is sensitive and cannot be delegated   0x100000
    USE_DES_KEY_ONLY               Use Kerberos DES Encryption types              0x200000
    DONT_REQ_PREAUTH               Do not require Kerberos preauthentication      0x400000  

    Sum = 0x7500e0 = 7667936
    If all accounts in the environment use Smartcard, it might make sense to change the value to 5832928
    
    
    http://support.microsoft.com/kb/305144   
    #>

    $AcctSearcher = [ADSISearcher]"(&(objectCategory=person)(objectClass=user)(userAccountControl:1.2.840.113556.1.4.804:=7667936))"

    $AcctSearcher.searchRoot = [ADSI]"LDAP://$($domainDN)"

    $AcctSearcher.CacheResults = $true
    $AcctSearcher.PageSize = 1000
    
    $AcctSearcher.SizeLimit = 0


    #Get all objects matching the LDAP query above
    $Accts = $AcctSearcher.FindAll()
    
    if ($verboseOutput) { Write-Host "Found" $accts.count "non-standard accounts." }

    $domainAccts = @()

    #for each account found from LDAP query loop...
    $Accts | %{   
    
        #convert this account PS object
        $thisAcct = $_.psbase.properties
           
        $lastpwdchange = convertTo-datetime $thisAcct.pwdlastset[0]
        #check if lastlogontimestamp attribute is set
        if($thisAcct.lastlogontimestamp)
        {
            $lastlogontimestamp = convertTo-datetime $thisAcct.lastlogontimestamp[0]
            $dayssincelogon = (new-TimeSpan $lastlogontimestamp $(Get-Date)).days
        }
        else
        {
            $lastlogontimestamp = "< NOT SET >"
            $dayssincelogon = ""
        }
        
        $daysunchanged = (new-TimeSpan $lastpwdchange $(Get-Date)).days
        
            # Create a custom object to hold the account properties
            $Acct = new-Object PSObject
            $Acct | Add-Member NoteProperty Domain $domain
            $Acct | Add-Member NoteProperty Name $($thisAcct.name)
            $Acct | Add-Member NoteProperty SAMAccountName $($thisAcct.samaccountname)
            $Acct | Add-Member NoteProperty DN $($thisAcct.distinguishedname)
            $Acct | Add-Member NoteProperty Description $($thisAcct.description)
            $Acct | Add-Member NoteProperty LastPasswordChange $lastpwdchange
            $Acct | Add-Member NoteProperty DaysPwdUnchanged $daysunchanged
            $Acct | Add-Member NoteProperty LastLogonTimestamp $lastlogontimestamp
            $Acct | Add-Member NoteProperty DaysSinceLastLogon $dayssincelogon
            $Acct | Add-Member NoteProperty UAC $($thisAcct.useraccountcontrol)
            $Acct | Add-Member NoteProperty WhenChanged $($thisAcct.whenchanged)
            $Acct | Add-Member NoteProperty WhenCreated $($thisAcct.whencreated)
            
            $domainAccts += $Acct
    }#end loop all accounts with reversible encryption
    
    return $domainAccts
}

########################
########################
## Main Execution Start

$NonStdAccounts = @()

if ($verboseOutput) { Write-Host "Gathering accounts with non-standard User Account Control Values.`n###############################" }

#for each domain get accounts with reversible encryption...
$domains_detail | %{

    if ($verboseOutput) { Write-Host "`tExtracting accounts from domain: $($_.domain)" }
    
    $results = get-Accountlist $_.domainDN $_.domain
    
    #check that there are results
    if($results)
    {
        $NonStdAccounts += $results
    }
}#end loop

#export all accounts to CSV    
$NonStdAccounts | Select-Object `
    Domain,
    Name,
    SAMAccountName,
    DN,
    Description,
    @{e={$_.LastPasswordChange};n="Last Password Change"},
    @{e={$_.DaysPwdUnchanged};n="Days Password Unchanged"},
    @{e={$_.LastLogonTimestamp};n="Last Logon Timestamp"},
    @{e={$_.DaysSinceLastLogon};n="Days Since Last Logon"},
    @{e={if (($_.uac -band 0x2) -eq 0) { $true } else { $false }};n="Account Enabled"},
    @{e={if (($_.uac -band 0x20) -ne 0) { $true } else { $false }};n="Password Not Required"},
    @{e={if (($_.uac -band 0x40) -ne 0) { $true } else { $false }};n="User cannot change password"},
    @{e={if (($_.uac -band 0x80) -ne 0) { $true } else { $false }};n=" Store Password Using Reversible Encryption"},
    @{e={if (($_.uac -band 0x10000) -ne 0) { $true } else { $false }};n="Password Never Expires"},
    @{e={if (($_.uac -band 0x40000) -ne 0) { $true } else { $false }};n="Smartcard is required for interactive logon"},
    @{e={if (($_.uac -band 0x100000) -ne 0) { $true } else { $false }};n="Account is sensitive and cannot be delegated"},
    @{e={if (($_.uac -band 0x200000) -ne 0) { $true } else { $false }};n="Use Kerberos DES Encryption types"},
    @{e={if (($_.uac -band 0x400000) -ne 0) { $true } else { $false }};n="Do not require Kerberos preauthentication"},
    @{e={$_.uac};n="Raw UserAccountControl value"},
    @{e={$_.WhenChanged};n="Modified Time"},
    @{e={$_.WhenCreated};n="Created Time"} | `
Export-Csv -NoTypeInformation "$($filePrefix)_Interesting_Accts.csv"

if ($verboseOutput) { Write-Host "###############################" }