<#
.SYNOPSIS             
Remove a domain from the array of domains

.DESCRIPTION 
Remove a single domain, represented by the omit parameter from the array of
domains provided in the domainArr parameter           

.PARAMETER  DomainArr
The array containing a list of domains in the forest

.PARAMETER Omit
The name of the domain to omit

.INPUTS

.OUTPUTS
$newDomainArr: A new array containing the domains in domainArr that were not omitted

.EXAMPLE

.LINK

#>
function Remove-DomainFromArray
{
    param (
        [Parameter(mandatory=$true)]$domainarr,
        [Parameter(mandatory=$false)][string]$omit
    )
    $newDomainArr = @()
    $domainArr | %{
        #if the domain doesn't match, add it to a new array
        if($_.name -ne $omit.trim())
        {
            $newdomainArr += $_
        }
    }#end domain array loop
    #set the domains array to the new value, omitting the one passed to this function
    $newDomainArr
}


<#
.SYNOPSIS
Get the list of domain names and distinguished names

.DESCRIPTION
Collect the information used by the data collection scripts in the ADSA. The 
script gathers the name and distinguishedname of each domain

.PARAMETER omitDomains
Path to omitDomains.txt file

.EXAMPLE

.INPUTS
None

.OUTPUTS
domains_detail: Array of objects with information about each domain in the forest.

.NOTES

#>
Function Get-ADSATargetDomains
{
    [CmdletBinding()]
    param
    ( 
        $omitDomains = $null
    )

    if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
    {
        $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
    }

    $omitDomainList = $null
    if ($omitDomains) 
    {    
        $omitDomainList = Get-Content $omitDomains
    }


    # Query RootDSE to get the root domain and the configuration partition for the forest
    $rootdse = new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
    $rootdomain = $($rootdse.rootDomainNamingContext)
    $config = $($rootdse.configurationNamingContext)

    Write-Verbose "Collecting information on domains in Active Directory forest: $rootdomain"

    # Get the list of partitions from the config container
    $partitionsearcher = New-Object System.DirectoryServices.DirectorySearcher
    $partitionsearcher.filter = "(&(objectClass=crossRef)(systemFlags:1.2.840.113556.1.4.803:=2))" # SystemFlags 0x2 = Domain Partition
    $partitionsearcher.SearchRoot = "LDAP://CN=Partitions,$config"
    $partitionsearcher.SearchScope = "OneLevel"
    $partitionsearcher.CacheResults = $true
    $partitionsearcher.SizeLimit = 0
    $partitionsearcher.PageSize = 1000
    $partitionsearcher.PropertiesToLoad.add("nCName") | Out-Null
    $partitionsearcher.PropertiesToLoad.Add("systemFlags") | Out-Null
    $partitionsearcher.PropertiesToLoad.Add("nETBIOSName") | Out-Null
    $partitionsearcher.PropertiesToLoad.Add("dnsRoot") | Out-Null
    $partitionsearcher.PropertiesToLoad.Add("msDS-Behavior-Version") | Out-Null
    $partitionlist = $partitionsearcher.FindAll()
    $partitionsearcher.dispose()

    $domains_detail = @()
    
    # Extract information on each domain that we pulled from the Partitions container
    foreach ($crossRef in $partitionlist)
    {         
        if ($omitDomainList -notcontains $($crossRef.properties.dnsroot))
        {
            Write-Verbose "`tCollecting information on domain: $($crossRef.properties.dnsroot)" 
            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $($crossRef.properties.dnsroot)
            $domainobj | Add-Member NoteProperty DomainDN $($crossRef.properties.ncname)
            $domainobj | Add-Member NoteProperty DomainMode $($crossRef.Properties.'msds-behavior-version' )
            $domainobj | Add-Member NoteProperty NetBIOSName $($crossRef.Properties.netbiosname)

            # Get FSMO Role Owners
            $domaindn = $($crossref.properties.ncname)
            $pdc = $(([adsi]"LDAP://$domaindn").Properties.fsmoroleowner)
            $riddn = $(([adsi]"LDAP://$domaindn").Properties.rIDManagerReference)
            $rid = $(([adsi]"LDAP://$riddn").Properties.fsmoroleowner)
            $infra = $(([adsi]"LDAP://CN=Infrastructure,$domaindn").Properties.fsmoroleowner)

            $domainobj | Add-Member NoteProperty pdcroleowner ($pdc.split(",")[1]).replace("CN=","")
            $domainobj | Add-Member NoteProperty ridroleowner ($rid.split(",")[1]).replace("CN=","")
            if ($infra)
            {
                $domainobj | Add-Member NoteProperty infraroleowner ($infra.split(",")[1]).replace("CN=","")
            }
            else
            {
                Write-Verbose "`t`tThe Infrastructure Master role owner is not defined for domain $($crossRef.properties.dnsroot)"
                $domainobj | Add-Member NoteProperty infraroleowner "NOT DEFINED"
            }

            $domains_detail += $domainobj
        }
        else { Write-Verbose "`tOmitted collection on domain: $($crossRef.properties.dnsroot)" }
    }

    #handle the case where all domains are removed, warn and exit.
    if($domains_detail.count -eq 0)
    {
        $errorstring = "All domains were omitted, or no domains were discovered"
        $exception = new-object System.Exception($errorstring)
        $errorID = "ADSANoDomainsInScope"
        $errorcat = [System.Management.Automation.ErrorCategory]"InvalidData"
        $domainerror = New-Object System.Management.Automation.ErrorRecord($exception,$errorID,$errorcat,$domains_detail)
        throw $domainerror
    }

    Write-Verbose ("Information collected on " + $domains_detail.count + " domains`n")
    return $domains_detail
}


<#
.SYNOPSIS
Get the list of domaincontroller names, FQDNs, and parent domain

.DESCRIPTION
Collect the information used by the data collection scripts in the ADSA. The script gathers the name,
FQDN, and parent domain of each Domain Controller

.PARAMETER omitDomains
Path to omitDomains.txt file

.EXAMPLE

.INPUTS
None

.OUTPUTS
DC_detail: Array of objects containing information about each domain controller

.NOTES

#>
Function Get-ADSATargetDCs
{
    [CmdletBinding()]
    param
    ( 
        $omitDomains = $null
    )

    if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
    {
        $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
    }

    $omitDomainList = $null
    if ($omitDomains) 
    {    
        $omitDomainList = Get-Content $omitDomains
    }


    # Query RootDSE to get the root domain and the configuration partition for the forest
    $rootdse = new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
    $rootdomain = $($rootdse.rootDomainNamingContext)
    $config = $($rootdse.configurationNamingContext)

    Write-Verbose "Collecting information on domain controllers in Active Directory forest: $rootdomain" 
    
    # Get the list of partitions
    $partitionsearcher = New-Object System.DirectoryServices.DirectorySearcher
    $partitionsearcher.filter = "(&(objectClass=crossRef)(systemFlags:1.2.840.113556.1.4.803:=2))"
    $partitionsearcher.SearchRoot = "LDAP://CN=Partitions,$config"
    $partitionsearcher.SearchScope = "OneLevel"
    $partitionsearcher.CacheResults = $true
    $partitionsearcher.SizeLimit = 0
    $partitionsearcher.PageSize = 1000
    $partitionsearcher.PropertiesToLoad.add("nCName") | Out-Null
    $partitionsearcher.PropertiesToLoad.Add("systemFlags") | Out-Null
    $partitionsearcher.PropertiesToLoad.Add("dnsRoot") | Out-Null
    $partitionlist = $partitionsearcher.FindAll()
    $partitionsearcher.dispose()
    
    $All_DCs = @()

    foreach ($crossRef in $partitionlist)
    {         
        $domain = $($crossRef.properties.dnsroot)
        if ($omitDomainList -notcontains $domain)
        {
            Write-verbose "`tCollecting information on domain controllers in domain: $domain" 
            $dcSearcher = New-Object System.DirectoryServices.DirectorySearcher
            $dn = $($crossref.properties.ncname)
            $dcSearcher.filter = "(&(objectClass=nTDSDSA)(msDS-HasDomainNCs=$dn))"
            $dcSearcher.SearchRoot = "LDAP://CN=Sites,$config"
            $dcSearcher.SearchScope = "SubTree"
            $dcSearcher.CacheResults = $true
            $dcSearcher.SizeLimit = 0
            $dcSearcher.PageSize = 1000
            $ConfigDCList = $dcSearcher.FindAll() 

            foreach ($NTDSAobj in $ConfigDCList)
            {
                $Configobj = ([adsi]$NTDSAobj.path).parent
                $dc = ([adsi]$Configobj).serverreference
                    
                Write-Verbose "`t`tCollecting information on domain controller: $dc"
                    
                # Get Active Directory attributes of DC computer object
                $dc_detail = [adsi]"LDAP://$dc"    
                                    
                # Look up its IP Address(es)
                $iplist = ([System.Net.Dns]::GetHostAddresses($($dc_detail.dnsHostName)))
                    # If the DCs are using IPv6 exclusively, this line needs to be changed
                $ip = $iplist | where {$_.AddressFamily -eq "InterNetwork"} | select -ExpandProperty ipaddresstostring

                # Test for GC
                if (($($NTDSAobj.properties.options) -band 0x1) -eq 0x1) { $gc = "Yes" } else { $gc = "No" }

                # Get the site name
                $site = ($Configobj.split(",")[2]).replace("CN=","")

                # Find out if it's an RODC
                if ($($ntdsaobj.properties.objectcategory) -match "^CN=NTDS-DSA-RO") { $rodc = "Yes" } else { $rodc = "No" }

                # Put the relevant information into a PSObject
                $DCObj = New-Object PSObject

                $DCObj | Add-Member NoteProperty "Domain" $domain 
                $DCObj | Add-Member NoteProperty "Name" $($dc_detail.name)
                $DCObj | Add-Member NoteProperty "FQDN" $($dc_detail.dnsHostName)
                $DCObj | Add-Member NoteProperty "IP" $ip
                $DCObj | Add-Member NoteProperty "OS" $($dc_detail.operatingSystem)
                $DCObj | Add-Member NoteProperty "Site" $site                     
                $DCObj | Add-Member NoteProperty "Global Catalog" $gc 
                $DCObj | Add-Member NoteProperty "Read-Only DC" $rodc
                
                $All_DCs += $DCObj
            }
        }
        else { Write-Verbose "`tOmitted collection on domain: $($crossRef.properties.dnsroot)" }
    }    
    Write-Verbose ("Information collected on " + $All_DCs.count + " domain controllers`n")
    return $All_DCs
}


<#
.SYNOPSIS             
Use the WinForms Open File Dialog to pick a file

.DESCRIPTION            

.PARAMETER  InitialDirectory
The directory to start in when the File Dialog form opens

.PARAMETER Filter
Filter for files to show in the File Dialog
Text: Show text files with .txt or .csv extensions
CSV: Show only comma separated value files with .csv extension
All: Show all files (default)

.INPUTS

.OUTPUTS
String containing the full path to the file selected in the dialog box.

.EXAMPLE
get-filenamefromdialog -initialdirectory "c:\windows\system32" -filter TXT

Description

-----------

This command launches the open files dialog, starting in the c:\windows\system32 folder and filtered to show only files with a .csv extension.

.NOTES
Adapted from "Hey, Scripting Guy" column shown under related links.

.LINK
http://blogs.technet.com/b/heyscriptingguy/archive/2009/09/01/hey-scripting-guy-september-1.aspx

#>
Function Get-FileNameFromDialog
{  
    Param
    (
        [string]$initialDirectory="",
        [ValidateSet("Text","CSV","All")][string]$filter="All"
    )
    
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $OpenFileDialog.filter = "Text Files (*.txt;*.csv)|*.txt;*.csv|CSV Files (*.csv)|*.csv|All files (*.*)| *.*"
    $OpenFileDialog.FilterIndex = switch ($filter) {
        "Text" {1}
        "CSV" {2}
        "All" {3}
        }
    $OpenFileDialog.ShowDialog() | Out-Null
    
    #Return
    $OpenFileDialog.filename
} 


<#
.SYNOPSIS             
Initialize running the ADSA tests

.DESCRIPTION            

.INPUTS

.OUTPUTS
TasksToRun: An array of PSObjects holding the name of each data collection 
task, whether to run the task (set to false for all tasks), and the custom 
credentials to be used to run the task (set to null for all tasks).

.EXAMPLE

.LINK

#>
function Initialize-ADSATasks
{
    # Create an array with the name of each data collection task
    
    # IMPORTANT: DO NOT REORDER THIS TASK LIST. OTHER FUNCTIONS EXPECT THE 
    # ARRAY INDEXES TO MATCH THE ORDER LISTED
    
    $taskList = @(
                "ForestInfo", #0
                "Trusts", #1
                "DNS", #2
                "DSACLs", #3
                "GroupMembership", #4
                "GPO", #5
                "OUs", #6
                "StaleAccts", #7
                "Sites", #8
                "EmptyOUs", #9
                "EmptyGroups", #10
                "UserInfo", #11
                "TrustedForDelegation", #12
                "OUTree", #13
                # "AllUsers", #14
                # "AllGroups", #15
                "SoftwareServices", #14
                "ShareACLs", #15
                "NTFSACLs", #16
                "DCDrives", #17
                "WUSettings", #18
                "DCQFEs", #19
                "LocalAdmins", #20
                "IESecurityZones", #21
                "PasswordConfig" #22
                )

    # Create an array of objects where each object represents a task
    $TasksToRun = @()
    foreach ($task in $tasklist)
    {
        $objTask = new-object psobject
        $objTask | Add-Member -Type NoteProperty -Name TaskName -Value $task
        $objTask | Add-Member -Type NoteProperty -Name RunTask -Value $false
        $objTask | Add-Member -Type NoteProperty -Name CustomCreds -Value $null
        $objTask | Add-Member -Type NoteProperty -Name CustomFiles -Value $null
        $TasksToRun += $objTask
    }

    # Return an array of PSObjects
    $TasksToRun
}


<#
.SYNOPSIS             
Initialize output for ADSA Tasks

.DESCRIPTION   
Determine the path to the script directory, create the output directory for the
ADSA tasks, change directory to that folder, and create a subfolder to hold GPO
reports

.INPUTS

.OUTPUTS
ScriptDir: A string containing the path to the output files

.EXAMPLE

.LINK

.PARAMETER  OutputFolder
The folder to write the output of the ADSA data collection
#>
function Initialize-ADSAOutput
{
    [CmdletBinding()]
    Param(
        [Parameter(mandatory=$true)][string]$OutputFolder
    )
     
    if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
    {
        $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
    }
    
    #get the path that the script is currently running from and make an output dir
    $ScriptDir = Split-Path $myInvocation.ScriptName -Parent
    
    #create an output directory
    cd $ScriptDir
    Try
    {
        if (!(test-path $outputfolder)) 
        { 
            $outdir = mkdir $OutputFolder | Out-Null
            write-verbose "Created folder $($outdir.fullname) for script output." 
        }
        elseif((Get-ChildItem -Path $outputfolder -Filter *.csv) -ne $null)
        {
            #ensure that previously outputted data is not overwritten
            #make script exit if user does not say Y for yes proceed with overwrite
            Write-Warning "ADSA output already exists! Continuing will overwrite this data." 
            Write-Warning "Continue? [Y]/[N]"
            $response = Read-Host 
            if($response -notlike "Y")
            {
                Write-Verbose "Exiting due to customer selection."
                Exit
            }
        }
        cd $OutputFolder
        
        if (!(test-path "GPO_Reports")) { mkdir "GPO_Reports" | Out-Null }
    }
    catch
    {
        $errorstring = "Output folder structure could not be created"
        $exception = new-object System.Exception($errorstring)
        $errorID = "ADSAOutputFolderFailed"
        $errorcat = [System.Management.Automation.ErrorCategory]"WriteError"
        $foldererror = New-Object System.Management.Automation.ErrorRecord($exception,$errorID,$errorcat,$outputfolder)
        throw $foldererror
    }

    #Return value
    $ScriptDir
}


<#
.SYNOPSIS             
Check that ADSA prereqs for the data collection server are met prior to running the script
.DESCRIPTION            
Check a variety of prereqs for the script to makes sure they are met:
- Script is run in context of an admin user
TODO: Determine whether additional prereqs are needed

.INPUTS

.OUTPUTS
bAdminCheck: Boolean value indicating whether the prereqs are met.
TODO: If more prereqs are added, return a bit string with flags defined for each check

.EXAMPLE

.LINK

#>
function Test-ADSAServerPrereq
{

    [CmdletBinding()] Param()

    if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
    {
        $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
    }

    #1 Ensure the script is run with local administrator privileges
    Write-Verbose "Checking whether script is running with elevated account."
    try
    {
        $AdmCheck = $false
        $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
  	    $principal = new-object System.Security.Principal.WindowsPrincipal($identity)
  	    $admin = [System.Security.Principal.WindowsBuiltInRole]::Administrator	
        $AdmCheck = $principal.IsInRole($admin)
    }
    catch
    {
        $AdmCheck = $false
    }
    
    #2 Ensure Active Directory and Group Policy PowerShell module is presented
    Write-Verbose "Checking that Active Directory and Group Policy PowerShell modules are available"
    $PsModules = Get-Module -ListAvailable -verbose:$false # Don't verbosely load the module list
    $PsADMod = $false
    $PsGPOMod = $false
    foreach($PsModule in $PsModules.name)
    {
        if($PsModule -eq "ActiveDirectory")
        {
            $PsADMod = $true
        }
        elseif($PsModule -eq "GroupPolicy")
        {
            $PsGPOMod = $true
        }
    }

    #4 Ensure LDAP connection for RootDSE is possible
    Write-Verbose "Checking LDAP connectivity to RootDSE."
    try 
    {
        new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE") | Out-Null
        $LDAPRootCheck = $true
    }
    catch
    {
        $LDAPRootCheck = $false
    }
    
    #5 OS version
    Write-Verbose "Checking that host OS is a supported version"
    $OSCheck = $false
    try
    {
        $OSVer = [environment]::OSVersion.Version
        $OSMajor = [int]$OSVer.Major
        if ($OSMajor -ge 6)
        {
            $OSCheck = $true
        }
        
        else{}
    }
    catch
    {
        $OSCheck = $false
    }
    # Return a boolean
    Write-Verbose ("Admin: " + $AdmCheck + "`nAD PoweShell Module: "+ $PsADMod + "`nGPO PoweShell Module: "+ $PsGPOMod)
    Write-Verbose ("LDAP Root: " + $LDAPRootCheck + "`nOS Version: " + $OSCheck)
    
    $outcome = $AdmCheck -and $PsADMod -and $LDAPRootCheck -and $PsGPOMod -and $LDAPRootCheck -and $OSCheck
    return $outcome
}

<#
.SYNOPSIS             
Check that ADSA prereqs related with Network Connectivity are fulfiled

.DESCRIPTION            
Network connectivity prerequirements

.INPUTS

.OUTPUTS
NetworkOK: Boolean value indicating whether the prereqs are met.

.EXAMPLE

.LINK

#>

function Test-ADSANetConnection
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)]$DCs
    )

    if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
    {
        $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
    }

    #1 LDAP Connection
    $LdapOK =$true
    ForEach ($DC in $DCs.name)
    {
        try
        {
            $Dom = "LDAP://"+$DC
            $Root = New-Object DirectoryServices.DirectoryEntry $Dom -ErrorAction Stop
            Write-Verbose ("LDAP->" + $DC + ": OK") 
        }
        catch
        {
            Write-Verbose ("LDAP->" + $DC + ": FALSE") 
            $LdapOK = $false
        }

    }
    #2 SMB Connection
    $SmbOK =$true
    ForEach ($DC in $DCs.name)
    {
        try
        {
            $Rpath = "\\" + $DC + "\C$"
            $status = Test-Path $RPath -ErrorAction Stop
            Write-Verbose ("SMB->" + $DC + ": " + $status) 
        }
        catch
        {
            Write-Verbose ("SMB->" + $DC + ": FALSE") 
            $SmbOK = $false
        }
    }    

    #3 WMI Connection
    $WMIOK =$true
    ForEach ($DC in $DCs.name)
    {
        try
        {
            $ColItems = Get-WmiObject -Class Win32_PnPEntity -Namespace "root\cimv2" -Computer $DC -ErrorAction Stop
            Write-Verbose("WMI->" + $DC + ": OK") 
        }
        catch
        {
            Write-Verbose ("WMI->" + $DC + ": FALSE") 
            $WMIOK =$false
        }
    }
    #4 Remote Registry Connection
    $RemRegCheck = $true
    ForEach ($DC in $DCs.name)
    {
        try
        {
            $Reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $DC)
           Write-Verbose ("Remote Registry->" + $DC + ": OK") 
        }
        catch
        {
            Write-Verbose ("Remote Registry->" + $DC + ": FALSE") 
            $RemRegCheck = $true
        }
    }
        
    
    # Return a boolean
    $NetworkOK = $RemRegCheck -and $LdapOK -and $SmbOK -and $WMIOK
    return $networkOK
} 

<#
.SYNOPSIS             
Set options for how the ADSA will run
.DESCRIPTION            

.PARAMETER TasksToRun

.PARAMETER ScriptDir

.PARAMETER strConfigFile

.PARAMETER bAlternateCreds

.PARAMETER bSelectChecks

.INPUTS

.OUTPUTS
TasksToRun: An array of PSObjects holding the name of each data collection 
task, whether to run the task (set to false for all tasks), and the custom 
credentials to be used to run the task (set to null for all tasks).

.EXAMPLE

.LINK

.FUNCTIONALITY
Set a variety of ADSA Options and Configurations
- Use of automatic config file
- Use of alternate credentials to run tests
- Interactive selection of tests to run
- Custom files

#>
function Set-ADSAOptions
{
    Param(
        [Parameter(Mandatory=$true)]$TasksToRun,
        [Parameter(Mandatory=$true)]$ScriptDir,
        [Parameter(Mandatory=$true)][alias("ADSAConfigFile")]$strConfigFile,
        [Parameter(Mandatory=$true)][alias("AlternateCreds")]$bAlternateCreds,
        [Parameter(Mandatory=$true)][alias("SelectChecks")]$bSelectChecks,
        [Parameter(Mandatory=$true)]$CustomFilePath
    )

    rv bSpecifiyCreds, bInteractive -ErrorAction SilentlyContinue
    
    # Test path to configuration file
    $bConfigFilePresent = Test-Path ($ScriptDir + $strConfigFile)

    # If config file is present load values from it
    if ($bConfigFilePresent)
    {
        Try
        {
            $ConfigSettings = Import-Csv $($ScriptDir + $strConfigFile)
            
            Foreach ($setting in $ConfigSettings)
            {
                #Handle Specify Creds as a special case
                if ($setting.name -eq "SpecifyCreds") 
                {
                    $bSpecifyCreds = [System.Convert]::ToBoolean($setting.value)
                }

                # Update the TasksToRun object for everything else
                elseif ($TasksToRun.TaskName -contains $setting.name) 
                {
                    $a = $TasksToRun.TaskName.IndexOf($setting.name)
                    $TasksToRun[$a].RunTask = [System.Convert]::ToBoolean($setting.value)
                }

            }

            $bInteractive = $false
        }
        Catch
        {
            #Something went wrong with the config file. Give the option to continue and manually select options
            Write-Warning "Config file not found or syntax incorrect." 
            if ((Read-Host "Do you want to continue and specify settings manually?") -like "Y")
            {
                $bAlternateCreds = $false
                $bSelectChecks = $false 
            }
            else
            {
                $errorstring = "Config file incorrect and user chose not to continue."
                $exception = new-object System.Exception($errorstring)
                $errorID = "ADSAConfigFileIncorrect"
                $errorcat = [System.Management.Automation.ErrorCategory]"InvalidData"
                $configerror = New-Object System.Management.Automation.ErrorRecord($exception,$errorID,$errorcat,$($ScriptDir + $strConfigFile))
                throw $configerror
            }
        }

    }

    # Set whether specific creds will be specified
    if ($bAlternateCreds)
    {
        $bSpecifyCreds = $true
    }
    elseif ($bSpecifyCreds -eq $null)
    {
        $bSpecifyCreds = (Read-Host "*** Will you specify credentials for each information-gathering task? Y/N ***") -like "Y"
    }

    # Set interactive selection of tests to run
    if ($bSelectChecks)
    {
        $bInteractive = $true
    }
    elseif ($bInteractive = $null)
    {
        $bInteractive = (Read-Host "Do you want to run all checks? Y/N - (Enter 'N' to select individual checks to run.)") -notlike "Y"
    }

    if ($bInteractive)
    {
        Write-Host "`nBeginning interactive option selection:"        
        $TasksToRun[0].RunTask = (Read-Host "`nExport forest-level information? Y/N") -like "Y"
        $TasksToRun[1].RunTask = (Read-Host "Gather information on forest and domain trusts? Y/N") -like "Y"
        $TasksToRun[2].RunTask = (Read-Host "Gather AD-Integrated DNS zone information? Y/N") -like "Y"
        $TasksToRun[3].RunTask = (Read-Host "Gather Directory Service ACL information? Y/N") -like "Y"
        $TasksToRun[4].RunTask = (Read-Host "Gather administrative group information? Y/N") -like "Y"
        $TasksToRun[5].RunTask = (Read-Host "Gather GPO information? Y/N") -like "Y"
        $TasksToRun[6].RunTask = (Read-Host "Gather OU information? Y/N") -like "Y"
        $TasksToRun[7].RunTask = (Read-Host "Gather stale account information? Y/N") -like "Y"
        $TasksToRun[8].RunTask = (Read-Host "Gather site details? Y/N") -like "Y"
        $TasksToRun[9].RunTask = (Read-Host "Gather empty OU information? Y/N") -like "Y"
        $TasksToRun[10].RunTask = (Read-Host "Gather empty group information? Y/N") -like "Y"
        $TasksToRun[11].RunTask = (Read-Host "Gather information on accounts with non-standard settings (e.g. password never expires, reversible encryption)? Y/N") -like "Y"
        $TasksToRun[12].RunTask = (Read-Host "Gather information on accounts with authentication delegations? Y/N") -like "Y"
        $TasksToRun[13].RunTask = (Read-Host "Export a text-based visualization of the domain OU structure? Y/N") -like "Y"
        # $TasksToRun[14].RunTask = (Read-Host "Export details on all users, including UAC flag details? Y/N") -like "Y"
        # $TasksToRun[15].RunTask = (Read-Host "Export a list of all groups in each domain? Y/N") -like "Y"
        $TasksToRun[14].RunTask = (Read-Host "Gather detailed DC software/service configuration information? Y/N") -like "Y"
        $TasksToRun[15].RunTask = (Read-Host "Gather detailed DC shared folder ACL configuration information? Y/N") -like "Y"
        $TasksToRun[16].RunTask = (Read-Host "Gather detailed DC share NTFS ACL configuration information? Y/N") -like "Y"
        $TasksToRun[17].RunTask = (Read-Host "Gather DC drive configuration information? Y/N") -like "Y"
        $TasksToRun[18].RunTask = $false # (Read-Host "Gather DC Windows Updates configuration information? Y/N") -like "Y"
        $TasksToRun[19].RunTask = (Read-Host "Gather DC QFE installation information? Y/N") -like "Y"
        $TasksToRun[20].RunTask = (Read-Host "Gather local admin membership for designated servers (requires specifying a custom local admins file)? Y/N") -like "Y"
        $TasksToRun[21].RunTask = (Read-Host "Gather Internet explorer security settings? Y/N") -like "Y"
        $TasksToRun[22].RunTask = (Read-Host "Gather default domain password policy and fine-grained password policy settings? Y/N") -like "Y"
    }
    elseif ($bInteractive -eq $false)
    {
        Write-Host "`nAll checks will run..."
        for ($a=0; $a -lt $TasksToRun.Count; $a++) { $TasksToRun[$a].RunTask = $true ; $TasksToRun[18] = $false }
    }

    # If custom credentials are to be specified, call the function to get them
    if ($bSpecifyCreds) { $TasksToRun = Get-ADSACustomCredentials $TasksToRun }

    # Call the function to read in custom files
    if (Test-Path ($ScriptDir + $CustomFilePath)) { $TasksToRun = Set-ADSAInputFiles $CustomFilePath $TasksToRun $ScriptDir }

    # Return
    $TasksToRun               
}


<#
.SYNOPSIS             
Set options for input files
.DESCRIPTION            

.PARAMETER  CustomFilePath
Path to the CSV file containing details on customization files to load

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK

#>
function Set-ADSAInputFiles
{

    Param
    (
        $CustomFilePath,
        $TasksToRun,
        $ScriptDir
        # TODO: Allow Custom File Paths as parameters to function

    )

    # Clean up variables
    rv DSACLs,GroupMembership,LocalAdmins,ForestInfo -ErrorAction SilentlyContinue

    If(Test-Path ($ScriptDir + $CustomFilePath))
    {  
        if((Read-Host "Custom input file located.  Would you like to use this? [Y]/[N]") -like "Y")
        {
            $AskForFiles = $False
            $FilePaths = Import-csv ($ScriptDir + $CustomFilePath)

            # TODO: Validate that $FilePaths is in the correct format.

            foreach ($FilePath in $FilePaths)
            {
                if ([System.Convert]::ToBoolean($FilePath.Use))
                {
                    switch ($FilePath.Variable)
                    {
                    CustomACLFile {$DSACLs = ($ScriptDir + $FilePath.Path)}
                    CustomGroupFile {$GroupMembership = ($ScriptDir + $FilePath.Path)}
                    CustomLocalAdminFile {$LocalAdmins = ($ScriptDir + $FilePath.Path)}
                    OmitDomains {$ForestInfo = ($ScriptDir + $FilePath.Path)}
                    }

                }
            }
        }
    }
    Else
    {
        $AskForFiles = ((Read-Host "Do you have custom input files to provide? Y/N") -like "Y")
    }

    If($AskForFiles) 
    {
        # TODO: We should only ask for files if the task has been selected to run.
        Write-Host "All input files must be in the proper format. `nSee the ADSA PowerShell Readme document for information on creating custom files.`nPlease supply the absolute path to custom files."
        
        #check if users is supplying custom ACL file to collect
        if((Read-Host "Do you have custom ACLs to collect? [Y]/[N]") -like "Y")
        {
            $DSACLs = Get-FileNameFromDialog -initialDirectory (split-path $CustomFilePath) -filter Text
        }

        #check if user is supplying custom group file to collect
        if((Read-Host "Do you have custom group memberships to collect? [Y]/[N]") -like "Y")
        {
            $GroupMembership = Get-FileNameFromDialog -initialDirectory (split-path $CustomFilePath) -filter Text
        }

        #check if user is supplying custom local admin file to collect
        if((Read-Host "Do you have member computers from which to retrieve local Administrators group membership? [Y]/[N]") -like "Y")
        {
            $LocalAdmins = Get-FileNameFromDialog -initialDirectory (split-path $CustomFilePath) -filter Text
        }

        #check if users is omitting domains from collection
        if((Read-Host "Do you have domain(s) in the current forest to exclude from collection? [Y]/[N]") -like "Y")
        {
            $ForestInfo = Get-FileNameFromDialog -initialDirectory (split-path $CustomFilePath) -filter Text
        }
    }

    # Loop TasksToRun and update custom files as appropriate
    For ($a=0; $a -lt $TasksToRun.count; $a++)
    {
        switch ($TasksToRun[$a].taskname)
        {
            DSACLs { $TasksToRun[$a].CustomFiles = $DSACLs }
            GroupMembership { $TasksToRun[$a].CustomFiles = $GroupMembership }
            LocalAdmins { $TasksToRun[$a].CustomFiles = $LocalAdmins }
            ForestInfo { $TasksToRun[$a].CustomFiles = $ForestInfo }
        } 
    }

    if ($LocalAdmins -eq $null)
    {
        $a = $TasksToRun.TaskName.IndexOf("LocalAdmins")
        if ($TasksToRun[$a].RunTask -eq $true)
        {
            #Local Admins task can't run without an input file
            Write-Warning "Local Admins task can't run because no file was specified"
            $TasksToRun[$a].RunTask = $False
        }
    }
    
    # Return
    $TasksToRun

}


<#
.SYNOPSIS             
Get custom credentials
.DESCRIPTION            

.PARAMETER TasksToRun

.INPUTS

.OUTPUTS

.EXAMPLE

.LINK

#>
Function Get-ADSACustomCredentials
{
    Param ( [Parameter(Mandatory=$true)]$TasksToRun )

    $CurrentUser = ([System.Security.Principal.WindowsIdentity]::GetCurrent()).name
    Write-Host "For each option, choose whether to supply custom credentials."
    Write-Host "For tasks where custom credentials are not supplied, the account " -NoNewline
    Write-Host "$CurrentUser" -NoNewline -ForegroundColor DarkBlue -BackgroundColor White
    Write-host " will be used."
    
    For ($a=0; $a -lt $TasksToRun.count; $a++) 
    {
        if ($TasksToRun[$a].runtask -eq $true) 
        {
            if ((Read-Host "Do you wish to use custom credentials for the task" $TasksToRun[$a].TaskName "?") -like "Y")
            {
               $TasksToRun[$a].CustomCreds = Get-Credential 
            }       
        }
    }

    $TasksToRun
}