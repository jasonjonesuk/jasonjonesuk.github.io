[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone, 
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)][String[]]$DomainList,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=2)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null,
    [Parameter(mandatory=$false,Position=6)]$stalethreshold = $null
)

if ($Standalone) 
{ 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }

    if ($DomainList)
    {
        $domains_detail = @()
        foreach ($domain in $domainlist)
        {
            # Convert FQDN to DN
            $domainnamearray = $domain.split(".")
            $domainDN = "dc=" + $domainnamearray[0]
            for ($i=1;$i -lt $domainnamearray.count; $i++) { $domaindn += ",dc=" + $domainnamearray[$i] }

            $domainobj = New-Object psobject
            $domainobj | Add-Member NoteProperty Domain $domain
            $domainobj | Add-Member NoteProperty DomainDN $domaindn
            $domains_detail += $domainobj
        }            
    }
    else
    {
        Import-Module .\ADSA.psm1
        $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose        
    } 
} 

# Make sure we're in the OutputPath folder (this is important when running as a job
cd $OutputPath

Set-Variable -Name All_staleAccts -Value @() -Scope script

Write-Verbose "Gathering Stale Accounts.`n###############################"

function get-threshold($domainDN)
{
    #This function will get the domain's password maximum age value and convert it to days
    #Then will multiply the result by 3 to establish the "stale" threshold
    #Stale threshold value is in FileTimeUTC format
    
    #Get the password max age from the domain
    $pwdMaxAge = [ADSI]"LDAP://$($domainDN)"
    #convert this from ADSLargeInt to a workable int64
    $pwdMaxAge = $pwdMaxAge.ConvertLargeIntegerToInt64($pwdMaxAge.maxPwdAge.value)
    #establish the timespan from 'beginning of time' to the when the pwdmaxage is setting, then convert to days
    $pwdMaxAgeDays = (New-TimeSpan (get-date 1/1/1601).addticks($pwdMaxAge) (get-date 1/1/1601)).days
    
    #set the threshold as 3x the pwdmaxage
    $staleThreshold = ($pwdMaxAgeDays * 3)
    
    #convert the threshold days into FileTimeUTC format to be used for LDAP queries
    $date = date
    $thresholdUTC = $date.addDays(-$staleThreshold)
    $thresholdUTC = $thresholdUTC.ToFileTimeUTC()
    
    # Create a password object holder
    $pwdSettingsObj = new-Object PSObject
    $pwdSettingsObj | Add-Member NoteProperty PwdMaxAge $pwdMaxAgeDays
    $pwdSettingsObj | Add-Member NoteProperty StaleThreshold $staleThreshold
    $pwdSettingsObj | Add-Member NoteProperty ThresholdUTC $thresholdUTC
    
    
    return $pwdSettingsObj
}

function convertTo-datetime($int64)
{
    return [datetime]::FromFileTimeUTC($int64)
    #return [System.DateTime]::FromFileTime($int64)
}

function Test-AccountEnabled($uac)
{
    #check to see if the account is enabled or disabled.
        
    $disabledTest = 0x2
    
    if(($uac -band $disabledTest) -eq 0)
    {
        #account is enabled
        return $true
    }
    Else
    {
        #account is disabled
        return $false
    }
}

function get-accountType($objClass)
{
     #is this a user or computer account?
    switch($objClass)
    {
        {$objClass -contains "computer"} {Return "Computer"}
        {$objClass -contains "user"} {Return "User"}
        default {Return "unknown"}
    }  
}

function Get-AccountProperties($acctObj,$ageDetails,$domain)
{
        #convert to PSbase obj with properties
        $acctObj = $acctObj.psbase.properties
        
        $accountname = $acctObj.name[0]
        $SAMaccountname = $acctObj.samaccountname[0]
        $dn = $acctObj.distinguishedname[0]
        $uac = $acctObj.useraccountcontrol[0]
        $lastpwdchange = convertTo-datetime $acctObj.pwdlastset[0]
        try
        {
            $lastlogontimestamp = convertTo-datetime $acctObj.lastlogontimestamp[0]
        }
        catch # Catch the situation where lastlogontimestamp is not defined on the object (i.e. the account has never logged on)
        {
            $lastlogontimestamp = convertTo-datetime 0
        }
        $daysunchanged = (new-TimeSpan $lastpwdchange $(Get-Date)).days
        $dayssincelogon = (new-TimeSpan $lastlogontimestamp $(Get-Date)).days
        
        ## this acctexpires is 9223372036854775807 or 0 means never expires
        if(($acctObj.accountexpires[0] -eq 9223372036854775807) -or ($acctObj.accountexpires[0] -eq 0))
        {
            #account never expires
            $acctexpires = ""
        }
        else
        {#the account does expire, get the date and time
            $acctexpires = convertTo-datetime $acctObj.accountexpires[0]
        }

        # Create a stale object holder
        $staleObj = new-Object PSObject

        # Add member properties with their name and value pair
        $staleObj | Add-Member NoteProperty Domain $domain
        $staleObj | Add-Member NoteProperty AccountName $accountname
        $staleObj | Add-Member NoteProperty SAMAccountName $SAMaccountname
        $staleObj | Add-Member NoteProperty AccountType $(get-accountType $acctObj.objectclass)
        $staleObj | Add-Member NoteProperty DN $dn
        $staleObj | Add-Member NoteProperty LastPasswordChange $lastpwdchange
        $staleObj | Add-Member NoteProperty DaysPwdUnchanged $daysunchanged
        $staleObj | Add-Member NoteProperty LastLogonTimestamp $lastlogontimestamp
        $staleObj | Add-Member NoteProperty DaysSinceLastLogon $dayssincelogon
        $staleObj | Add-Member NoteProperty PasswordMaxAge $ageDetails.pwdmaxage
        $staleObj | Add-Member NoteProperty StaleThreshold $ageDetails.stalethreshold       
        $staleObj | Add-Member NoteProperty AccountExpiresOn $acctexpires
        $staleObj | Add-Member NoteProperty AccountEnabled $(Test-AccountEnabled $uac)
        
        return $staleObj
}


function Get-StaleAccounts($domainDN,$domain,$type)
{
    if ($stalethreshold)
    {
        $thresholdUTC = (get-date).addDays(-$staleThreshold)
        $thresholdUTC = $thresholdUTC.ToFileTimeUTC()        
        
        # Create a password object holder
        $pwdAgeDetails = new-Object PSObject
        $pwdAgeDetails | Add-Member NoteProperty PwdMaxAge "Not Defined"
        $pwdAgeDetails | Add-Member NoteProperty StaleThreshold $staleThreshold
        $pwdAgeDetails | Add-Member NoteProperty ThresholdUTC $thresholdUTC

    }
    else
    {
        $pwdAgeDetails = get-threshold $domainDN
        $thresholdUTC = $pwdAgeDetails.thresholdUTC
    }
    
    #LDAP query
    $Searcher = [ADSISearcher]"(&(objectCategory=$type)(objectClass=$type)(pwdLastSet<=$($thresholdUTC))(|(lastlogontimestamp<=$($thresholdUTC))(!(lastlogontimestamp=*))))"

    $Searcher.searchRoot = [ADSI]"LDAP://$($domainDN)"

    # Cache the results
    $Searcher.CacheResults = $true
    $Searcher.SearchScope = "Subtree"
    $Searcher.PageSize = 1000
<################    
#***************#> $Searcher.SizeLimit = 0
################

    #Get all objects matching the LDAP query above
    $accounts = $Searcher.FindAll()
    
    $staleAccounts = @()
    #loop for all computer accounts found
    $accounts | %{
         
         $staleAccounts += get-AccountProperties $_ $pwdAgeDetails $domain
    }#end loop
    
    return $staleAccounts
}

########################
########################
## Main Execution Start

#for all the domains get stale accounts
$domains_detail | %{

    Write-Verbose "Extracting stale accounts from domain: $($_.domain)"
    
    Write-Verbose "`tCollecting stale COMPUTER accounts ..."
    $All_staleAccts += Get-StaleAccounts $_.domainDN $_.domain 'computer'
    
    Write-Verbose "`tCollecting stale USER accounts ..."
    $All_staleAccts += Get-StaleAccounts $_.domainDN $_.domain 'user'
           
}
#export all stale accounts to CSV    
$All_staleAccts | Select-Object `
        Domain,
        @{e={$_.AccountName};n="Account Name"},
        SAMAccountName,
        @{e={$_.AccountType};n="Account Type"},
        DN,
        @{e={$_.LastPasswordChange};n="Last Password Change"},
        @{e={$_.DaysPwdUnchanged};n="Days Password Unchanged"},
        @{e={$_.LastLogonTimestamp};n="Last Logon Timestamp"},
        @{e={$_.DaysSinceLastLogon};n="Days Since Last Logon"},
        @{e={$_.PasswordMaxAge};n="Password Maximum Age"},
        @{e={$_.StaleThreshold};n="Stale Threshold"},
        @{e={$_.AccountExpiresOn};n="Account Expires On"},
        @{e={if($_.accountEnabled){"Yes"}else{"No"}};n="Account Enabled"} | `
    Export-Csv -Encoding UTF8 -NoTypeInformation "$($filePrefix)_StaleAccounts.csv"

Write-Verbose "###############################"