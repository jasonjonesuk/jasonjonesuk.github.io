﻿<#
.SYNOPSIS
Get information about target Active Directory forest for output.

.DESCRIPTION
Collect information about the target Active Directory forest and all member domains and application partition. 
- FSMO role holders
- Functional levels for the forest and each member domain
- Domain controller info including OS version and global catalog status
- Total user accounts
- Total computer accounts
- When the domain/forest was created
- Details on built-in Administrator and Guest account

.PARAMETER domains_detail
Array of objects representing properties of each domain

.PARAMETER All_DCs
Array of objects representing properties of each domain controller

.PARAMETER filePrefix
Prefix to use for file names (typically shortname of forest root domain

.PARAMETER OutputPath
Path to write CSV files

.PARAMETER FilePath
Path to custom files

.EXAMPLE

.INPUTS
None

.OUTPUTS
<ForestName>_ForestInfo.csv
<ForestName>_App_Partitions.csv
<ForestName>_Domains.csv
<ForestName>_DomainControllers.csv

.NOTES
Created by Microsoft ISRM ACE team for use as part of data collection for Active Directory Security Assessment.
Version 2.0

#>

[CmdletBinding()]
Param 
(
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=0)]$domains_detail,
    [Parameter(mandatory=$true,ParameterSetName="DataCol",Position=1)]$All_DCs,

    [Parameter(mandatory=$true,ParameterSetName="Standalone",Position=0)][switch]$Standalone,
    [Parameter(mandatory=$false,ParameterSetName="Standalone",Position=1)]$omitDomains = $null, 

    [Parameter(mandatory=$false,Position=3)]$filePrefix = $null,
    [Parameter(mandatory=$false,Position=4)]$OutputPath = ".",
    [Parameter(mandatory=$false,Position=5)]$filepath = $null
)

if ($Standalone) 
{ 
    if (!($filePrefix)) { $filePrefix = "Standalone_" + (get-date -f yyyyMMddHHmm).tostring() }
    Import-Module .\ADSA.psm1
    $domains_detail = Get-ADSATargetDomains -omitDomains $omitDomains -verbose        
    $All_DCs = Get-ADSATargetDCs -omitDomains $omitDomains -verbose
} 

# Make sure we're in the OutputPath folder (this is important when running as a job)
cd $OutputPath

if (-not $PSBoundParameters.ContainsKey('VerbosePreference'))
{
    $VerbosePreference = $PSCmdlet.GetVariableValue('VerbosePreference')
}

# Convert numeric functional level to text representation
Function convertTo-FunctionalLevelText ($msdsbehaviorversion)
{
    $functionalLevel = ""
    switch ($msdsbehaviorversion)
    {
        0 { $functionalLevel = "WIN2000" }
        1 { $functionalLevel = "WIN2003_MIXED" }
        2 { $functionalLevel = "WIN2003" }
        3 { $functionalLevel = "WIN2008" }
        4 { $functionalLevel = "WIN2008R2" }
        5 { $functionalLevel = "WIN2012" }
        6 { $functionalLevel = "WIN2012R2" }
        7 { $functionalLevel = "WIN2016" }
        default { $functionalLevel = "NOTDEFINED" }
    }

    return $functionalLevel
}

function Get-domainSID($domainDN)
{
    # Use ADSI interface to get the object
    $domain = new-object System.DirectoryServices.DirectoryEntry("LDAP://$($domainDN)")

    # Get the objectSID, which is stored in byte format.
    
    $byteObjectSID = $($domain.objectsid)
    $strObjectSID = (New-Object System.Security.Principal.SecurityIdentifier($byteObjectSID,0)).value

    return $strObjectSID
}

# Query RootDSE to get the root domain and the configuration partition for the forest
$rootdse = new-object System.DirectoryServices.DirectoryEntry("LDAP://RootDSE")
$rootdomain = $($rootdse.rootDomainNamingContext)
$config = $($rootdse.configurationNamingContext)
$schema = $($rootdse.schemaNamingContext)

# Get the root domain from $domains_detail
$rootIdx = $domains_detail.DomainDN.IndexOf($rootdomain)
$rootDomainObj = $domains_detail[$rootIdx]

# Query the Partitions container for the Forest Mode and Domain Naming Master
$partitions = [adsi]"LDAP://CN=Partitions,$config"
Write-Verbose "Getting forest functional level"
$forestmode = $($partitions.properties.'msds-Behavior-Version')
Write-Verbose "Getting Domain Naming Master"
$domainnamemaster = $($partitions.Properties.fsmoRoleOwner)

# Query the Schema NC for FSMO and schema version
$schemanc = [adsi]"LDAP://$schema"
Write-Verbose "Getting Schema Master"
$schemamaster = $($schemanc.properties.fsmoroleowner)
$schemaversion = $($schemanc.properties.objectversion)

# Get the list of Application Partitions
Write-Verbose "Getting list of application partitions"
$partitionsearcher = New-Object System.DirectoryServices.DirectorySearcher
# Complex filter to get just application partitions
        # ObjectClass = CrossRef
        # Not Enterprise Configuration
        # Not Enterprise Schema
        # Is a naming context (Systemflags 0x1)
        # Is not a domain partition (not Systemflags 0x2)
$partitionsearcher.filter = "(&(objectClass=crossRef)(!(cn=Enterprise Configuration))(!(cn=Enterprise Schema))(systemFlags:1.2.840.113556.1.4.803:=1)(!(systemFlags:1.2.840.113556.1.4.803:=2)))"
$partitionsearcher.SearchRoot = "LDAP://CN=Partitions,$config"
$partitionsearcher.SearchScope = "OneLevel"
$partitionsearcher.CacheResults = $true
$partitionsearcher.SizeLimit = 0
$partitionsearcher.PageSize = 1000
$partitionsearcher.PropertiesToLoad.add("nCName") | Out-Null
$partitionsearcher.PropertiesToLoad.Add("msDS-SDReferenceDomain") | Out-Null
$partitionlist = $partitionsearcher.FindAll()
$partitionsearcher.dispose()

$AppPartitions = @()
foreach ($partition in $partitionlist)
{
    $AppObj = New-Object psobject
    $AppObj | Add-Member NoteProperty Name $($partition.properties.ncname)
    $AppObj | Add-Member NoteProperty SecurityReferenceDomain $($partition.Properties.'msds-sdreferencedomain')
    $AppPartitions += $AppObj
}

# Create an AD Object to hold the AD basic info
$ADObj = New-Object PSObject
    
#Forest info    
$ADObj | Add-Member NoteProperty Forest $rootDomainObj.domain
$ADObj | Add-Member NoteProperty ForestMode (convertTo-FunctionalLevelText $forestmode)
$ADObj | Add-Member NoteProperty RootDomain $rootDomainObj.domain
$ADObj | Add-Member NoteProperty NetBIOSName $rootDomainObj.netbiosname
$ADObj | Add-Member NoteProperty SchemaVersion $schemaversion   

#FSMO roles
$ADObj | Add-Member NoteProperty SchemaRoleOwner ($schemamaster.split(",")[1]).replace("CN=","")
$ADObj | Add-Member NoteProperty NamingRoleOwner ($domainnamemaster.split(",")[1]).replace("CN=","")

#Dump Forest information to <ForestName>_ForestInfo.csv
$ADObj | Select-Object `
                @{e={$_.forest};n="Forest"},                
                @{e={$_.forestmode};n="Functional Level"},
                @{e={$_.schemaversion};n="Schema Version"},
                @{e={$_.rootdomain};n="Root Domain"},
                @{e={$_.NetBIOSName};n="NetBIOS Name"},
                @{e={$_.schemaroleowner};n="Schema Master"},
                @{e={$_.namingroleowner};n="Domain Naming Master"} | `
        Export-Csv -NoTypeInformation "$($filePrefix)_ForestInfo.csv"

#Dump Application partition information to <ForestName>_App_Partitions.csv
$AppPartitions | Select-Object `
                @{e={$_.name};n="Name"},
                @{e={$_.securityreferencedomain};n="Security Reference Domain"} | `
        Export-Csv -NoTypeInformation "$($filePrefix)_App_Partitions.csv"

# Get some additional details for each domain
foreach ($domain in $domains_detail)
{
    Write-Verbose "Getting creation date for domain $($domain.domain)"
    $domainnc = [adsi]"LDAP://$($domain.domaindn)"
    $createdDate = $domainnc.Properties.whencreated

    Write-Verbose "Getting builtin account names for domain $($domain.domain)"
    $domainsid = Get-domainSID $($domain.domain)
    
    $domainsearcher = New-Object System.DirectoryServices.DirectorySearcher
    $domainsearcher.SearchRoot = "LDAP://$($domain.domaindn)"
    $domainsearcher.SearchScope = "SubTree"
    $domainsearcher.CacheResults = $true
    $domainsearcher.PageSize = 1000  
    $domainsearcher.SizeLimit = 0
    $domainsearcher.filter = "(objectsid=$($domainsid + '-500'))"
    $admin = $domainsearcher.findone()
    $domainsearcher.filter = "(objectsid=$($domainsid + '-501'))"
    $guest = $domainsearcher.findone()

    # Update $Domains_Detail with the Admin and guest information
    $index = $domains_detail.domaindn.indexof($domain.domaindn)
    Write-Verbose "Adding creation and account data with index of $($index)."
    $domains_detail[$index] | Add-Member NoteProperty Created $($createdDate)
    $domains_detail[$index] | Add-Member NoteProperty Admin $($admin.properties.samaccountname)
    $domains_detail[$index] | Add-Member NoteProperty Guest $($Guest.properties.samaccountname)
    $domains_detail[$index] | Add-Member NoteProperty AdminDN $($admin.properties.distinguishedname)
    $domains_detail[$index] | Add-Member NoteProperty GuestDN $($Guest.properties.distinguishedname)
}    



#Dump Domain information to <ForestName>_Domains.csv
$Domains_Detail | Select-Object `
                @{e={$_.domain};n="Domain"},
                @{e={$_.domainDN};n="Domain DN"},
                @{e={$_.NetBIOSName};n="NetBIOS Name"},
                @{e={convertTo-FunctionalLevelText $_.domainmode};n="Functional Level"},
                @{e={$_.pdcroleowner};n="PDC Emulator"},
                @{e={$_.ridroleowner};n="RID Master"},
                @{e={$_.infraroleowner};n="Infrastructure Master"},
                @{e={$_.created};n="Domain Creation Date"},
                @{e={$_.admin};n="Admin SAMAccountName"},
                @{e={$_.adminDN};n="Admin Distinguished Name"},
                @{e={$_.guest};n="Guest SAMAccountName"},
                @{e={$_.guestDN};n="Guest Distinguished Name"} | `
        Export-Csv -NoTypeInformation "$($filePrefix)_Domains.csv"
  
#Dump Domain Controller information to <ForestName>_DomainControllers.csv
$All_DCs | Export-Csv -NoTypeInformation "$($filePrefix)_DomainControllers.csv"

  