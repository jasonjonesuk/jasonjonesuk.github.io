param (
    [Parameter(Mandatory=$true)]
    [string]$preferredDC
)

<#
.SYNOPSIS
    This script is used to create rename legacy Tier Model objects before deploying the latest Tier Model to avoid conflicts where duplicate names exist.

.DESCRIPTION
    RM prefix stands for Remove, mean after migration these objects can will be removed as they are no longer required by the new Tier Model.
    This script will rename legacy Tier Model Groups to include the 'RM_' for both the Group Name and the pre-Windows 2000 name.
    This script will rename legacy Tier Model GPOs to include the 'RM_' for the GPO Name, from *- to *RM-.

.PARAMETER PreferredDC
    Ensure all changes occur on the Preferred Domain Controller to avoid replication issues.

.EXAMPLE
    .\Migrate-LegacyTierModel.ps1 -PreferredDC 'DC01.contoso.com'

.NOTES
    This sample script is not supported under any Microsoft standard support program or service. 
    The sample script is provided AS IS without warranty of any kind. Microsoft further disclaims 
    all implied warranties including, without limitation, any implied warranties of merchantability 
    or of fitness for a particular purpose. The entire risk arising out of the use or performance of 
    the sample scripts and documentation remains with you. In no event shall Microsoft, its authors, 
    or anyone else involved in the creation, production, or delivery of the scripts be liable for any 
    damages whatsoever (including, without limitation, damages for loss of business profits, business 
    interruption, loss of business information, or other pecuniary loss) arising out of the use of or 
    inability to use the sample scripts or documentation, even if Microsoft has been advised of the 
    possibility of such damages
#>

# Import the Active Directory module
Import-Module ActiveDirectory

# Define the prefix to add
$groupPrefix = "RM_"

# Define the array of existing group names
$existingGroupNames = @(
    "AdminDomainJoin",
    "BreakGlassAdmins",
    "Tier 0 Application Operators",
    "Tier 0 Build Domain Controller using MDT",
    "Tier 0 Domain Operators",
    "Tier 0 HGS Admins",
    "Tier 0 HGS gMSA Users",
    "Tier 0 HGS View Admins",
    "Tier 2 Computer Quarantine Operators",
    "Tier0Admins",
    "Tier0Operators",
    "Tier0ServerOperators",
    "Tier1Admins",
    "Tier1ApplicationXOperators",
    "Tier1Operators",
    "Tier1ServerOperators",
    "Tier2AccountOperators",
    "Tier2Admins",
    "Tier2DeviceOperators",
    "Tier2GroupOperators",
    "Tier2HelpdeskOperators",
    "Tier2Operators"
)

foreach ($existingGroupName in $existingGroupNames) {
    # Get the group object
    $group = Get-ADGroup -Identity $existingGroupName

    # Construct the new names
    $newGroupName = $groupPrefix + $group.Name
    $newPreWin2000Name = $groupPrefix + $group.sAMAccountName

    # Rename the group
    Rename-ADObject -Identity $group.DistinguishedName -NewName $newGroupName -Server $preferredDC

    # Update the sAMAccountName (pre-Windows 2000 name)
    Set-ADGroup -Identity $group.SamAccountName -SamAccountName $newPreWin2000Name -Server $preferredDC

    Write-Output "Group renamed successfully to $newGroupName with pre-Windows 2000 name $newPreWin2000Name"
}

$existingGPONames = @(
    "*- Additional Domain Security Settings",
    "*- Computer Quarantine",
    "*- MSFT Windows Server 2022 - Domain Security",
    "*- PAW Staging BitLocker",
    "*- PAW Staging Restricted Groups",
    "*- Tier 0 DCs MSFT Edge Version 107 - Computer",
    "*- Tier 0 DCs MSFT Internet Explorer 11 - Computer",
    "*- Tier 0 DCs MSFT Windows 10 1809 and Server 2019 - Defender Antivirus",
    "*- Tier 0 DCs MSFT Windows 10 and Server 2016 Defender",
    "*- Tier 0 DCs MSFT Windows Server 2012 R2 Domain Controller Baseline",
    "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller",
    "*- Tier 0 DCs MSFT Windows Server 2019 - Domain Controller Virtualization Based Security",
    "*- Tier 0 DCs MSFT Windows Server 2022 - Defender Antivirus",
    "*- Tier 0 DCs MSFT Windows Server 2022 - Domain Controller",
    "*- Tier 0 DCs MSFT Windows Server 2022 - Domain Controller Virtualization Based Security",
    "*- Tier 0 DCs SCM Windows Server 2016 - Domain Controller Baseline",
    "*- Tier 0 DCs Windows Server 2019 Disable System Guard Secure Launch",
    "*- Tier 0 PAWs",
    "*- Tier 0 PAWs Admin",
    "*- Tier 0 PAWs BitLocker",
    "*- Tier 0 PAWs Devices Base AppLocker Audit",
    "*- Tier 0 PAWs Devices Base AppLocker Enforce",
    "*- Tier 0 PAWs Internet Access Configuration - User",
    "*- Tier 0 PAWs LAPS",
    "*- Tier 0 PAWs MSFT Edge Version 107 - Computer",
    "*- Tier 0 PAWs MSFT Internet Explorer 11 - Computer",
    "*- Tier 0 PAWs MSFT Internet Explorer 11 - User",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - Computer",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 0 PAWs MSFT Windows 11 21H2 - User",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - Computer",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 0 PAWs MSFT Windows 11 22H2 - User",
    "*- Tier 0 PAWs Telemetry Configuration",
    "*- Tier 0 Servers",
    "*- Tier 0 Servers Host Guardian Service Administration Policy",
    "*- Tier 0 Servers LAPS",
    "*- Tier 0 Servers MSFT Edge Version 107 - Computer",
    "*- Tier 0 Servers MSFT Internet Explorer 11 - Computer",
    "*- Tier 0 Servers MSFT Windows 10 1809 and Server 2019 - Defender Antivirus",
    "*- Tier 0 Servers MSFT Windows 10 1809 and Server 2019 Member Server - Credential Guard",
    "*- Tier 0 Servers MSFT Windows 10 and Server 2016 - Credential Guard",
    "*- Tier 0 Servers MSFT Windows 10 and Server 2016 Defender",
    "*- Tier 0 Servers MSFT Windows Server 2012 R2 Member Server Baseline",
    "*- Tier 0 Servers MSFT Windows Server 2019 - Member Server",
    "*- Tier 0 Servers MSFT Windows Server 2022 - Defender Antivirus",
    "*- Tier 0 Servers MSFT Windows Server 2022 - Member Server",
    "*- Tier 0 Servers MSFT Windows Server 2022 - Member Server Credential Guard",
    "*- Tier 0 Servers SCM Windows Server 2016 - Member Server Baseline - Computer",
    "*- Tier 0 Servers SCM Windows Server 2016 - Member Server Baseline - User",
    "*- Tier 0 Servers Windows Server 2019 Disable System Guard Secure Launch",
    "*- Tier 1 PAWs",
    "*- Tier 1 PAWs Admin",
    "*- Tier 1 PAWs BitLocker",
    "*- Tier 1 PAWs Devices Base AppLocker Audit",
    "*- Tier 1 PAWs Devices Base AppLocker Enforce",
    "*- Tier 1 PAWs Internet Access Configuration - User",
    "*- Tier 1 PAWs LAPS",
    "*- Tier 1 PAWs MSFT Edge Version 107 - Computer",
    "*- Tier 1 PAWs MSFT Internet Explorer 11 - Computer",
    "*- Tier 1 PAWs MSFT Internet Explorer 11 - User",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - Computer",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 1 PAWs MSFT Windows 11 21H2 - User",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - Computer",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 1 PAWs MSFT Windows 11 22H2 - User",
    "*- Tier 1 PAWs Telemetry Configuration",
    "*- Tier 1 Servers",
    "*- Tier 1 Servers LAPS",
    "*- Tier 1 Servers MSFT Edge Version 107 - Computer",
    "*- Tier 1 Servers MSFT Internet Explorer 11 - Computer",
    "*- Tier 1 Servers MSFT Windows 10 1809 and Server 2019 - Defender Antivirus",
    "*- Tier 1 Servers MSFT Windows 10 1809 and Server 2019 Member Server - Credential Guard",
    "*- Tier 1 Servers MSFT Windows 10 and Server 2016 - Credential Guard",
    "*- Tier 1 Servers MSFT Windows 10 and Server 2016 Defender",
    "*- Tier 1 Servers MSFT Windows Server 2012 R2 Member Server Baseline",
    "*- Tier 1 Servers MSFT Windows Server 2019 - Member Server",
    "*- Tier 1 Servers MSFT Windows Server 2022 - Defender Antivirus",
    "*- Tier 1 Servers MSFT Windows Server 2022 - Member Server",
    "*- Tier 1 Servers MSFT Windows Server 2022 - Member Server Credential Guard",
    "*- Tier 1 Servers SCM Windows Server 2016 - Member Server Baseline - Computer",
    "*- Tier 1 Servers SCM Windows Server 2016 - Member Server Baseline - User",
    "*- Tier 1 Servers Staging",
    "*- Tier 1 Servers Windows Server 2019 Disable System Guard Secure Launch",
    "*- Tier 2 Devices Staging",
    "*- Tier 2 LAPS",
    "*- Tier 2 MSFT Edge Version 107 - Computer",
    "*- Tier 2 MSFT Internet Explorer 11 - Computer",
    "*- Tier 2 MSFT Internet Explorer 11 - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Computer",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - DDE Block - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Legacy File Block - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Legacy JScript Block - Computer",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - Require Macro Signing - User",
    "*- Tier 2 MSFT M365 Apps for enterprise 2104 - User",
    "*- Tier 2 MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 2 MSFT Windows 11 21H2 - Computer",
    "*- Tier 2 MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 2 MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 2 MSFT Windows 11 21H2 - User",
    "*- Tier 2 MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 2 MSFT Windows 11 22H2 - Computer",
    "*- Tier 2 MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 2 MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 2 MSFT Windows 11 22H2 - User",
    "*- Tier 2 PAWs",
    "*- Tier 2 PAWs Admin",
    "*- Tier 2 PAWs BitLocker",
    "*- Tier 2 PAWs Devices Base AppLocker Audit",
    "*- Tier 2 PAWs Devices Base AppLocker Enforce",
    "*- Tier 2 PAWs Internet Access Configuration - User",
    "*- Tier 2 PAWs LAPS",
    "*- Tier 2 PAWs MSFT Edge Version 107 - Computer",
    "*- Tier 2 PAWs MSFT Internet Explorer 11 - Computer",
    "*- Tier 2 PAWs MSFT Internet Explorer 11 - User",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - BitLocker",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - Computer",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - Credential Guard",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - Defender Antivirus",
    "*- Tier 2 PAWs MSFT Windows 11 21H2 - User",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - BitLocker",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - Computer",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - Credential Guard",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - Defender Antivirus",
    "*- Tier 2 PAWs MSFT Windows 11 22H2 - User",
    "*- Tier 2 PAWs Telemetry Configuration",
    "*- Tier 2 Workstations"
)

foreach ($existingGPOName in $existingGPONames) {
    
    # Get the GPO object
    $gpo = Get-GPO -DisplayName $existingGPOName

    # Replace name with new name
    $newName = $gpo.DisplayName -replace '[*]', '*RM'
        
    # Rename the GPO
    Rename-GPO -Guid $gpo.Id -TargetName $newName -Server $preferredDC
    Write-Output "Renamed GPO '$($gpo.DisplayName)' to '$newName'"

}

# SIG # Begin signature block
# MIIoKQYJKoZIhvcNAQcCoIIoGjCCKBYCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBa9n41RNaQ9Cwc
# wmb3nOImt8rsVMpu0+9OJrB/U2ZV8KCCDXYwggX0MIID3KADAgECAhMzAAAEhV6Z
# 7A5ZL83XAAAAAASFMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjUwNjE5MTgyMTM3WhcNMjYwNjE3MTgyMTM3WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDASkh1cpvuUqfbqxele7LCSHEamVNBfFE4uY1FkGsAdUF/vnjpE1dnAD9vMOqy
# 5ZO49ILhP4jiP/P2Pn9ao+5TDtKmcQ+pZdzbG7t43yRXJC3nXvTGQroodPi9USQi
# 9rI+0gwuXRKBII7L+k3kMkKLmFrsWUjzgXVCLYa6ZH7BCALAcJWZTwWPoiT4HpqQ
# hJcYLB7pfetAVCeBEVZD8itKQ6QA5/LQR+9X6dlSj4Vxta4JnpxvgSrkjXCz+tlJ
# 67ABZ551lw23RWU1uyfgCfEFhBfiyPR2WSjskPl9ap6qrf8fNQ1sGYun2p4JdXxe
# UAKf1hVa/3TQXjvPTiRXCnJPAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUuCZyGiCuLYE0aU7j5TFqY05kko0w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwNTM1OTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBACjmqAp2Ci4sTHZci+qk
# tEAKsFk5HNVGKyWR2rFGXsd7cggZ04H5U4SV0fAL6fOE9dLvt4I7HBHLhpGdE5Uj
# Ly4NxLTG2bDAkeAVmxmd2uKWVGKym1aarDxXfv3GCN4mRX+Pn4c+py3S/6Kkt5eS
# DAIIsrzKw3Kh2SW1hCwXX/k1v4b+NH1Fjl+i/xPJspXCFuZB4aC5FLT5fgbRKqns
# WeAdn8DsrYQhT3QXLt6Nv3/dMzv7G/Cdpbdcoul8FYl+t3dmXM+SIClC3l2ae0wO
# lNrQ42yQEycuPU5OoqLT85jsZ7+4CaScfFINlO7l7Y7r/xauqHbSPQ1r3oIC+e71
# 5s2G3ClZa3y99aYx2lnXYe1srcrIx8NAXTViiypXVn9ZGmEkfNcfDiqGQwkml5z9
# nm3pWiBZ69adaBBbAFEjyJG4y0a76bel/4sDCVvaZzLM3TFbxVO9BQrjZRtbJZbk
# C3XArpLqZSfx53SuYdddxPX8pvcqFuEu8wcUeD05t9xNbJ4TtdAECJlEi0vvBxlm
# M5tzFXy2qZeqPMXHSQYqPgZ9jvScZ6NwznFD0+33kbzyhOSz/WuGbAu4cHZG8gKn
# lQVT4uA2Diex9DMs2WHiokNknYlLoUeWXW1QrJLpqO82TLyKTbBM/oZHAdIc0kzo
# STro9b3+vjn2809D0+SOOCVZMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgkwghoFAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAASFXpnsDlkvzdcAAAAABIUwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEICILq8U0pfOuBHbx4WxIsfc8
# 0GJ8Fnn/5TXTbfcOB/yBMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAAUkkCTpTEexT/euY3GcX9wqlS2X5LH/Mi0OcYWpUDL6OknntRpcn2rQb
# b4OVt1oBpPMtVfaTZVNkGGy396GgofSv3K8/sae0N5pIL37zM5s1/x3rAnbh+V7N
# dlIMCALhX+2AjOBtS8ugJP3or62LH8XkKo3Fhd9YOIPJs4wUfiWRcwCC2vUjxSq7
# NiWak41czZVjyQyuNOkYyZJNrRVCBoNTW2GoL31A7WjpQ0U2Ppd54+Pzx6w8K/Xf
# BIknpRRzneQJ+5dn4zMJYbNPxcbdP4vpPsvE1co+5Tk5IIcvthx0XQ5Hozf2Rge2
# KoPc/paNLoW0UwXB1V+aRbYDBwmICKGCF5MwghePBgorBgEEAYI3AwMBMYIXfzCC
# F3sGCSqGSIb3DQEHAqCCF2wwghdoAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBYSaQtylDuafUwfjbo17ZtYBFTzw0Iq0V2rk9srpNZuQIGaMLIY7pz
# GBIyMDI1MTAwODIwMDgwNC41MlowBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjpBOTM1LTAz
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# EeowggcgMIIFCKADAgECAhMzAAACDLlk4zWc7PSuAAEAAAIMMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTI1MDEzMDE5NDMw
# MFoXDTI2MDQyMjE5NDMwMFowgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjpBOTM1LTAzRTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAMoBViY95G2Br9TqPOrKosPQwCiiXbeBwE3nz5n9eyRj
# A0mxn477BXJBiXx09MrX8ELbECJzWb4m9ySqNVpDfYqZRGwRmi2KtBjg8pVb55fB
# G3evqzOAu6JzqqgeVtejH+XQcm2BRGTMNdYyQqYZIvvPz9yupy+Ziq/y3+yUAXgn
# 6anNv20wVWaPApc41V1HCD1DdZo9kELta+iLs9Eg3aOCNIGcdjIBlKWy0o2ulhvr
# 4a7qhIWRDMalHrn5A0N2Q/i585/g9s6Dd9vi4Y+MjwQ8qWnAzBqLWRDJf5+ByAKh
# X0n6jwxhgJlR63eTOGHBHOqHosx4ONpcs/vTVJdeJdzZkfO4MdtL+xm0nfrbtxWk
# KVcQhS+DbGmvSs+Ui0fC2OjU/AwKldiqdgq9fxonydrBP1bwVS67Jk8bXznb6riO
# RWV4ovvH7t6XwRN6Ft2TB2EBfJeKZoTNZ6001KYb8p8cCn1zPCwvW8qvhGCf6kgi
# Rke6iZ1/l7jzUr7EhaEsI92m5XzsSoY4r+NuE6dkSrB28DQCUxot+yYJ6Zma6l6N
# pi4STTn/pwJTGAXjMKeQl5h0wA/71niRWHu3NEWzD+VlKXYPsSEgDoqePpF98faT
# ti1IZK/zoJKHN+JdrP3LqxO7xIaoXo5sv9678OSK/JWgJ9RdYuOJImytLrcPQQcd
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUdQ5FIf+wH+tD9t4PSXlXFDvToYgwHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBANkw+viBWbDB/gYwHll8dKvfi6G6DrLO7gdR
# P4lYxmrP26EtkGhfkI+N0onPABW9ig24uZLT72UDlLviu8qp3+72+nzxUaTpTuAx
# x5q12qkqVtVF2fZl+sxykjjM5zoG25ivMlXhwSzViZf3m6IDFoQPfjDTYGd+49lc
# DR52wMFt3iLEVTxf/UnQN8hSTVgVg86ubCYjaTXq7pNwo7RilGXBN0Kr287R4QgR
# HVIuZA0HNf2HZxwK+2B6Q5oGghDdlFqLwOzV/7BwoI/MPioNffE2C8sWIqgDplIb
# 1L/I6sZqJIYh4PLk31VC6pM2OvK4DOO9/lbwBCnfWFXUZtQM6RtR137OQlYpfgWb
# N543nYQRvKShZwnlX0zgM8Y3nGkWpfL1o7T51HRRRha6p4uEPJGdV5lxMS7TGCaj
# 6lAdq4VUBKxU5EynxMXx2l6x362qSRDxU28jbSg5+dN8v7tmBQx/uo1XSWXRajme
# WvUIm9rVt+TYdzkFjUz2x3duUGR7PK8k+fiPRt846sJhPBiw2yOJGX9ZbXw06mLC
# pyLAWVQ2q1YJEzML2vzhhpQxDzYHLCTjx3i4GiflkDylddLuPAlOMmPlRJ5GX2+N
# P3w8NnIIU7Z4VI4V0N1/pYGj9ZlQDaEZnSr4nuPXjR9tcJ85QibSPbcdoBXRyQNL
# +eYL+gXWMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA00w
# ggI1AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046QTkzNS0wM0UwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAO+7
# yGSEQy3lnwt15+WzvPUtVTymoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDskNtCMCIYDzIwMjUxMDA4MTI0NDUw
# WhgPMjAyNTEwMDkxMjQ0NTBaMHQwOgYKKwYBBAGEWQoEATEsMCowCgIFAOyQ20IC
# AQAwBwIBAAICCuwwBwIBAAICFOYwCgIFAOySLMICAQAwNgYKKwYBBAGEWQoEAjEo
# MCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkqhkiG
# 9w0BAQsFAAOCAQEAk9xlQbqKzy/0WBMR1jR47UnuO10DNOtTBJ/YYjgiLKhdwLWM
# u+aUp6fiCwhRofVVQuVQqjzP87lIgjRYnxfH1ouFJAGNwBsMUjkjWhOlYwWWIo1q
# NmQA6t5WcRhJbNyZ9YfDlTFzW7Ddo2PCjaXCQ8IluLpsI7eQXbFJN40+iIMXIWu4
# Q+g/GlOKKmO93CevdvVr5yIxTvbz1GTH+qCWv598riSTBwmoqcvnA6d7owTYflH/
# orKl3IU9b+qRiJhtUYlt1W4mLx2CHxUZ8u8u+y4L2St216CoiAwAKYZe9UUcqdY5
# WJmXKjU0y2DIgH8ev8MmdqfCu6lOqrcFn9J0FzGCBA0wggQJAgEBMIGTMHwxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jv
# c29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAACDLlk4zWc7PSuAAEAAAIMMA0G
# CWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJ
# KoZIhvcNAQkEMSIEIFxET8JC/CoYQ+jSuIzDBT5TN+3LZsi58IicxIcGR9ksMIH6
# BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg1SjXtwUxk3jowjk18gCD1THlw7nE
# z2Ket7muK45nwi0wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAx
# MAITMwAAAgy5ZOM1nOz0rgABAAACDDAiBCDIhtqjPCTSukFqe4rhuUvqOk9eLyC0
# ciNfIdQCDMs/JTANBgkqhkiG9w0BAQsFAASCAgCydnE8B9OL92R4N8+jM3ri3mkD
# QxQ7tveOw8n5zeQI6xSMrm9S/b2PXX+mw9UISmfEVKFeaJ2o85GdQUBPFAmZ1qPw
# cJv9tc7hs4zJsjXpji+d6uuvu2q9WGn/VgwmHClDRI+yLCCfYNnLB6tBu7/PUHzB
# WihfMyN4M8p7A/TAiFhqPkdRRhyEK+udO9UwyFmtdAnbXjQvWjLrNeE0YIGuFGLA
# VHCdj6zJcc6VfMziWJC8+On4YqbQiFPnHHemUM3ApEJHYGzihPUdpjDMnf2h6ceb
# bn1Xcr8UfpZlzkIxDjOE2KtQ9YyOsMMVkZgmN8DO7P25ZcS+WTwUFI3dX+Gen/eN
# 8c/+/XXiA4234hto2nLHVu96BJdEc2krgq/Iup9UCsLiy/JO3qf7Rnp/Yi6mxxrl
# MwqRn1uK85LaYFtUU+4t1meeDocrkEBs2KxKSFiwkh4gQM2M11aHRJyXi4JIeCio
# B4b3uTw06rJ+7y31OPmCmr1VI+YMZPlh9Cp1NGyqvQ+cjIqoUooZIgNQYJreaX3K
# /pp06av5r/M9DTQZwQbfDrz97HEhxqCBJ2kTUyT3fLdrvPIqNpY3wTljvEBxIkqn
# o3J7w+mCvV/6MqYxIq39+zGBHOeLyzCt8x7TqHPvKb5WqRb50FdNKU5onp3bZX9T
# k7tK/aLK59bX8vsrDA==
# SIG # End signature block
